﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Totest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           CEGMisc.clsCEGMiscWML obj1 = new CEGMisc.clsCEGMiscWML();
            obj1.ToGetUsedStyleForEditingFramework(@"CH1_BM_9781526125286.docx||CH2_BM_9781526125286.docx||CH3_BM_9781526125286.docx||CH4_BM_9781526125286.docx||CH5_BM_9781526125286.docx||CH6_BM_9781526125286.docx||CH7_BM_9781526125286.docx||CH7_BM_9781526125286.docx", @"D:\Thiyagu Workarea\Downloads\9781526125286\9781526125286---style report missing", "CEG", "9781526125286", "An Introduction to the Science of the Mind"); 
        }
    }
}
