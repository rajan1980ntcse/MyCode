﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Specialized;
using System.Net.Http;
using System.Threading;
using System.Xml;
using System.Xml.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Windows.Forms;
using Word = Microsoft.Office.Interop.Word;
using System.Globalization;
using System.Net;
using System.IO;
using CEGINI;
using System.Runtime.InteropServices;
using System.Drawing;
using System.Text.RegularExpressions;
using Microsoft.VisualBasic;
using System.Security.Permissions;

namespace CEGUtility
{
    [ComVisible(true)]
    [ClassInterface(ClassInterfaceType.AutoDual)]
    
    class clsLegislation
    {
        String PreferredLegislation = "";
        Word.Document activeDoc = null;
        [HostProtectionAttribute(SecurityAction.LinkDemand, Resources = HostProtectionResource.UI)]
        //public string InputBox(string Prompt, string Title = "", string DefaultResponse = "");
        public Boolean ToFormatLegislation(Word.Document wDoc, Word.Application WordApp)
        {
            Word.Range fullTextRange = null;
            activeDoc = wDoc;
            activeDoc.TrackRevisions = true;
            int iExit = 0;
           // bool bolFO = false;
            try
            {

            //if (bolFO==true)
            //{ goto again2; }
            
                //body of the contents
                fullTextRange = activeDoc.StoryRanges[Word.WdStoryType.wdMainTextStory];
                fullTextRange.Find.ClearFormatting();
                fullTextRange.Find.Format = true;
                fullTextRange.Find.Text = null;
                fullTextRange.Find.Wrap = Word.WdFindWrap.wdFindStop;
                fullTextRange.Find.set_Style("‡text_legislation");
                string bVal = "";
                //fullTextRange.Find.Font.Shading.BackgroundPatternColor = Word.WdColor.wdColorBrightGreen;
                while (fullTextRange.Find.Execute())//Used "While" To Pick up the two or more content in a footnote
                {

                    try
                    {
                        if (wDoc.Application.Selection.Bookmarks.Exists("\\EndofDoc") == true) { break; }

                        bVal = getLegislationCitations(fullTextRange, wDoc);

                        if (bVal.ToLower() == "exit")
                        {
                            iExit = 1;
                            //  break;
                            //   System.Windows.Forms.Application.Exit();
                            return true;
                        }
                        else
                            if (bVal.ToLower() == "next")
                        {
                            fullTextRange.Find.Text = null;
                            fullTextRange.Collapse(Word.WdCollapseDirection.wdCollapseEnd);
                            fullTextRange.Find.Forward = true;
                        }
                        else
                           if (bVal.ToLower() == "previous")
                        {
                            fullTextRange.Find.Text = null;
                            fullTextRange.Collapse(Word.WdCollapseDirection.wdCollapseStart);
                            fullTextRange.Find.Forward = false;
                        }

                        else
                                if (bVal.ToLower() == "undo")
                        {
                            fullTextRange.Find.Text = null;
                            activeDoc.ActiveWindow.View.ShowFieldCodes = true;
                            int fccounter = fullTextRange.Fields.Count;
                            int fccounterprev = fullTextRange.Previous().Words[1].Fields.Count;

                            //************Delete the field**************
                            for (int i = fccounter; i >= 1; i--)
                            {
                                if (fullTextRange.Fields[1].Code.Text.Contains("Legis"))
                                {
                                    fullTextRange.Fields[1].Code.Text = "";
                                    fullTextRange.Fields[1].Unlink();
                                    wDoc.Application.Selection.Range.Font.Shading.BackgroundPatternColorIndex = Word.WdColorIndex.wdBrightGreen;
                                }

                            }

                            for (int i = fccounterprev; i >= 1; i--)
                            {
                                if (fullTextRange.Previous().Words[1].Fields[1].Code.Text.Contains("Legis"))
                                {
                                    fullTextRange.Previous().Words[1].Fields[1].Code.Text = "";
                                    fullTextRange.Previous().Words[1].Fields[1].Unlink();
                                    wDoc.Application.Selection.Range.Font.Shading.BackgroundPatternColorIndex = Word.WdColorIndex.wdBrightGreen;
                                }

                            }
                            activeDoc.ActiveWindow.View.ShowFieldCodes = false;
                            //************Delete the field**************


                            wDoc.Application.Selection.Range.Collapse(Word.WdCollapseDirection.wdCollapseEnd);
                            wDoc.Application.Selection.MoveRight();
                            fullTextRange.Start = wDoc.Application.Selection.Start;
                            fullTextRange.End = wDoc.Application.Selection.End;
                            fullTextRange.Select();
                            fullTextRange.Find.Forward = true;
                            fullTextRange.Find.set_Style("‡text_legislation");
                            // fullTextRange.Find.Execute();
                        }
                    }
                    catch(Exception Ex)
                    {
                        continue;
                    }
                }
                if (bVal=="previous" && fullTextRange.Find.Forward == false)
                {
                   
                    CEGUtility.Legislation frm;
                    do
                    {
                        MessageBox.Show("We are in the first legislation.");
                        frm = new CEGUtility.Legislation(fullTextRange.Text, PreferredLegislation, wDoc);
                        frm.ShowDialog();
                    } while (frm.userAction == 3);
                    string legRetrun = frm.legDetail;

                    if (frm.userAction == 0)
                    {
                        frm.Close();
                        bVal= "next";
                        fullTextRange = activeDoc.StoryRanges[Word.WdStoryType.wdMainTextStory];
                        fullTextRange.Find.ClearFormatting();
                        fullTextRange.Find.Format = true;
                        fullTextRange.Find.Forward = true;
                        fullTextRange.Find.Text = null;
                        fullTextRange.Find.Wrap = Word.WdFindWrap.wdFindStop;
                        fullTextRange.Find.set_Style("‡text_legislation");
                        fullTextRange.Find.Execute(); fullTextRange.Find.Execute();
                        frm = new CEGUtility.Legislation(fullTextRange.Text, PreferredLegislation, wDoc);
                        frm.ShowDialog();
                    }
                   
                    if (frm.userAction == 2)
                    {
                        iExit = 1;
                        return true;
                       // Application.Exit();

                    }

                   if (frm.userAction == 4)
                    {
                        fullTextRange.Find.Text = null;
                        activeDoc.ActiveWindow.View.ShowFieldCodes = true;
                        int fccounter = fullTextRange.Fields.Count;
                        int fccounterprev = fullTextRange.Previous().Words[1].Fields.Count;

                        //************Delete the field**************
                        for (int i = fccounter; i >= 1; i--)
                        {
                            if (fullTextRange.Fields[1].Code.Text.Contains("Legis"))
                            {
                                fullTextRange.Fields[1].Code.Text = "";
                                fullTextRange.Fields[1].Unlink();
                                wDoc.Application.Selection.Range.Font.Shading.BackgroundPatternColorIndex = Word.WdColorIndex.wdBrightGreen;
                            }

                        }

                        for (int i = fccounterprev; i >= 1; i--)
                        {
                            if (fullTextRange.Previous().Words[1].Fields[1].Code.Text.Contains("Legis"))
                            {
                                fullTextRange.Previous().Words[1].Fields[1].Code.Text = "";
                                fullTextRange.Previous().Words[1].Fields[1].Unlink();
                                wDoc.Application.Selection.Range.Font.Shading.BackgroundPatternColorIndex = Word.WdColorIndex.wdBrightGreen;
                            }

                        }
                        activeDoc.ActiveWindow.View.ShowFieldCodes = false;
                        //************Delete the field**************

                        wDoc.Application.Selection.Range.Collapse(Word.WdCollapseDirection.wdCollapseEnd);
                        wDoc.Application.Selection.MoveRight();
                        fullTextRange.Start = wDoc.Application.Selection.Start;
                        fullTextRange.End = wDoc.Application.Selection.End;
                        fullTextRange.Select();
                        fullTextRange.Find.Forward = true;
                        fullTextRange.Find.set_Style("‡text_legislation");
                       // fullTextRange.Find.Execute();

                    }

                    if (frm.userAction == 1)
                    {
                        frm.Close();
                        wDoc.Application.Selection.Range.Font.Shading.BackgroundPatternColorIndex = Word.WdColorIndex.wdYellow;

                        string storytype = wDoc.Application.Selection.Range.StoryType.ToString();




                        //Insert the legislation as FECode Text
                        //Word.Field f;
                        object fieldType = Word.WdFieldType.wdFieldEmpty;
                        //   String FieldText = "LegisRef: " + legRetrun.Split(new string[] { "|" }, StringSplitOptions.None)[0].Trim() + " LegisPubWork: " + legRetrun.Split(new string[] { "|" }, StringSplitOptions.None)[1].Trim() + " LegisJurisdiction: " + legRetrun.Split(new string[] { "|" }, StringSplitOptions.None)[2].Trim();
                        String FieldText = "LegisRef: " + legRetrun.Split(new string[] { "|" }, StringSplitOptions.None)[0].Trim() + " LegisTitle: " + legRetrun.Split(new string[] { "|" }, StringSplitOptions.None)[1].Trim() + " LegisJurisdiction: " + legRetrun.Split(new string[] { "|" }, StringSplitOptions.None)[2].Trim();
                        object preserve = false;


                        if (storytype == "wdFootnotesStory")
                        {

                            int charpos = wDoc.StoryRanges[Word.WdStoryType.wdFootnotesStory].Application.Selection.Range.Start;
                            Word.Range footnoteRange = wDoc.StoryRanges[Word.WdStoryType.wdFootnotesStory];
                            Word.Range myrange = footnoteRange.Duplicate;
                            myrange.Start = charpos;
                            myrange.End = charpos;
                            //myrange.Font.Italic = 0;
                            #region ChangingCaseforFields
                            Boolean bolTrackrevisions = false;
                            if (wDoc.TrackRevisions == true) { bolTrackrevisions = true; wDoc.TrackRevisions = false; }
                            footnoteRange.Fields.Add(myrange, ref fieldType, FieldText.Trim(), ref preserve).Select();
                            wDoc.Application.Selection.Font.Italic = 0;
                            if (bolTrackrevisions == true) { wDoc.TrackRevisions = true; }
                            #endregion
                        //    footnoteRange.Fields.Add(myrange, ref fieldType, FieldText, ref preserve);
                        }
                        if (storytype == "wdEndnotesStory")
                        {
                            int charpos = wDoc.StoryRanges[Word.WdStoryType.wdEndnotesStory].Application.Selection.Range.Start;
                            Word.Range endnoteRange = wDoc.StoryRanges[Word.WdStoryType.wdEndnotesStory];
                            Word.Range myrange = endnoteRange.Duplicate;
                            myrange.Start = charpos;
                            myrange.End = charpos;
                            // myrange.Font.Italic = 0;
                            #region ChangingCaseforFields
                            Boolean bolTrackrevisions = false;
                            if (wDoc.TrackRevisions == true) { bolTrackrevisions = true; wDoc.TrackRevisions = false; }
                            endnoteRange.Fields.Add(myrange, ref fieldType, FieldText.Trim(), ref preserve).Select();
                            wDoc.Application.Selection.Font.Italic = 0;
                            if (bolTrackrevisions == true) { wDoc.TrackRevisions = true; }
                            #endregion
                       //     endnoteRange.Fields.Add(myrange, ref fieldType, FieldText, ref preserve);
                        }
                        else
                        {
                            if (storytype == "wdMainTextStory")
                            {
                                int charpos = wDoc.Application.Selection.Range.Start;
                                //   wDoc.Range(charpos, charpos).Font.Italic = 0;
                                #region ChangingCaseforFields
                                Boolean bolTrackrevisions = false;
                                if (wDoc.TrackRevisions == true) { bolTrackrevisions = true; wDoc.TrackRevisions = false; }
                                wDoc.Application.Selection.Range.Fields.Add(wDoc.Range(charpos, charpos), ref fieldType, FieldText.Trim(), ref preserve).Select();
                                wDoc.Application.Selection.Font.Italic = 0;
                                if (bolTrackrevisions == true) { wDoc.TrackRevisions = true; }
                                #endregion
                             //   wDoc.Application.Selection.Range.Fields.Add(wDoc.Range(charpos, charpos), ref fieldType, FieldText, ref preserve);
                            }
                        }
                        PreferredLegislation = legRetrun;
                        bVal = "next";
                        fullTextRange = activeDoc.StoryRanges[Word.WdStoryType.wdMainTextStory];
                        for(int loopcounter=1; loopcounter<=2; loopcounter++)
                        {
                            fullTextRange.Find.ClearFormatting();
                            fullTextRange.Find.Format = true;
                            fullTextRange.Find.Text = null;
                            fullTextRange.Find.Wrap = Word.WdFindWrap.wdFindContinue;
                            fullTextRange.Find.set_Style("‡text_legislation");
                            fullTextRange.Find.Execute();
                            fullTextRange.Collapse(Word.WdCollapseDirection.wdCollapseEnd);
                            fullTextRange.Find.Forward = true;
                        }
                        
                        frm = new CEGUtility.Legislation(fullTextRange.Text, PreferredLegislation, wDoc);
                        frm.ShowDialog();

                    }



                }
                 

        
            }
            

            catch (Exception ex)
            {
                MessageBox.Show("Unable to process body of the document");
            }

           

            try
            {
                if (activeDoc.Footnotes.Count > 0)
                {
                    PreferredLegislation = "";
                    fullTextRange = activeDoc.StoryRanges[Word.WdStoryType.wdFootnotesStory];
                    fullTextRange.Find.ClearFormatting();
                    fullTextRange.Find.Format = true;
                    fullTextRange.Find.Text = null;
                    fullTextRange.Find.Wrap = Word.WdFindWrap.wdFindStop;
                    fullTextRange.Find.set_Style("‡text_legislation");
                    string bVal="";
 again:
                    //fullTextRange.Find.Font.Shading.BackgroundPatternColor = Word.WdColor.wdColorBrightGreen;
                    while (fullTextRange.Find.Execute())//Used "While" To Pick up the two or more content in a footnote
                    {
                        bVal = getLegislationCitations(fullTextRange, wDoc);

                        if (bVal.ToLower() == "exit")
                        {
                            iExit = 1;
                            break;
                            Application.Exit();
                        }
                        else
                            if (bVal.ToLower() == "next")
                        {
                            fullTextRange.Find.Text = null;
                            fullTextRange.Collapse(Word.WdCollapseDirection.wdCollapseEnd);
                            fullTextRange.Find.Forward = true;
                        }
                        else
                           if (bVal.ToLower() == "previous")
                        {
                            fullTextRange.Find.Text = null;
                            fullTextRange.Collapse(Word.WdCollapseDirection.wdCollapseStart);
                            fullTextRange.Find.Forward = false;
                        }
                        else
                            if (bVal.ToLower() == "undo")
                        {
                            fullTextRange.Find.Text = null;

                            activeDoc.ActiveWindow.View.ShowFieldCodes = true;
                            int fccounter = fullTextRange.Fields.Count;
                            int fccounterprev = fullTextRange.Previous().Words[1].Fields.Count;

                            //************Delete the field**************
                            for (int i = fccounter; i >= 1; i--)
                            {
                                if (fullTextRange.Fields[1].Code.Text.Contains("Legis"))
                                {
                                    fullTextRange.Fields[1].Code.Text = "";
                                    fullTextRange.Fields[1].Unlink();
                                    wDoc.Application.Selection.Range.Font.Shading.BackgroundPatternColorIndex = Word.WdColorIndex.wdBrightGreen;
                                }

                            }

                            for (int i = fccounterprev; i >= 1; i--)
                            {
                                if (fullTextRange.Previous().Words[1].Fields[1].Code.Text.Contains("Legis"))
                                {
                                    fullTextRange.Previous().Words[1].Fields[1].Code.Text = "";
                                    fullTextRange.Previous().Words[1].Fields[1].Unlink();
                                    wDoc.Application.Selection.Range.Font.Shading.BackgroundPatternColorIndex = Word.WdColorIndex.wdBrightGreen;
                                }

                            }
                            activeDoc.ActiveWindow.View.ShowFieldCodes = false;
                            //************Delete the field**************



                            wDoc.Application.Selection.Range.Collapse(Word.WdCollapseDirection.wdCollapseEnd);
                            wDoc.Application.Selection.MoveRight();
                            fullTextRange.Start = wDoc.Application.Selection.Start;
                            fullTextRange.End = wDoc.Application.Selection.End;
                            fullTextRange.Select();
                            fullTextRange.Find.Forward = true;
                            fullTextRange.Find.set_Style("‡text_legislation");
                       //     fullTextRange.Find.Execute();
                        }
                    }
                    if (bVal == "previous" && fullTextRange.Find.Forward == false)
                    {

                        CEGUtility.Legislation frm;
                        do
                        {
                            MessageBox.Show("We are in the first legislation.");
                            frm = new CEGUtility.Legislation(fullTextRange.Text, PreferredLegislation, wDoc);
                            frm.ShowDialog();
                        } while (frm.userAction == 3);

                        if (frm.userAction == 0)
                        {
                            bVal = "next";
                            goto again;
                        }

                        if (frm.userAction == 2)
                        {
                            iExit = 1;
                            return true;
                           // Application.Exit();
                        }

                        if (frm.userAction == 4)
                        {
                            fullTextRange.Find.Text = null;
                            activeDoc.ActiveWindow.View.ShowFieldCodes = true;
                            int fccounter = fullTextRange.Fields.Count;
                            int fccounterprev = fullTextRange.Previous().Words[1].Fields.Count;

                            //************Delete the field**************
                            for (int i = fccounter; i >= 1; i--)
                            {
                                if (fullTextRange.Fields[1].Code.Text.Contains("Legis"))
                                {
                                    fullTextRange.Fields[1].Code.Text = "";
                                    fullTextRange.Fields[1].Unlink();
                                    wDoc.Application.Selection.Range.Font.Shading.BackgroundPatternColorIndex = Word.WdColorIndex.wdBrightGreen;
                                }

                            }

                            for (int i = fccounterprev; i >= 1; i--)
                            {
                                if (fullTextRange.Previous().Words[1].Fields[1].Code.Text.Contains("Legis"))
                                {
                                    fullTextRange.Previous().Words[1].Fields[1].Code.Text = "";
                                    fullTextRange.Previous().Words[1].Fields[1].Unlink();
                                    wDoc.Application.Selection.Range.Font.Shading.BackgroundPatternColorIndex = Word.WdColorIndex.wdBrightGreen;
                                }

                            }
                            activeDoc.ActiveWindow.View.ShowFieldCodes = false;
                            //************Delete the field**************


                            fullTextRange.Collapse(Word.WdCollapseDirection.wdCollapseEnd);
                            fullTextRange.Find.Forward = true;
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unable to process Footnotes");
            }

            try
            {
                if (activeDoc.Endnotes.Count > 0)
                {
                    PreferredLegislation = "";
                    fullTextRange = activeDoc.StoryRanges[Word.WdStoryType.wdEndnotesStory];
                    fullTextRange.Select();
                    fullTextRange.Find.ClearFormatting();
                    fullTextRange.Find.Format = true;
                    fullTextRange.Find.Text = null;
                    fullTextRange.Find.Wrap = Word.WdFindWrap.wdFindStop;
                    fullTextRange.Find.set_Style("‡text_legislation");
                    string bVal = "";
                    again:
                    //fullTextRange.Find.Font.Shading.BackgroundPatternColor = Word.WdColor.wdColorBrightGreen;
                    while (fullTextRange.Find.Execute())//Used "While" To Pick up the two or more content in a footnote
                    {
                        bVal = getLegislationCitations(fullTextRange, wDoc);




                        if (bVal.ToLower() == "exit")
                        {
                            iExit = 1;
                            break;
                            Application.Exit();
                        }
                        else
                            if (bVal.ToLower() == "next")
                        {
                            fullTextRange.Find.Text = null;
                            fullTextRange.Collapse(Word.WdCollapseDirection.wdCollapseEnd);
                            fullTextRange.Find.Forward = true;
                        }
                        else
                           if (bVal.ToLower() == "previous")
                        {
                            fullTextRange.Find.Text = null;
                            fullTextRange.Collapse(Word.WdCollapseDirection.wdCollapseStart);
                            fullTextRange.Find.Forward = false;
                        }
                        else
                        if (bVal.ToLower() == "undo")
                        {
                            fullTextRange.Find.Text = null;

                            activeDoc.ActiveWindow.View.ShowFieldCodes = true;
                            int fccounter = fullTextRange.Fields.Count;
                            int fccounterprev = fullTextRange.Previous().Words[1].Fields.Count;

                            //************Delete the field**************
                            for (int i = fccounter; i >= 1; i--)
                            {
                                if (fullTextRange.Fields[1].Code.Text.Contains("Legis"))
                                {
                                    fullTextRange.Fields[1].Code.Text = "";
                                    fullTextRange.Fields[1].Unlink();
                                    wDoc.Application.Selection.Range.Font.Shading.BackgroundPatternColorIndex = Word.WdColorIndex.wdBrightGreen;
                                }

                            }

                            for (int i = fccounterprev; i >= 1; i--)
                            {
                                if (fullTextRange.Previous().Words[1].Fields[1].Code.Text.Contains("Legis"))
                                {
                                    fullTextRange.Previous().Words[1].Fields[1].Code.Text = "";
                                    fullTextRange.Previous().Words[1].Fields[1].Unlink();
                                    wDoc.Application.Selection.Range.Font.Shading.BackgroundPatternColorIndex = Word.WdColorIndex.wdBrightGreen;
                                }

                            }
                            activeDoc.ActiveWindow.View.ShowFieldCodes = false;
                            //************Delete the field**************


                            fullTextRange.Collapse(Word.WdCollapseDirection.wdCollapseEnd);
                            fullTextRange.Find.Forward = true;
                        }
                    }
                    if (bVal == "previous" && fullTextRange.Find.Forward == false)
                    {

                        CEGUtility.Legislation frm;
                        do
                        {
                            MessageBox.Show("We are in the first legislation.");
                            frm = new CEGUtility.Legislation(fullTextRange.Text, PreferredLegislation, wDoc);
                            frm.ShowDialog();
                        } while (frm.userAction == 3);

                        if (frm.userAction == 0)
                        {
                            bVal = "next";
                            fullTextRange.Find.Text = null;
                            fullTextRange.Collapse(Word.WdCollapseDirection.wdCollapseEnd);
                            fullTextRange.Find.Forward = true;
                            goto again;
                        }

                        if (frm.userAction == 2)
                        {
                            iExit = 1;
                            return true;
                          //  Application.Exit();
                        }

                        if (frm.userAction == 4)
                        {
                            fullTextRange.Find.Text = null;
                            activeDoc.ActiveWindow.View.ShowFieldCodes = true;
                            int fccounter = fullTextRange.Fields.Count;
                            int fccounterprev = fullTextRange.Previous().Words[1].Fields.Count;

                            //************Delete the field**************
                            for (int i = fccounter; i >= 1; i--)
                            {
                                if (fullTextRange.Fields[1].Code.Text.Contains("Legis"))
                                {
                                    fullTextRange.Fields[1].Code.Text = "";
                                    fullTextRange.Fields[1].Unlink();
                                    wDoc.Application.Selection.Range.Font.Shading.BackgroundPatternColorIndex = Word.WdColorIndex.wdBrightGreen;
                                }

                            }

                            for (int i = fccounterprev; i >= 1; i--)
                            {
                                if (fullTextRange.Previous().Words[1].Fields[1].Code.Text.Contains("Legis"))
                                {
                                    fullTextRange.Previous().Words[1].Fields[1].Code.Text = "";
                                    fullTextRange.Previous().Words[1].Fields[1].Unlink();
                                    wDoc.Application.Selection.Range.Font.Shading.BackgroundPatternColorIndex = Word.WdColorIndex.wdBrightGreen;
                                }

                            }
                            activeDoc.ActiveWindow.View.ShowFieldCodes = false;
                            //************Delete the field**************


                        //    fullTextRange.Collapse(Word.WdCollapseDirection.wdCollapseEnd);
                            fullTextRange.Find.Text = null;
                            fullTextRange.Collapse(Word.WdCollapseDirection.wdCollapseEnd);
                            fullTextRange.Find.Forward = true;
                            goto again;
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unable to process Endnotes");
            }


            if (iExit == 1)
            {
                MessageBox.Show("Process Ignored");
                return true;
            }

            try
            { activeDoc.Application.ActiveWindow.ActivePane.Close(); }
            catch(Exception ex)
            { }

            activeDoc.Application.ActiveWindow.View.ShowRevisionsAndComments = true;
            activeDoc.Application.ActiveWindow.View.RevisionsView = Word.WdRevisionsView.wdRevisionsViewFinal;
            MessageBox.Show("Process completed successfully");
            return true;
        }
        public string getLegislationCitations(Word.Range fullTextRange, Word.Document wDoc)
        {
            var IgnoreList = new List<string> { "act", "bill", "regulation", "report", "(cth)", "(vic)" };
            string legRetrun;
            fullTextRange.Select();
            string selectedTerm = fullTextRange.Text;
            Console.WriteLine(selectedTerm);
            // changing the count from 40 to 15. 
            //if(selectedTerm.Length > 15)
            //{
            //    PreferredLegislation = selectedTerm;
            //    return true;
            //}

            string lowerSelectedTerm = selectedTerm.ToLower();
            if(Regex.IsMatch(lowerSelectedTerm, @"act|bill|regulation|report|\(sa\)|\(cth\)|\(vic\)|\(qld\)|\(uk\)|\(wa\)|\(act\)",RegexOptions.Singleline)) 
            {
                legRetrun = "";
                if (Regex.IsMatch(lowerSelectedTerm, "([0-9]{4})", RegexOptions.Singleline)==true && Regex.IsMatch(lowerSelectedTerm, @"(?<!(of\sthe\s))(act|bill|regulation|report|\(sa\)|\(cth\)|\(vic\)|\(qld\)|\(uk\)|\(wa\)|\(act\))", RegexOptions.Singleline)==true)
                {
                    PreferredLegislation = selectedTerm;
                  //  return true;
                }
                else
                {
                    if (Regex.IsMatch(lowerSelectedTerm, @"(?<!(of\sthe\s))(act|bill|regulation|report|\(sa\)|\(cth\)|\(vic\)|\(qld\)|\(uk\)|\(wa\)|\(act\))", RegexOptions.Singleline) == true)
                    {
                        // PreferredLegislation = selectedTerm;

                        #region 02-07-2018
                            if (Strings.InStr(1, PreferredLegislation.ToLower().Trim(), selectedTerm.ToLower().Trim(), CompareMethod.Text)==0)
                        { PreferredLegislation = selectedTerm; }
                        #endregion
                    }
                }
            }
            else
            {
                #region 03-05-2018
               string pattern= @"(\b(App[s ]?)\b |\b(Art[s ]?)\b |\b(Ch[s ]?)\b |\b(cl[l ]?)\b |\b(Div[s ]?)\b |\b(Item)\b |\b(O)\b |\b(Ord[s ]?)\b |\b(para[s ]?)\b |\b(Pt[s ]?)\b |\b(r[r ]?)\b |\b(reg[s ]?)\b |\b(s[s ]?)\b |\b(Sch[s ]?)\b |\b(Schedule[s ]?)\b |\b(Subclause[s ]?)\b |\b(subcl[l ]?)\b |\b(Subdiv[s ]?)\b |\b([Ss]ub[Dd]ivision[s ]?)\b |\b([Ss]ub[Ii]tem[s ]?)\b |\b(subpara[s ]?)\b |\b(subr[r ]?)\b |\b(subreg[s ]?)\b |\b(subs[s ]?)\b |\b(r[r ]?)\b)((([0-9\.]+)(\(?[A-Za-z]\)?)?(\sand\s)?){1,}|(([A-Z]+)(\sand\s)?){1,})?";
                
                Regex myregex = new Regex(pattern, RegexOptions.IgnoreCase);
               bool bolpresent = myregex.IsMatch(selectedTerm);

                if (bolpresent == true)
                {
                    if (PreferredLegislation.Split(new string[] { "|" }, StringSplitOptions.None)[0].Trim() != "")
                    {
                        PreferredLegislation = PreferredLegislation.Replace(PreferredLegislation.Split(new string[] { "|" }, StringSplitOptions.None)[0].Trim(), selectedTerm);
                    }
                    else
                    {
                        PreferredLegislation = selectedTerm + PreferredLegislation;
                    }
                }
                else
                {
                    if (PreferredLegislation.Split(new string[] { "|" }, StringSplitOptions.None)[0].Trim()!="")
                    { 
                         PreferredLegislation = PreferredLegislation.Replace(PreferredLegislation.Split(new string[] { "|" }, StringSplitOptions.None)[0].Trim(), selectedTerm);
                    }
                    else
                    {
                        PreferredLegislation = selectedTerm + PreferredLegislation;
                    }
                }
               
                #endregion
                
            }


            //for(int ig=0;ig<IgnoreList.Count;ig++)
            //{
            //    string lowerSelectedTerm = selectedTerm.ToLower();
            //    if(lowerSelectedTerm.Contains(IgnoreList[ig]))
            //    {
            //      PreferredLegislation = selectedTerm;
            //      return true;
            //    }
            //}
            //object myValue = InputBox(PreferredLegislation, "InputBox", "1");
            CEGUtility.Legislation frm = new CEGUtility.Legislation(selectedTerm, PreferredLegislation, wDoc);
            // CEGUtility.Form2 frm = new CEGUtility.Form2(selectedTerm, PreferredLegislation, wDoc);
            //frm.ShowDialog();
            //CEGUtility.Legis uc = new CEGUtility.Legis(selectedTerm, PreferredLegislation, wDoc);
            //uc.Dock = DockStyle.Fill;
            //frm.Controls.Add(uc);
            // oActApp.ActiveWindow.ScrollIntoView(oActApp.Selection.Range, True);
            //  wDoc.Application.ActiveWindow.ScrollIntoView(wDoc.Application.Selection.Range, true);

            frm.ShowDialog();
        //    Legislation.ShowWindow(frm.Handle, 8);

            // this.Controls.Add(uc);
            legRetrun = frm.legDetail;
           
            if (frm.userAction == 0)
            {
                return "next";
            }
            //1 for summit

            if (frm.userAction == 2)
            {
                return "exit";
            }

            if (frm.userAction == 3)
            {
                return "previous";
            }

            if (frm.userAction == 4)
            {
                wDoc.ActiveWindow.View.ShowFieldCodes = true;
                return "undo";
            }

            wDoc.Application.Selection.Range.Font.Shading.BackgroundPatternColorIndex = Word.WdColorIndex.wdYellow;

            string storytype = wDoc.Application.Selection.Range.StoryType.ToString();
            

            

            //Insert the legislation as FECode Text
            //Word.Field f;
            object fieldType = Word.WdFieldType.wdFieldEmpty;
            // String FieldText = "LegisRef: " + legRetrun.Split(new string[] { "|" }, StringSplitOptions.None)[0].Trim() + " LegisPubWork: " + legRetrun.Split(new string[] { "|" }, StringSplitOptions.None)[1].Trim() + " LegisJurisdiction: " + legRetrun.Split(new string[] { "|" }, StringSplitOptions.None)[2].Trim();

            String FieldText = "LegisRef: " + legRetrun.Split(new string[] { "|" }, StringSplitOptions.None)[0].Trim() + " LegisTitle: " + legRetrun.Split(new string[] { "|" }, StringSplitOptions.None)[1].Trim() + " LegisJurisdiction: " + legRetrun.Split(new string[] { "|" }, StringSplitOptions.None)[2].Trim();
            object preserve = false;
            

            if (storytype == "wdFootnotesStory")
            {
                
                int charpos = wDoc.StoryRanges[Word.WdStoryType.wdFootnotesStory].Application.Selection.Range.Start;
                Word.Range footnoteRange = wDoc.StoryRanges[Word.WdStoryType.wdFootnotesStory];
                Word.Range myrange = footnoteRange.Duplicate;
                myrange.Start = charpos;
                myrange.End = charpos;
              //  myrange.Font.Italic = 0;
                footnoteRange.Fields.Add(myrange, ref fieldType, FieldText, ref preserve);
            }
            if (storytype == "wdEndnotesStory")
            {
                int charpos = wDoc.StoryRanges[Word.WdStoryType.wdEndnotesStory].Application.Selection.Range.Start;
                Word.Range endnoteRange = wDoc.StoryRanges[Word.WdStoryType.wdEndnotesStory];
                Word.Range myrange = endnoteRange.Duplicate;
                myrange.Start = charpos;
                myrange.End = charpos;
                endnoteRange.Fields.Add(myrange, ref fieldType, FieldText, ref preserve);
            }
            else
            { if (storytype == "wdMainTextStory")
                {
                    int charpos = wDoc.Application.Selection.Range.Start;
                    wDoc.Application.Selection.Range.Fields.Add(wDoc.Range(charpos, charpos), ref fieldType, FieldText, ref preserve);
                }
            }
            PreferredLegislation = legRetrun;
            return "next";
        }
    }

    class clsBindingCombobox
    {
        public void bindingCombobox(Word.Document wDoc)
        {
            object objReplaceAll = Word.WdReplace.wdReplaceAll;
            object objMissing = System.Reflection.Missing.Value;
            Boolean bolTrackRevisonsPresent = false;
            if (wDoc.TrackRevisions == true)
            { bolTrackRevisonsPresent = true; wDoc.TrackRevisions = false; }
            wDoc.Application.Selection.Find.ClearFormatting();
            wDoc.Application.Selection.Find.set_Style("‡text_legislation");
            wDoc.Application.Selection.Find.Replacement.ClearFormatting();
            wDoc.Application.Selection.Find.Text = "";
            wDoc.Application.Selection.Find.Replacement.Text = @"<textleg>^&</textleg>";
            wDoc.Application.Selection.Find.Forward = true;
            wDoc.Application.Selection.Find.Wrap = Word.WdFindWrap.wdFindContinue;
            wDoc.Application.Selection.Find.Format = true;
            wDoc.Application.Selection.Find.MatchCase = false;
            wDoc.Application.Selection.Find.MatchWholeWord = false;
            wDoc.Application.Selection.Find.MatchWildcards = false;
            wDoc.Application.Selection.Find.MatchSoundsLike = false;
            wDoc.Application.Selection.Find.MatchAllWordForms = false;
            wDoc.Application.Selection.Find.Execute(ref objMissing, ref objMissing, ref objMissing,
                     ref objMissing, ref objMissing, ref objMissing, ref objMissing,
                     ref objMissing, ref objMissing, ref objMissing, ref objReplaceAll,
                     ref objMissing, ref objMissing, ref objMissing, ref objMissing);

            //Collecting Match Collections of 'Legislations' and storing it in a array

            string[] text_cases = Regex.Matches(wDoc.Content.Text, @"\<textleg\>(.*?)\<\/textleg\>").Cast<Match>().Select(m => m.Value).ToArray().ToList().Distinct().ToArray();

            //Collecting Match Collections of 'Legislations' and storing it in a array

            //Sorting Array
            Array.Sort(text_cases);

            #region BindingCombobox_Title
            int Counter;
            for (Counter=1; Counter<=text_cases.Length-1; Counter++)
            {
                string lyear;
                string llegisPubWork;
                string pattern;

          //      Regex myregex = new Regex(pattern, RegexOptions.IgnoreCase);
                MatchCollection matches = myregex.Matches(text_cases[Counter].ToString());
                if (matches.Count > 0)
                {
                    lyear = matches[matches.Count - 1].Value;
                    llegisPubWork = text_cases[Counter].ToString();
                }
                else
                { lyear = ""; llegisPubWork = text_cases[Counter].ToString(); }
                pattern = @"(of)( )?(the)";
                myregex = new Regex(pattern, RegexOptions.IgnoreCase);
                Boolean bolpresent = myregex.IsMatch(text_cases[Counter].ToString());
            }
            #endregion 




            wDoc.Application.Selection.Find.ClearFormatting();
            wDoc.Application.Selection.Find.Replacement.ClearFormatting();
            wDoc.Application.Selection.Find.Text = @"\<textleg\>(*)\<\/textleg\>";
            wDoc.Application.Selection.Find.Replacement.Text = @"\1";
            wDoc.Application.Selection.Find.Forward = true;
            wDoc.Application.Selection.Find.Wrap = Word.WdFindWrap.wdFindContinue;
            wDoc.Application.Selection.Find.Format = true;
            wDoc.Application.Selection.Find.MatchCase = false;
            wDoc.Application.Selection.Find.MatchWholeWord = false;
            wDoc.Application.Selection.Find.MatchWildcards = true;
            wDoc.Application.Selection.Find.MatchSoundsLike = false;
            wDoc.Application.Selection.Find.MatchAllWordForms = false;
            wDoc.Application.Selection.Find.Execute(ref objMissing, ref objMissing, ref objMissing,
                     ref objMissing, ref objMissing, ref objMissing, ref objMissing,
                     ref objMissing, ref objMissing, ref objMissing, ref objReplaceAll,
                     ref objMissing, ref objMissing, ref objMissing, ref objMissing);


            if (bolTrackRevisonsPresent == true)
            { wDoc.TrackRevisions = true; }

        }
    }
}
