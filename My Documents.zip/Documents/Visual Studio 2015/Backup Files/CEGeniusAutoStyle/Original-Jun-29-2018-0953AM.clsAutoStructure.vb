Imports Microsoft.Office.Interop.Word
Imports System.Text.RegularExpressions
Imports System.IO
Imports System.Collections
Imports System.Linq
Imports System.Runtime.InteropServices

Public Class clsAutoStructure
    <ComVisible(True)>
    Const sSecStylesInfo As String = "LWW_StylesInfo"
    Private Const sTitleTag As String = "title"
    Private Const sLabelTag As String = "label"
    Private Const sXTag As String = "x"
    Private Const sTagTypeAttribute As String = "tagtype"
    Private Const sListItemTag As String = "list-item"
    Private Const sPTag As String = "p"
    Private Const sCitationTag As String = "citation"
    Private Const sFigTag As String = "fig"
    Private Const sTabTag As String = "table"
    Private Const sFSTag As String = "formalstatement"
    Private Const sFloatsSourceTag As String = "source"
    Private Const sRefTag As String = "ref"
    Private Const sAffTag As String = "aff"
    Private Const sCorrAffTag As String = "aff_CorresAuthorAff"
    Private Const sArtTitleTag As String = "article-title"
    Private Const sKwdTag As String = "kwd"
    Private Const sAuthorTag As String = "contrib"
    Private Const sRunHeadTag As String = "run-head"
    Private Const sAuthorInfoTag As String = "author-info"
    Private Const sSecAutoStyleKeys As String = "AutoStyleKeys"
    Private Const sPrefixNoKey As String = "([xvi0-9\.\t\s]*)"
    Private Const sTelPattern As String = "((tel|phone|telephone)[\s\:\.]*(no|number)?[\s\:\.]+[0-9\+\-\(\) ]*)"
    Private Const sFaxPattern As String = "((fax)[\s\:\.]*(no|number)?[\s\:\.]+[0-9\+\-\(\) ]*)"
    Private Const sMailPattern As String = "((((e)?\s*(\.|\-)*\s*mail)?[\s\:]+([A-Z0-9._%+-]+\@[A-Z0-9.-]+(\.[A-Z]{2,6})+))|([A-Z0-9._%+-]+\@[A-Z0-9.-]+(\.[A-Z]{2,6})+))"
    Private Const sHeadElements As String = "Article||SectionHead||ArticleTitle||ShortTitle||SeriesTitle||Collaboration||Authors||surname||suffix||Position||OnBehalfOf||author_jobtitle||Affiliation||CorrespondingAuthor||email||SourceRef||Accepted||fn_related||fn_moreinfo||MoreInfoWeb||SeriesInfo||Biog||Standfirst||AbstractTitle||Abstract||Topic||WebExtra||supp-file||supp-caption||Received||Revised||fn-online||fn_webonly||KeywordsDefault||TrialRegNo"
    Private Const sFNElements As String = "fn_conflict||fn_ethics||fn_provenance||fn_moreinfo||fn_contributor||fn_webonly"
    Private Const sBodyElements As String = "SectionA||SectionB||SectionC||ParaHead||Paragraph||ParaCont||email||URL||Lista||Listb||List3||ListPara||FlushQuote||IndentQuote||Pullout Quote||QuoteRef||Logos||ParaNoindent||DsiplayQuote||BibItem||Footnote||citation"
    Private Const sBackElements As String = "Acknowledgements||Participators||fn_funding||fn_conflict||fn_ethics||Miscellanenous||References||Citeline||ref text||fn_patient||fn_contributor||fn_provenance||Appendix||DisplayGraphics||FigCaption||Credit||BoxStart1/SumPtsBox||BoxStart2/OrdinaryBox||BoxStart3/WTSAddsBox||BoxStart4/QuestionsBox||BoxFootnote||BoxEnd||TableCaption||TableTitle||TableBody||TableHeader||TableSubHead||TableFootnote||TextBoxCaption||AuthorQuery||DisplayMath||EquationText||DisplayTable||Furtherreading"
    Private Const sFloatsElements As String = "DisplayGraphics||FigCaption||Credit||BoxStart1/SumPtsBox||BoxStart2/OrdinaryBox||BoxStart3/WTSAddsBox||BoxStart4/QuestionsBox||BoxFootnote||BoxEnd||TableCaption||TableTitle||TableBody||TableHeader||TableSubHead||TableFootnote||TextBoxCaption||AuthorQuery||DisplayMath||EquationText||DisplayTable||Furtherreading"
    Private Declare Unicode Function GetPrivateProfileString Lib "kernel32" Alias "GetPrivateProfileStringW" (ByVal lpApplicationName As String, ByVal lpKeyName As String, ByVal lpDefault As String, ByVal lpReturnedString As String, ByVal nSize As Int32, ByVal lpFileName As String) As Int32
    Public Const URI As String = "AS"
    '' Public Const URI As String = "http://www.w3.org/2013/XSL/json"
    Dim bAddCapsInfo As Boolean


    '####### General #################
    Dim SplitSinglePipe As Char() = New Char() {"|"}
    Dim ParaInfoCollection As Hashtable
    Dim HeadRng As Range, BodyRng As Range, BackRng As Range, FloatRng As Range
    Dim MiscellaneousKey As String
    Dim BoxMiscKey As String
    Dim TempStr As String, TempRng As Range, TempVar() As String
    Dim ConfidenceVal As Integer
    Dim bAddParaInfo As Boolean
    Dim bAddNextTag As Boolean
    Dim bAddLastTag As Boolean
    Dim sLastTagInfo As String
    Dim sNextTagInfo As String
    Dim LastSectionInfo As String

    '########### For Apply style ########
    Private ApplyPunStyleErrorInfo As String
    Private ReferencesRng As Range
    Private sWebInputXMLInfo As String

    '############ Collect from the MetaXML file ########
    Private JourName4mXML As String
    Private PubName4mXML As String
    Private ArticleType4mXML As String
    Private RunHead4mXML As String = ""
    Private ArticleTitle4mXML As String
    Private ArticleDOI4mXML As String
    Private CorrAuListInfo4mXML As String
    Private CorrespondenceNames4mXML As String
    Private CorrespondenceMails4mXML As String
    Private CorrespondenceAff4mXML As String
    Private CorrAuEmailList4mXML As String
    Private AuthorsListInfo4mXML As String
    Private AuthorsNames4mXML As String = ""
    Private AuthorsEMailList4mXML As String
    Private Affiliation4mXML As String
    Private KeywordsList4mXML As String
    Private AbstractInfo4mXML As String
    Private Acknowledgement4mXML As String
    '######## Footnote information #######    
    Private CollaboratorsData4XML As String
    Private ContributorInfo4mXML As String
    Private FundersData4mXML As String
    Private CompInterestsData4mXML As String
    Private PatientconsentData4XML As String
    Private EthicsData4mXML As String
    Private ProvenanceData4mXML As String
    Private DataSharing4mXML As String
    Private RevisionInfo4mXML As String
    Private SupplementInfo4mXML As String
    Private SectionHeadInfo4mXML As String
    '######## History information ########
    Private AcceptedDateInfo4mXML As String
    Private ReceivedDateInfo4mXML As String
    Private RevisedDateInfo4mXML As String
    Private OrgFileNameInfo4mXML As String
    '###########################################################
    Dim shtList1LeftInfo As Short
    Dim shtList2LeftInfo As Short
    Dim shtList3LeftInfo As Short

    Dim P As Paragraph : Dim PRng As Range
    Dim AckFound As Boolean, AppFound As Boolean, Miscellaneous As Boolean, bBoxStartFound As Boolean
    Dim sExactDeleteKey As String
    Dim sOptionalDeleteKey As String

    '########## Head Variables #########
    Dim TitleKey, RunHeadKey, PubTypeKey, SubTitleKey, CorrNameskey, CorrAuthorsKey, CorrMailkey, AuthorNamesKey, AuthorsKey, AuthorsMailKey, AffKey, AbstractKey, AbstractSectionKey, KeywordKey, Pacswordkey, AbbrevKey, AddressKey, CityKey, StateKey, CountryKey As String
    Dim ArtTitleFound As Boolean, RunHeadFound As Boolean, PubTypeFound As Boolean, CorrAuFound As Boolean, CorrMailFound As Boolean, AuthorFound As Boolean, AuthorsMailFound As Boolean, AffFound As Boolean, AbsFound As Boolean, KeywordFound As Boolean
    Dim WordCntKey As String, WordCntFound As Boolean
    Dim AllTypeAffKey As String
    Dim DedicateKey As String

    '######### Body Variables ##########
    Dim Sec1Key As String, Sec2Key As String, Sec3Key As String, Ackkey As String, Appkey As String
    Dim SecFound As Boolean, Sec1Found As Boolean, Sec2Found As Boolean, Sec3Found As Boolean

    '######### Tail Variables ##########
    Dim RefTitle As Boolean

    '######### Floats Variables ##########
    Dim FigKey As String, TabKey As String, FsKey As String
    Dim FloatsSourceKey As String
    Dim TabFound As Boolean, FigFound As Boolean
    Dim TabFNCnt As Integer = 0, FigFNCnt As Integer = 0
    Dim TabIDCnt As Integer = 0, FigIDCnt As Integer = 0
    Dim FSIDCnt As Integer = 0
    Dim frmAuto As New frmAutoStyles()
    Private sAutoStructuresXSDPath As String
    Public bCallManualStyle As Boolean

    Public Function IsAutoStyling(ByVal sJounalConfig As String, ByVal sPubName As String, ByVal sJName As String, ByVal sArtType As String) As Boolean
        Dim sTempShrtType As String = String.Empty
        Try
            If String.IsNullOrWhiteSpace(sPubName) = False AndAlso String.IsNullOrWhiteSpace(sJName) = False AndAlso String.IsNullOrWhiteSpace(sArtType) = False Then
                Dim sTemp1 As String = String.Empty
                sTemp1 = ReadINI(sJounalConfig, sPubName.ToUpper & "@" & sJName.ToUpper, sKeyAutoStylingArtType, String.Empty, False)
                If String.IsNullOrWhiteSpace(sTemp1) = True Then sTemp1 = ReadINI(sJounalConfig, sPubName.ToUpper, sKeyAutoStylingArtType, String.Empty, False)
                If String.IsNullOrWhiteSpace(sTemp1) = False Then
                    '## sTemp1 = Replace(sTemp1, "&", "\&") : sTemp1 = Replace(sTemp1, "-", "\-") : sTemp1 = Replace(sTemp1, "|", "(s)?|")
                    sTemp1 = Regex.Replace(sTemp1, "(^\(|\)$)", String.Empty).ToLower
                    sTemp1 = Regex.Escape(sTemp1) : sTemp1 = sTemp1.Replace("s\|", "(s)?\|")
                    sTemp1 = sTemp1.Replace("-", "[\-\s]*") : sTemp1 = "(\|" & sTemp1.Replace("\|", "\||\|") & "\|)"
                    'If sTemp1.StartsWith("\(") = True Then sTemp1 = "(\|" & sTemp1.Substring(2)
                    'If sTemp1.EndsWith("\)") = True Then sTemp1 = sTemp1.Substring(0, Len(sTemp1) - 2) & "\|)"
                    If Regex.IsMatch("|" & sArtType & "|", sTemp1, RegexOptions.IgnoreCase) = True Then
                        Return True
                        Exit Function
                    End If
                End If
                Return False
            Else
                Return False
            End If
        Catch ex As Exception
            Throw New Exception(ex.Message)
        End Try
    End Function

    Public Function ToCallAutoStyling(ByVal PreProcessDoc As Document, ByVal PubName As String, ByVal RHead As String, ByVal JName As String, ByVal AID As String, ByVal ArtDOI As String, ByVal Arttitle As String, ByVal ArtType As String, ByVal CorrAu As String, ByVal CorrMail As String, ByVal AuList As String, ByVal JConfigPath As String, ByVal CEGeniusTemplatePath As String, ByVal sBackupDocName As String) As Boolean
        'If Not (frmAuto Is Nothing) Then Call frmAuto.Dispose()
        Dim sStyleTemplatePath As String = String.Empty : Dim sBackupDocFullPath As String = String.Empty
        bCallManualStyle = False : ToCallAutoStyling = False : LoadForm = False
        Dim sTempFullPath As String = String.Empty
        Dim sStartTime As String = Now.ToString


        Try
            WordApp = Nothing : WordDoc = Nothing
            WordApp = PreProcessDoc.Application : WordDoc = PreProcessDoc : sJournalConfigPath = JConfigPath
            sTempFullPath = Path.Combine(Path.GetTempPath(), PreProcessDoc.Name)
            '################# Show normal view #####################################
            If WordApp.ActiveWindow.View.SplitSpecial = WdSpecialPane.wdPaneNone Then
                WordApp.ActiveWindow.ActivePane.View.Type = WdViewType.wdNormalView
            Else
                WordApp.ActiveWindow.View.Type = WdViewType.wdNormalView
            End If
            WordApp.ActiveWindow.ActivePane.View.Zoom.Percentage = 100
            If WordApp.ActiveWindow.StyleAreaWidth = 0 Then WordApp.ActiveWindow.StyleAreaWidth = 1

            sBackupDocFullPath = Path.Combine(Path.Combine(PreProcessDoc.Path, "Backup"), sBackupDocName)
            If File.Exists(sBackupDocFullPath) = False Then
                Dim sBackUpDir As String = Path.Combine(PreProcessDoc.Path, "Backup")
                If Directory.Exists(sBackUpDir) = False Then Directory.CreateDirectory(sBackUpDir)
                File.Copy(PreProcessDoc.FullName, sBackupDocFullPath)
            End If

            '' sAutoStructuresXSDPath = Path.Combine(Path.GetDirectoryName(JConfigPath), "autostructure.xsd")
            sAutoStructuresXSDPath = Path.Combine(Path.GetDirectoryName(JConfigPath), "autostructure2013.xsd")
            StylesConfPath = String.Empty : sStyleTemplatePath = String.Empty  'StylesConfPath = "C:\CEGenius 3.0\Main\Styles\ANE.ini"
            If Directory.Exists(CEGeniusTemplatePath) = True Then
                StylesConfPath = Path.Combine(CEGeniusTemplatePath, JName & ".ini")
                If File.Exists(StylesConfPath) = False Then StylesConfPath = String.Empty Else StylesConfPath = JName & ".ini"
            Else
                MsgBox("CEGenius style config path missing..." & vbCr & "Path : " & CEGeniusTemplatePath, MsgBoxStyle.Information + vbOKOnly, sMsgtitle)
                Exit Function
            End If
            If String.IsNullOrWhiteSpace(StylesConfPath) = True Then StylesConfPath = AuoStructureReadINI(JConfigPath, PubName & "@" & JName, sKeyStylesINI, String.Empty, False)
            If String.IsNullOrWhiteSpace(sStyleTemplatePath) = True Then sStyleTemplatePath = AuoStructureReadINI(JConfigPath, PubName & "@" & JName, sKeyTemplateName, String.Empty, False)
            If String.IsNullOrWhiteSpace(StylesConfPath) = True Then
                StylesConfPath = AuoStructureReadINI(JConfigPath, PubName, sKeyStylesINI, "CE Genius Journals Styles.ini", False)
            End If
            If String.IsNullOrWhiteSpace(sStyleTemplatePath) = True Then
                sStyleTemplatePath = AuoStructureReadINI(JConfigPath, PubName, sKeyTemplateName, "CE Genius Journals Styles.dot", False)
            End If
            If Directory.Exists(CEGeniusTemplatePath) = True Then
                StylesConfPath = Path.Combine(CEGeniusTemplatePath, StylesConfPath)
                sStyleTemplatePath = Path.Combine(CEGeniusTemplatePath, sStyleTemplatePath)
            Else
                MsgBox("CEGenius style config path missing..." & vbCr & "Path : " & CEGeniusTemplatePath, MsgBoxStyle.Information + vbOKOnly, sMsgtitle)
                Exit Function
            End If
            If File.Exists(StylesConfPath) = False OrElse File.Exists(sStyleTemplatePath) = False Then
                Throw New Exception("Unable to find the journal styles config file path..." & vbCr & "Path : " & StylesConfPath)
                Exit Function
            End If
            '####LoadForm = False : frmAuto = New frmAutoStyles(PubName, JName, JConfigPath, StylesConfPath)
            frmAuto.StylesConfPath = StylesConfPath
            '########## Set all values to the private variables ##############
            PubName4mXML = PubName : JourName4mXML = JName : RunHead4mXML = RHead : ArticleDOI4mXML = ArtDOI : ArticleType4mXML = ArtType
            ArticleTitle4mXML = Arttitle : CorrAuListInfo4mXML = CorrAu : CorrAuEmailList4mXML = CorrMail : AuthorsListInfo4mXML = AuList
            'ReceivedDateInfo4mXML = RecD : RevisedDateInfo4mXML = RevD : AcceptedDateInfo4mXML = AccD


            '############## Basic clean up ###################################
            Dim fChanged As Boolean
            Call ConvertsList2Text(PreProcessDoc) : Call ToRemoveBookmarks(PreProcessDoc, "bodystart")
            'Do : fChanged = CollapseText(PreProcessDoc, "  ", " ") : Loop Until Not fChanged
            Do : fChanged = CollapseText(PreProcessDoc, "^b", "^p") : Loop Until Not fChanged
            Do : fChanged = CollapseText(PreProcessDoc, "^n", "^p") : Loop Until Not fChanged
            Do : fChanged = CollapseText(PreProcessDoc, "^m", "^p") : Loop Until Not fChanged
            Do : fChanged = CollapseText(PreProcessDoc, "^p^p", "^p") : Loop Until Not fChanged
            Do : fChanged = CollapseText(PreProcessDoc, " ^p", "^p") : Loop Until Not fChanged
            Do : fChanged = CollapseText(PreProcessDoc, "^p ", "^p") : Loop Until Not fChanged
            Do : fChanged = CollapseText(PreProcessDoc, "^t^t ", "^t") : Loop Until Not fChanged
            Do : fChanged = CollapseText(PreProcessDoc, "^p^t", "^p") : Loop Until Not fChanged
            Do : fChanged = CollapseText(PreProcessDoc, "^t^p", "^p") : Loop Until Not fChanged
            '########## Identify document elements ###############
            Call ToIdentifyDocumentPart(PreProcessDoc) : PreProcessDoc.ActiveWindow.View.ShowXMLMarkup = False
            ExpandInfo = "Tables||Figures||Miscellaneous" : Call ToMoveCaptionsForAutoStructure()
            ExpandInfo = "Frontmatter||Abstract" : Call ToTagHead(PreProcessDoc)
            ExpandInfo = "Main text||text" : Call ToTagBody(PreProcessDoc)
            ExpandInfo = "Endmatter||Miscellaneous" : Call ToTagTail(PreProcessDoc)
            ExpandInfo = "Tables||Figures||Miscellaneous" : Call ToTagFloats(PreProcessDoc)
            Call ToCopyStyle(sStyleTemplatePath, PreProcessDoc)
            Call StyleOverrides(StylesConfPath, PreProcessDoc)
            Call ToApplyPubStyle(PubName, sJournalConfigPath, PreProcessDoc, False)
            Do : fChanged = CollapseText(PreProcessDoc, "^p^p", "^p") : Loop Until Not fChanged
            ToCallAutoStyling = True

        Catch ex As Exception
            Call ToLoadSchema(PreProcessDoc, True)
            Call ToRevertDocument(PreProcessDoc, sBackupDocFullPath, sTempFullPath)
            If vbYes = MsgBox("Unable to complete the auto styling process..." & vbCr & vbCr & "Do you want to run the manual styling?", vbYesNo + MsgBoxStyle.Question, sMsgtitle) Then
                bCallManualStyle = True
            Else
                ToCallAutoStyling = False
            End If
            Call ToSendMail(sTempFullPath, False, ex.Message, sStartTime)
        Finally
            If ToCallAutoStyling = True Then
                '####### Take copy of styled document to temp folder for sending mail ########
                '##### Dim oMailAttachDoc As Document = WordApp.Documents.Add(Visible:=False)
                '##### oMailAttachDoc.Range.FormattedText = PreProcessDoc.Range
                '##### Call oMailAttachDoc.SaveAs(sTempPath, AddToRecentFiles:=False)
                '##### Call File.Copy(PreProcessDoc.FullName, sTempPath, True)
                Dim frmUR As New frmUserResponse : frmUR.BringToFront()
                If frmUR.ShowDialog() = System.Windows.Forms.DialogResult.Yes Then
                    PreProcessDoc.Save()
                    Call File.Copy(PreProcessDoc.FullName, sTempFullPath, True)
                    Call ToSendMail(sTempFullPath, True, String.Empty, sStartTime, frmUR.sRevertReason)
                Else
                    Call ToRevertDocument(PreProcessDoc, sBackupDocFullPath, sTempFullPath)
                    Call ToSendMail(sTempFullPath, False, String.Empty, sStartTime, frmUR.sRevertReason)
                    bCallManualStyle = True
                End If
            End If
        End Try
    End Function

    Private Function ToRevertDocument(ByVal RevDoc As Document, ByVal BackUpFileFullName As String, Optional ByVal sTempFileFullPath As String = "") As Boolean
        On Error Resume Next
        If File.Exists(BackUpFileFullName) = True AndAlso String.IsNullOrWhiteSpace(sTempFileFullPath) = False AndAlso Directory.Exists(Path.GetDirectoryName(sTempFileFullPath)) = True Then
            RevDoc.Save()
            Call File.Copy(RevDoc.FullName, sTempFileFullPath)
        End If
        If File.Exists(BackUpFileFullName) = True Then
            RevDoc.Application.ScreenUpdating = False
            RevDoc.Range.Text = String.Empty
            RevDoc.Range.InsertFile(FileName:=BackUpFileFullName, ConfirmConversions:=False)
            RevDoc.Save() : RevDoc.Application.ScreenUpdating = True
        End If
    End Function

    Private Function ToSendMail(ByVal sAttachDocPath As String, ByVal bIsAutoStyleSuccess As Boolean, ByVal sErrorMsg As String, ByVal sStartTime As String, Optional ByVal sRevertReason As String = "") As Boolean
        Const sKeyMailCC As String = "MailCC"
        Try
            If File.Exists(sAttachDocPath) = True Then
                Dim MailObj As New CDO.Message
                Dim MailUserName As String
                Dim MailToCC As String = ReadINI(sJournalConfigPath, sSecMiscellaneousAutoStyleInfo, sKeyMailCC, String.Empty, False)
                MailObj.Configuration.Fields(CDO.CdoConfiguration.cdoSMTPServer).Value = "zimbra.newgen.co"
                MailObj.Configuration.Fields(CDO.CdoConfiguration.cdoSMTPConnectionTimeout).Value = 50
                MailObj.Configuration.Fields(CDO.CdoConfiguration.cdoSendUsingMethod).Value = CDO.CdoPostUsing.cdoPostUsingPort
                MailObj.Configuration.Fields.Update()
                MailObj.From = "no-reply@newgen.co"
                MailUserName = "Hi"
                MailObj.To = "hariharan@newgen.co"
                If String.IsNullOrWhiteSpace(MailToCC) = False AndAlso MailToCC.Contains("@") Then MailObj.BCC = MailToCC
                MailObj.Subject = PubName4mXML & " autostructure"

                '########### Get User, OS and Word application information ############
                Dim sBodyMail As String = "<p><b>Username : </b>" & Environment.UserName & "</p><p><b>Time : </b>" & Now() & "</p>" &
                                          "<p><b>OS Info :</b> " & Environment.OSVersion.ToString() & "</p>"
                If Not WordApp Is Nothing Then sBodyMail = sBodyMail & "<p><b>Word Version:</b> " & WordApp.Build & "</p>"
                sBodyMail = sBodyMail & "<p>-----------------------------------------</p>"
                sBodyMail = sBodyMail & "<br/><p><b>Pubname :</b>" & PubName4mXML & "</p>" &
                                              "<p><b>Journal name :</b>" & JourName4mXML & "</p>" &
                                              "<p><b>Article ID :</b>" & ArtID & "</p>" &
                                              "<p><b>Article DOI  :</b>" & ArticleDOI4mXML & "</p>" &
                                              "<p><b>Article title :</b>" & ArticleTitle4mXML & "</p>" &
                                              "<p><b>Document path :</b>" & sAttachDocPath & "</p>" &
                                              "<p><b>Start time :</b>" & sStartTime & "</p>" &
                                              "<p><b>End time :</b>" & Now.ToString & "</p>"
                Select Case bIsAutoStyleSuccess
                    Case True : sBodyMail = sBodyMail & "<br/><br/><p style='color:green'>User accept the auto styling process.</p>"
                    Case False : sBodyMail = sBodyMail & "<br/><br/><p style='color:red'>User rejects the auto styling process.</p>"
                End Select
                If String.IsNullOrWhiteSpace(sErrorMsg) = False Then sBodyMail = sBodyMail & "<br/><br/><p><b>Error :</b> " & sErrorMsg & "</p>"
                If String.IsNullOrWhiteSpace(sRevertReason) = False Then sBodyMail = sBodyMail & "<br/><br/><p><b>User comments :</b> " & sRevertReason & "</p>"
                MailObj.HTMLBody = sBodyMail
                Call MailObj.AddAttachment(sAttachDocPath)
                MailObj.Send()
            End If
        Catch ex As Exception
            ex.Data.Clear()
        End Try
    End Function





    ''' <summary>To tag head part elements (i.e. title, sub title, run head, etc.,)</summary>
    ''' <param name="oWordDoc">Which document we need to style it.</param>
    ''' <returns>It return the boolean status of process</returns>
    ''' <remarks></remarks>
    Private Function ToTagHead(ByVal oWordDoc As Document) As Boolean
        Dim I As Integer, PCnt As Integer
        HeadRng = ToGetNodeRange(oWordDoc, oWordDoc.Range, "front")
        If HeadRng Is Nothing Then Exit Function

        '########## Reset module variables ###########
        sLastTagInfo = "" : sNextTagInfo = "" : PRng = Nothing : P = Nothing : TempRng = Nothing : TempStr = "" : AuthorNamesKey = "" : CorrNameskey = ""

        '########## Read & Generate Patterns ###############
        TitleKey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "TitlePattern", "", True)
        If String.IsNullOrEmpty(ArticleTitle4mXML) = False Then TitleKey = "(" & TitleKey & "|" & StringToRegPattern(AutoStructureStringToRegPattern(ArticleTitle4mXML)) & ")"

        SubTitleKey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "SubTitlePattern", "")

        RunHeadKey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "RunHeadPattern", "", True)
        If String.IsNullOrEmpty(RunHead4mXML) = False Then RunHeadKey = "(" & RunHeadKey & "|" & StringToRegPattern(AutoStructureStringToRegPattern(RunHead4mXML)) & ")"

        PubTypeKey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "ArtTypePattern", "", True)
        If String.IsNullOrEmpty(ArticleType4mXML) = False Then PubTypeKey = "(" & PubTypeKey & "|" & StringToRegPattern(AutoStructureStringToRegPattern(ArticleType4mXML)) & ")"

        CorrMailkey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "CorrAuthorMailPattern", "", True)
        If String.IsNullOrEmpty(CorrAuEmailList4mXML) = False Then CorrMailkey = "(" & CorrMailkey & "|" & StringToRegPattern(AutoStructureStringToRegPattern(CorrAuEmailList4mXML)) & ")"

        AuthorsKey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "AuthorDegreesPattern", "", True, True)
        CorrAuthorsKey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "CorrAuthorPattern", "", True, True)


        Select Case True
            'Case String.IsNullOrEmpty(AuthorsListInfo4mXML) = False And String.IsNullOrEmpty(CorrAuListInfo4mXML) = False : AuthorNamesKey = AutoStructureStringToRegPattern(AuthorsListInfo4mXML & "|" & CorrAuListInfo4mXML)
            Case String.IsNullOrEmpty(AuthorsListInfo4mXML) = False : AuthorNamesKey = AutoStructureStringToRegPattern(AuthorsListInfo4mXML)
            Case String.IsNullOrEmpty(CorrAuListInfo4mXML) = False : AuthorNamesKey = AutoStructureStringToRegPattern(CorrAuListInfo4mXML)
            Case True : AuthorNamesKey = "(###)"
        End Select

        Select Case True
            Case String.IsNullOrEmpty(CorrAuListInfo4mXML) = False : CorrNameskey = AutoStructureStringToRegPattern(CorrAuListInfo4mXML)
            Case String.IsNullOrEmpty(AuthorsListInfo4mXML) = False : CorrNameskey = AutoStructureStringToRegPattern(AuthorsListInfo4mXML)
            Case True : CorrNameskey = "(###)"
        End Select


        AuthorsMailKey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "AuthorMailPattern", "", True)
        If String.IsNullOrEmpty(AuthorsEMailList4mXML) = False Then AuthorsMailKey = "(" & AuthorsMailKey & "|" & StringToRegPattern(AutoStructureStringToRegPattern(AuthorsEMailList4mXML)) & ")"

        AffKey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "AffPattern", "", True)
        If String.IsNullOrEmpty(Affiliation4mXML) = False Then AffKey = "(" & AffKey & "|" & StringToRegPattern(AutoStructureStringToRegPattern(Affiliation4mXML)) & ")"

        AbstractKey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "AbstractPattern", "", True)
        AbstractSectionKey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "AbstractSecPattern", "", True)
        KeywordKey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "KeywordPattern", "", True)
        Pacswordkey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "PacsPattern", "", True)
        AbbrevKey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "AbbrevPattern", "", True)
        MiscellaneousKey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "MiscPattern", "", True)
        BoxMiscKey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "BoxPattern", "", True, False)
        AddressKey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "AddressPattern", "", True, True)
        StateKey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "StatePattern", "", True, True)
        CountryKey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "CountryPattern", "", True, True)
        DedicateKey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "DedicatePattern", "", True, True)
        sExactDeleteKey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "ColorTextExactPattern", "", True)
        sOptionalDeleteKey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "ColorTextInRngPattern", "", True)
        WordCntKey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "WordCntPattern", "", True, True) : WordCntFound = False

        For I = 1 To 4 : CityKey = CityKey & AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "CityPattern" & I, "", True) & "|" : Next
        If Right(CityKey, 1) = "|" Then CityKey = Mid(CityKey, 1, Len(CityKey) - 1)
        CityKey = "\b(" & CityKey & "[\.\,\:\; ]*)\b"
        AllTypeAffKey = "(" & AffKey & "|" & AddressKey & "|" & CityKey & "|" & StateKey & "|" & CountryKey & ")"

        Try
            '######## Run on section headings ##########
            Call SplitRunOnSections(oWordDoc, HeadRng, MiscellaneousKey)
            PCnt = HeadRng.Paragraphs.Count
            For I = PCnt To 1 Step -1
                If HeadRng.Paragraphs.Item(1).Range.Information(WdInformation.wdWithInTable) = True Then GoTo NxtI
                If HeadRng.Paragraphs.Item(I).Range.Text <> Chr(13) Then
                    PRng = HeadRng.Paragraphs.Item(I).Range.Duplicate
                    PRng.SetRange(HeadRng.Paragraphs.Item(I).Range.Start, HeadRng.Paragraphs.Item(I).Range.End - 1)
                    TempStr = TrimString(PRng.Text, True)
                    If StringWithRegMatchesReturnMatchVal(PRng.Text, AbstractSectionKey, True, False, True) <> "" Then
                        TempStr = StringWithRegMatchesReturnMatchVal(PRng.Text, AbstractSectionKey, True, False, True)
                        If TempStr.Length < 3 Then GoTo NxtI
                        If PRng.ComputeStatistics(WdStatistic.wdStatisticLines) > 1 Then 'If TempStr.Length + 3 < PRng.Text.Length Then
                            TempRng = oWordDoc.Range(HeadRng.Paragraphs.Item(I).Range.Start, HeadRng.Paragraphs.Item(I).Range.Start + TempStr.Length)
                            TempRng.InsertAfter(Chr(13))
                        End If
                    End If
                Else
                    HeadRng.Paragraphs.Item(I).Range.Delete()
                End If
NxtI:
            Next I



            For Each P In HeadRng.Paragraphs
                If P.Range.Information(WdInformation.wdWithInTable) = True Then GoTo NxtPara
                PRng = P.Range : TempStr = Trim(P.Range.Text)
                If TempStr = Chr(13) Or TempStr = Chr(11) Or TempStr = Chr(11) & Chr(13) Then GoTo NxtPara
                If PRng.Characters.Last.Text = Chr(13) Then PRng.SetRange(PRng.Start, PRng.End - 1)
                ConfidenceVal = 0 : bAddNextTag = False : bAddLastTag = True : bAddParaInfo = False
                oWordDoc.ActiveWindow.ScrollIntoView(PRng, True)
                Call ToTrimParagraphSpace(PRng)

                If String.IsNullOrEmpty(sNextTagInfo) = False Then
                    TempVar = sNextTagInfo.Split(SplitSinglePipe, StringSplitOptions.RemoveEmptyEntries)
                    If TempVar.GetUpperBound(0) > 0 Then
                        Call ToSetNodeRange(PRng, TempVar(0), 40, True, sTagTypeAttribute, TempVar(1))
                    Else
                        GoTo UserInput4Head
                        'Call ToSetNodeRange(PRng, TempVar(0), 40, True, sTagTypeAttribute, sNextTagInfo & "_unknown")
                    End If
                    sNextTagInfo = String.Empty

                ElseIf StringWithRegMatches(TempStr, sExactDeleteKey, True, True, True) > 0 AndAlso PRng.ComputeStatistics(WdStatistic.wdStatisticLines) < 3 Then
                    Call ToSetNodeRange(PRng, sXTag, 40, True, sTagTypeAttribute, "x_Del", False, False)
                    AuthorFound = False : CorrMailFound = False : AuthorsMailFound = False : CorrAuFound = False : AffFound = False : AbsFound = False : KeywordFound = False

                ElseIf StringWithRegMatches(TempStr, sOptionalDeleteKey, True, True, False) > 0 AndAlso PRng.ComputeStatistics(WdStatistic.wdStatisticLines) < 10 Then
                    Call ToSetNodeRange(PRng, sXTag, 40, True, sTagTypeAttribute, "x_Optional_Del", False, False)
                    AuthorFound = False : CorrMailFound = False : AuthorsMailFound = False : CorrAuFound = False : AffFound = False : AbsFound = False : KeywordFound = False

                ElseIf StringWithRegMatches(TempStr, sPrefixNoKey & BoxMiscKey, True, True) > 0 Or (bBoxStartFound = True AndAlso (PRng.Text.Contains(vbTab) = True Or PRng.ComputeStatistics(WdStatistic.wdStatisticLines) <= 5)) Then
                    If StringWithRegMatches(TempStr, sPrefixNoKey & BoxMiscKey, True, True) > 0 Then
                        bAddNextTag = True
                        Call ToSetNodeRange(PRng, sXTag, 70, True, sTagTypeAttribute, "x_BoxStart", bAddParaInfo, bAddLastTag, bAddNextTag)
                    Else
                        Call ToSetNodeRange(PRng, sXTag, 40, True, sTagTypeAttribute, "x_BoxStart", bAddParaInfo, bAddLastTag, bAddNextTag)
                    End If
                    bBoxStartFound = True
                    AuthorFound = False : CorrMailFound = False : AuthorsMailFound = False : CorrAuFound = False : AffFound = False : AbsFound = False : KeywordFound = False


                ElseIf (AbsFound = False AndAlso RunHeadFound = False AndAlso StringWithRegMatches(TempStr, RunHeadKey, True) > 0) Then
                    '######## this validation help to find the runhead present after the prefix term (i.e run title : & vbcr & "Title text") 
                    If TempStr.Length < 17 AndAlso StringWithRegMatchesReturnMatchValLen(TempStr, RunHeadKey, True, False, True) + 4 >= TempStr.Length Then
                        ConfidenceVal += 40
                        bAddNextTag = True
                    Else
                        ConfidenceVal += 90
                    End If
                    '##### This validation help to to run-on the title (i.e. Title : vbcr "Title text") ###
                    If ToCheckEndLinePunctuations(TempStr, 3) = True Then bAddNextTag = True
                    RunHeadFound = ToSetNodeRange(PRng, sRunHeadTag, ConfidenceVal, True, sTagTypeAttribute, sRunHeadTag, bAddParaInfo, bAddLastTag, bAddNextTag)
                    PubTypeFound = False : CorrAuFound = False : CorrMailFound = False : AuthorFound = False : AuthorsMailFound = False : AffFound = False : AbsFound = False : KeywordFound = False

                ElseIf ((AbsFound = False AndAlso KeywordFound = False AndAlso ArtTitleFound = False AndAlso CorrAuFound = False AndAlso AffFound = False) And
                       ((PRng.Words.Count >= 3) AndAlso (StringWithRegMatches(TempStr, TitleKey, True) > 0 Or PRng.Font.Size > 12 Or PRng.Font.Bold <> 0 Or P.Alignment = WdParagraphAlignment.wdAlignParagraphCenter))) Then
                    '######## this validation help to find the title present after the prefix term (i.e run title & vbcr & "Title text") 
                    If TempStr.Length < 8 AndAlso StringWithRegMatchesReturnMatchValLen(TempStr, TitleKey, True, False, True) + 4 >= TempStr.Length Then
                        ConfidenceVal += 40
                        bAddNextTag = True
                    Else
                        ConfidenceVal += 90
                    End If
                    '##### This validation help to to run-on the title (i.e. Title : vbcr "Title text") ###
                    If ToCheckEndLinePunctuations(TempStr, 3) = True Then bAddNextTag = True
                    If P.Alignment = WdParagraphAlignment.wdAlignParagraphCenter Then ConfidenceVal += 10
                    If P.Range.Font.Size > 12 Then ConfidenceVal += 10
                    If P.Range.Font.Bold <> 0 Then ConfidenceVal += 10
                    ArtTitleFound = ToSetNodeRange(PRng, sArtTitleTag, ConfidenceVal, True, sTagTypeAttribute, sArtTitleTag, bAddParaInfo, bAddLastTag, bAddNextTag)


                ElseIf StringWithRegMatches(TempStr, sPrefixNoKey & MiscellaneousKey, True, True) > 0 Then
                    If StringWithRegMatchesReturnMatchValLen(TempStr, sPrefixNoKey & MiscellaneousKey, True, False, True) + 5 >= TempStr.Length Then
                        ConfidenceVal += 60
                        bAddNextTag = True
                    Else
                        ConfidenceVal += 90
                    End If
                    'Call ToSetNodeRange(PRng, sXTag, 70, True, sTagTypeAttribute, "x_Misc", bAddParaInfo, bAddLastTag, bAddNextTag)
                    AuthorFound = False : CorrMailFound = False : AuthorsMailFound = False : CorrAuFound = False : AffFound = False : AbsFound = False : KeywordFound = False
                    GoTo UserInput4Head

                ElseIf StringWithRegMatches(TempStr, DedicateKey, True, False, False) > 0 AndAlso PRng.ComputeStatistics(WdStatistic.wdStatisticLines) < 5 Then
                    Call ToSetNodeRange(PRng, "dedicate", 70, True, sTagTypeAttribute, "dedicate")
                    AuthorFound = False : CorrMailFound = False : AuthorsMailFound = False : CorrAuFound = False : AffFound = False : AbsFound = False : KeywordFound = False

                ElseIf StringWithRegMatches(TempStr, KeywordKey, True, True, False) > 0 Or (StringWithRegMatches(TempStr, KeywordKey & "(\:|\;|\.)\s+", True, False, False) > 0 And PRng.ComputeStatistics(WdStatistic.wdStatisticLines) < 4) Then
                    If StringWithRegMatches(TempStr, KeywordKey, True) > 0 Then ConfidenceVal += 80
                    KeywordFound = ToSetNodeRange(PRng, "kwd-group", ConfidenceVal, True, sTagTypeAttribute, "kwd-group")
                    AuthorFound = False : CorrAuFound = False : CorrMailFound = False : AuthorsMailFound = False : AffFound = False : AbsFound = False


                ElseIf (AbsFound = False And KeywordFound = False And ArtTitleFound = False) AndAlso
                       (HeadRng.Paragraphs.Item(1).Range.Text = P.Range.Text And (PRng.Words.Count >= 6)) Then
                    ConfidenceVal += 40
                    ArtTitleFound = ToSetNodeRange(PRng, sArtTitleTag, ConfidenceVal, True, sTagTypeAttribute, sArtTitleTag)
                    AuthorFound = False : CorrMailFound = False : AuthorsMailFound = False : CorrAuFound = False : AffFound = False : AbsFound = False : KeywordFound = False

                ElseIf StringWithRegMatches(TempStr, CorrAuthorsKey, True) > 0 Then
                    CorrAuFound = ToSetNodeRange(PRng, sAuthorTag, 70, True, sTagTypeAttribute, "contrib_CorresAuthorName")
                    AffFound = False : AuthorsMailFound = False : AbsFound = False : KeywordFound = False


                ElseIf ((StringWithRegMatches(TempStr, AuthorNamesKey, True) > 0 OrElse StringWithRegMatches(TempStr, CorrNameskey, True) > 0 OrElse
                        StringWithRegMatches(TempStr, AuthorsKey, True) > 0) AndAlso
                       (AbsFound = False AndAlso KeywordFound = False) AndAlso (StringWithRegMatches(TempStr, AffKey, True) = 0) AndAlso
                       StringWithRegMatches(TempStr, CorrMailkey, True) = 0 AndAlso StringWithRegMatches(TempStr, AuthorsMailKey, True) = 0) Then

                    '######### It should be author or corres author ###########
                    If (StringWithRegMatches(TempStr, AuthorNamesKey, True) <= StringWithRegMatches(TempStr, CorrNameskey, True) AndAlso
                       (StringWithRegMatches(TempStr, CorrAuthorsKey, True) > 0 OrElse CorrAuFound = True OrElse CorrMailFound = True)) Then
                        ConfidenceVal += 65
                        CorrAuFound = ToSetNodeRange(PRng, sAuthorInfoTag, ConfidenceVal, True, sTagTypeAttribute, "contrib_CorresAuthorPrefix")
                        AffFound = False : AuthorFound = False : CorrMailFound = False : AuthorsMailFound = False : AbsFound = False : KeywordFound = False
                    Else
                        ConfidenceVal += 70
                        AuthorFound = ToSetNodeRange(PRng, sAuthorTag, ConfidenceVal, True, sTagTypeAttribute, sAuthorTag)
                        AffFound = False : CorrAuFound = False : CorrMailFound = False : AuthorsMailFound = False : AbsFound = False : KeywordFound = False
                    End If


                ElseIf ((StringWithRegMatches(TempStr, CorrMailkey, True) > 0 OrElse StringWithRegMatches(TempStr, AuthorsMailKey, True) > 0 OrElse Regex.IsMatch(TempStr, "(\@)") = True) AndAlso
                       (AbsFound = False AndAlso KeywordFound = False) AndAlso (StringWithRegMatches(TempStr, AllTypeAffKey, True) = 0)) Then

                    '######### It should be author mail or corres author mail ###########
                    ConfidenceVal += 70 : TempRng = Nothing
                    Dim BackupRng As Range
                    If Regex.IsMatch(sLastTagInfo, "CorresAuthor", RegexOptions.IgnoreCase) = True Or CorrAuFound = True Then
                        BackupRng = ToSetNodeRangeReturnRng(PRng, sAffTag, ConfidenceVal, True, sTagTypeAttribute, "aff_CorresAuthorInfo")
                        AffFound = True : CorrMailFound = True : CorrAuFound = True : AbsFound = False : KeywordFound = False
                    Else
                        BackupRng = ToSetNodeRangeReturnRng(PRng, sAffTag, ConfidenceVal, True, sTagTypeAttribute, "aff_AuthorInfo")
                        AffFound = True : AuthorsMailFound = True : AbsFound = False : KeywordFound = False
                    End If
                    If Not (BackupRng Is Nothing) Then
                        Dim J As Integer, ContactPattern As String = ""
                        For J = 1 To 3
                            Select Case J
                                Case 1 : ContactPattern = sTelPattern
                                Case 2 : ContactPattern = sFaxPattern
                                Case 3 : ContactPattern = sMailPattern
                            End Select
                            TempRng = BackupRng.Duplicate : TempRng.Collapse(WdCollapseDirection.wdCollapseStart)
                            Dim rMatches As MatchCollection = Regex.Matches(BackupRng.Text, ContactPattern, RegexOptions.IgnoreCase)
                            For Each rMatch As Match In rMatches
                                TempRng.Find.Text = rMatch.Value
                                If TempRng.Find.Execute = True And TempRng.InRange(BackupRng) = True Then
                                    Select Case J
                                        Case 1
                                            Call ToSetNodeRange(TempRng, "phone", 90, True, sTagTypeAttribute, "aff_phone")
                                        Case 2
                                            Call ToSetNodeRange(TempRng, "fax", 90, True, sTagTypeAttribute, "aff_fax")
                                        Case 3
                                            Call ToSetNodeRange(TempRng, "email", 90, True, sTagTypeAttribute, "aff_email")
                                    End Select
                                    '####### It will close the corres author info after the contact details ###########
                                    If CorrAuFound = True AndAlso Regex.IsMatch(TempRng.Next.Paragraphs(1).Range.Text, "(" & sTelPattern & "|" & sFaxPattern & "|" & sMailPattern & ")", RegexOptions.IgnoreCase) = False Then
                                        CorrAuFound = False
                                        CorrMailFound = False
                                    End If
                                End If
                                TempRng.Collapse(WdCollapseDirection.wdCollapseEnd)
                            Next
                        Next
                    End If

                ElseIf (AbsFound = False AndAlso KeywordFound = False) AndAlso
                       (Regex.IsMatch(sLastTagInfo, "CorresAuthor", RegexOptions.IgnoreCase) = True AndAlso StringWithRegMatches(TempStr, AuthorsKey, True) > 0) Then
                    CorrAuFound = ToSetNodeRange(PRng, sAuthorTag, 70, True, sTagTypeAttribute, "contrib_CorresAuthorName")
                    AuthorFound = False : AuthorsMailFound = False : AffFound = False : AbsFound = False : KeywordFound = False

                ElseIf (AbsFound = False And KeywordFound = False And AffFound = False) AndAlso (PubTypeFound = False And StringWithRegMatches(TempStr, PubTypeKey, True) > 0) Then
                    If StringWithRegMatches(TempStr, PubTypeKey, True) > 0 Then ConfidenceVal += 70
                    PubTypeFound = ToSetNodeRange(PRng, "article-type", ConfidenceVal, True, sTagTypeAttribute, "article-type")
                    AuthorFound = False : CorrAuFound = False : CorrMailFound = False : AuthorsMailFound = False : AffFound = False : AbsFound = False : KeywordFound = False


                ElseIf (AbsFound = False AndAlso KeywordFound = False) AndAlso (StringWithRegMatches(TempStr, AllTypeAffKey, True) > 0 OrElse PRng.Characters.First.Font.Superscript = True) Then
                    '### It should be the corres author aff or author aff info ####
                    ConfidenceVal = 70
                    Select Case True
                        Case Regex.IsMatch(Left(TempStr, 3), "(\*|\#)", RegexOptions.IgnoreCase) = True Or Regex.IsMatch(sLastTagInfo, "CorresAuthor", RegexOptions.IgnoreCase)
                            AffFound = ToSetNodeRange(PRng, sAffTag, ConfidenceVal, True, sTagTypeAttribute, sCorrAffTag)

                        Case Regex.IsMatch(Left(TempStr, 3), "(\d+)", RegexOptions.IgnoreCase) = True
                            AffFound = ToSetNodeRange(PRng, sAffTag, ConfidenceVal, True, sTagTypeAttribute, sAffTag)

                        Case CorrAuFound Or CorrMailFound
                            AffFound = ToSetNodeRange(PRng, sAffTag, ConfidenceVal, True, sTagTypeAttribute, sCorrAffTag)

                        Case AuthorFound Or AuthorsMailFound
                            AffFound = ToSetNodeRange(PRng, sAffTag, ConfidenceVal, True, sTagTypeAttribute, sAffTag)

                        Case AffFound Or PRng.Characters.First.Font.Superscript <> 0
                            AffFound = ToSetNodeRange(PRng, sAffTag, ConfidenceVal, True, sTagTypeAttribute, sAffTag)

                        Case True
                            ConfidenceVal = 40
                            AffFound = ToSetNodeRange(PRng, sAffTag, ConfidenceVal, True, sTagTypeAttribute, sAffTag)
                    End Select

                ElseIf StringWithRegMatches(TempStr, AbstractKey, True, True, False) > 0 Then
                    If StringWithRegMatches(TempStr, AbstractKey, True) > 0 Then ConfidenceVal += 80
                    AbsFound = ToSetNodeRange(PRng, "abstract", ConfidenceVal, True, sTagTypeAttribute, "abstract")
                    AuthorFound = False : CorrAuFound = False : CorrMailFound = False : AuthorsMailFound = False : AffFound = False : KeywordFound = False

                ElseIf StringWithRegMatchesReturnMatchVal(TempStr, AbstractSectionKey, True, False, True) <> "" Or (PRng.ComputeStatistics(WdStatistic.wdStatisticLines) = 1 And KeywordFound = False And AbsFound = True And (PRng.Font.Bold = True Or PRng.Font.Italic = True)) Then
                    If StringWithRegMatches(TempStr, AbstractSectionKey, True) > 0 Then ConfidenceVal += 80
                    AbsFound = ToSetNodeRange(PRng, "sec", ConfidenceVal, True, sTagTypeAttribute, "sec_Abs-Section")
                    AuthorFound = False : CorrAuFound = False : CorrMailFound = False : AuthorsMailFound = False : AffFound = False : KeywordFound = False

                ElseIf (AbsFound = False And KeywordFound = False) AndAlso (Regex.IsMatch(PRng.Text, "([A-z]+(\u002A|\u2020|\u2021|\u00A7|\u00B6|\d)(\,|\;|\n|\r|\^))") = True) Then
                    Call ToSetNodeRange(PRng, sAuthorTag, 40, True, sTagTypeAttribute, sAuthorTag)


                ElseIf StringWithRegMatches(TempStr, sPrefixNoKey & BoxMiscKey, True, True) > 0 Or (bBoxStartFound = True AndAlso (PRng.Text.Contains(vbTab) = True Or PRng.ComputeStatistics(WdStatistic.wdStatisticLines) <= 7)) Then
                    Call ToSetNodeRange(PRng, sXTag, 70, True, sTagTypeAttribute, "x_BoxStart")
                    AuthorFound = False : CorrAuFound = False : CorrMailFound = False : AuthorsMailFound = False : AffFound = False : AbsFound = False : KeywordFound = False

                Else
                    ConfidenceVal = 60
                    Select Case True
                        Case AbsFound = True AndAlso KeywordFound = False AndAlso Regex.IsMatch(sLastTagInfo, "(abstract|abs-section|absSection|sec|p)", RegexOptions.IgnoreCase)
                            If PRng.ComputeStatistics(WdStatistic.wdStatisticLines) > 1 And PRng.Words.Count < 7 Then
                                Call ToSetNodeRange(PRng, "sec", ConfidenceVal, True, sTagTypeAttribute, "sec_Abs-Section")
                            Else
                                Call ToSetNodeRange(PRng, sPTag, ConfidenceVal, True, sTagTypeAttribute, "p_AbsPara")
                            End If

                        Case AbsFound = False AndAlso KeywordFound = False AndAlso CorrAuFound = False AndAlso AuthorFound = True
                            Call ToSetNodeRange(PRng, sAuthorInfoTag, ConfidenceVal, True, sTagTypeAttribute, sAuthorInfoTag)

                        Case AbsFound = False AndAlso KeywordFound = False AndAlso AuthorFound = False AndAlso (CorrAuFound = True Or Regex.IsMatch(sLastTagInfo, "(CorresAuthor)", RegexOptions.IgnoreCase) = True)
                            Call ToSetNodeRange(PRng, sAuthorInfoTag, ConfidenceVal, True, sTagTypeAttribute, "author-info_CorresAuthorInfo")

                        Case (AbsFound = False And KeywordFound = True) Or (KeywordFound = True And PRng.ComputeStatistics(WdStatistic.wdStatisticLines) <= 2)
                            Call ToSetNodeRange(PRng, sKwdTag, ConfidenceVal, True, sTagTypeAttribute, sKwdTag)

                        Case Else
UserInput4Head:
                            P.Range.Select() : IdentifierValStr = String.Empty
                            TempCaptionRng = P.Range.Duplicate
                            P.Range.HighlightColorIndex = WdColorIndex.wdBrightGreen
                            WordApp.ActiveWindow.ScrollIntoView(P.Range, True)
                            frmAuto.TopMost = True : frmAuto.ShowDialog()
                            P.Range.HighlightColorIndex = WdColorIndex.wdNoHighlight
                            Call ToAddUserSpecifiedTag(P.Range, IdentifierValStr, False)
                    End Select
                End If
NxtPara:
                oWordDoc.UndoClear()
            Next
            ToTagHead = True
        Catch ex As Exception
            Throw ex
        End Try
    End Function

    Private Function ToAddUserSpecifiedTag(ByVal TagRng As Range, ByVal sUserAns As String, ByVal bAddLastTagInfo As Boolean) As Boolean
        If Not TagRng Is Nothing AndAlso String.IsNullOrEmpty(sUserAns) = False Then
            Dim TagName As String = String.Empty : Dim TagAttribute As String = String.Empty
            Dim TempRng As Range, PRng As Range : PRng = TagRng.Duplicate
            Select Case True
                Case Regex.IsMatch(sUserAns, "(HeadA)", RegexOptions.IgnoreCase) = True AndAlso String.IsNullOrEmpty(LastSectionInfo)
                    'Case Regex.IsMatch(sUserAns, "(HeadA)", RegexOptions.IgnoreCase) = False AndAlso String.IsNullOrEmpty(LastSectionInfo)
                    TagName = "sec" : TagAttribute = "sec_Sec1"
                    TempRng = ToSetNodeRangeReturnRng(PRng, TagName, 60, True, sTagTypeAttribute, TagAttribute, True, "", "", True)
                    Call ToSetNodeRange(TempRng, sTitleTag, 60, True, sTagTypeAttribute, TagAttribute & sTitleTag)
                Case Regex.IsMatch(sUserAns, "HeadB", RegexOptions.IgnoreCase) = True
                    TagName = "sec" : TagAttribute = "sec_Sec2"
                    TempRng = ToSetNodeRangeReturnRng(PRng, TagName, 60, True, sTagTypeAttribute, TagAttribute, True, "", "", True)
                    Call ToSetNodeRange(TempRng, sTitleTag, 60, True, sTagTypeAttribute, TagAttribute & sTitleTag)
                Case Regex.IsMatch(sUserAns, "HeadC", RegexOptions.IgnoreCase) = True
                    TagName = "sec" : TagAttribute = "sec_Sec3"
                    TempRng = ToSetNodeRangeReturnRng(PRng, TagName, 60, True, sTagTypeAttribute, TagAttribute, True, "", "", True)
                    Call ToSetNodeRange(TempRng, sTitleTag, 60, True, sTagTypeAttribute, TagAttribute & sTitleTag)
                Case Regex.IsMatch(sUserAns, "HeadD", RegexOptions.IgnoreCase) = True
                    TagName = "sec" : TagAttribute = "sec_Sec4"
                    TempRng = ToSetNodeRangeReturnRng(PRng, TagName, 60, True, sTagTypeAttribute, TagAttribute, True, "", "", True)
                    Call ToSetNodeRange(TempRng, sTitleTag, 60, True, sTagTypeAttribute, TagAttribute & sTitleTag)
                Case Else
                    Call ToSetNodeRange(TagRng, sXTag, 99, True, sTagTypeAttribute, "UserInput_" & sUserAns, bAddParaInfo, bAddLastTagInfo, bAddNextTag)
            End Select
        ElseIf Not TagRng Is Nothing Then
            Call ToSetNodeRange(TagRng, sXTag, 99, True, sTagTypeAttribute, "x_unknown")
        End If
        P.Range.HighlightColorIndex = WdColorIndex.wdNoHighlight
        If bAddLastTagInfo = True Then sLastTagInfo = sUserAns
    End Function


    'Private Function ToAddUserSpecifiedTag(ByVal TagRng As Range, ByVal sUserAns As String, ByVal bAddLastTagInfo As Boolean) As Boolean
    '    If Not TagRng Is Nothing AndAlso String.IsNullOrEmpty(sUserAns) = False Then
    '        Call ToSetNodeRange(TagRng, sXTag, 99, True, sTagTypeAttribute, "UserInput_" & sUserAns)
    '    ElseIf Not TagRng Is Nothing Then
    '        Call ToSetNodeRange(TagRng, sXTag, 99, True, sTagTypeAttribute, "x_unknown")
    '    End If
    '    P.Range.HighlightColorIndex = WdColorIndex.wdNoHighlight
    '    If bAddLastTagInfo = True Then sLastTagInfo = sUserAns
    'End Function


    Private Function ToTagBody(ByVal oWordDoc As Document) As Boolean
        TempRng = Nothing
        Dim SecLevel As Integer
        Dim Recheckbln As Boolean
        BodyRng = ToGetNodeRange(oWordDoc, oWordDoc.Range, "body")
        Try
            If BodyRng Is Nothing Then ToTagBody = True : Exit Function
            '########## Reset module variables ###########
            shtList1LeftInfo = 0 : shtList2LeftInfo = 0 : shtList3LeftInfo = 0
            AckFound = False : AppFound = False : sLastTagInfo = "" : MiscellaneousKey = ""
            FigKey = "" : TabKey = "" : FloatsSourceKey = "" : Ackkey = "" : Appkey = "" : FsKey = ""
            FigFound = False : TabFound = False
            TabFNCnt = 0 : FigFNCnt = 0 : TabIDCnt = 0 : FigIDCnt = 0 : FSIDCnt = 0
            PRng = Nothing : P = Nothing : TempRng = Nothing : TempStr = String.Empty
            Sec1Key = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "Sec1Pattern", String.Empty, True)
            Sec2Key = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "sec2Pattern", String.Empty, True)
            Sec3Key = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "sec3Pattern", "", True)
            Ackkey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "AckPattern", "", True)
            Appkey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "AppPattern", "", True)
            MiscellaneousKey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "MiscPattern", "", True)
            BoxMiscKey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "BoxPattern", "", True, False)
            FigKey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "FigPattern", "", True)
            FsKey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "FormalStatementPattern", "", True) ''Jaisoft
            FloatsSourceKey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "TabAndFigSourcePattern", "", True)
            TabKey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "TabPattern", "", True)
            sExactDeleteKey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "ColorTextExactPattern", "", True)
            sOptionalDeleteKey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "ColorTextInRngPattern", "", True)

            Call BodyRng.ListFormat.ConvertNumbersToText()
            Call SplitRunOnSections(oWordDoc, BodyRng, MiscellaneousKey)
            For Each P In BodyRng.Paragraphs
                Recheckbln = False
                If P.Range.Information(WdInformation.wdWithInTable) = True Then GoTo NxtPara
                PRng = P.Range : TempStr = Trim(P.Range.Text)
                ConfidenceVal = 0 : bAddNextTag = False : bAddLastTag = True : bAddParaInfo = False
                If TempStr = Chr(13) Or TempStr = Chr(11) Or TempStr = Chr(11) & Chr(13) Then GoTo NxtPara
                If PRng.Characters.Last.Text = Chr(13) Then PRng.SetRange(PRng.Start, PRng.End - 1)
                Call ToTrimParagraphSpace(PRng)
                Do While Left(TempStr, 1) Like "[.,;:"" ]" : TempStr = Mid(TempStr, 2, Len(TempStr)) : Loop
                oWordDoc.ActiveWindow.ScrollIntoView(PRng, True)
PrcessRecheck:
                If PRng.InlineShapes.Count > 0 And Recheckbln = False Then
                    Recheckbln = True
                    Dim InLineCnt As Integer
                    If PRng.InlineShapes.Item(1).Type = WdInlineShapeType.wdInlineShapeEmbeddedOLEObject And TempStr.Length < 20 Then
                        Call ToSetNodeRange(PRng, "disp-formula", 90, True, sTagTypeAttribute, "disp-formula")
                    ElseIf PRng.InlineShapes.Item(1).Type = WdInlineShapeType.wdInlineShapeEmbeddedOLEObject Then
                        Call ToSetNodeRange(PRng, sPTag, 90, True, sTagTypeAttribute, "p_IndTxtPara")
                        For InLineCnt = 1 To PRng.InlineShapes.Count
                            Call ToSetNodeRange(PRng.InlineShapes(InLineCnt).Range, "inline-formula", 90, False)
                        Next
                    Else
                        GoTo PrcessRecheck
                    End If

                ElseIf String.IsNullOrEmpty(sNextTagInfo) = False Then
                    TempVar = sNextTagInfo.Split(SplitSinglePipe, StringSplitOptions.RemoveEmptyEntries)
                    sNextTagInfo = String.Empty
                    If TempVar.GetUpperBound(0) > 0 Then
                        Call ToSetNodeRange(PRng, TempVar(0), 40, True, sTagTypeAttribute, TempVar(1))
                    Else
                        'Call ToSetNodeRange(PRng, TempVar(0), 40, True, sTagTypeAttribute, sNextTagInfo & "_unknown")
                        GoTo UserInput4Body
                    End If


                    '########## Floats validation in the body matter - Start #############
                ElseIf RegMatchesAndCustomValidate(PRng.Text, FsKey, True, False, True, True) = True And StringWithRegMatches(PRng.Text, FsKey, True, True, False) > 0 And PRng.ComputeStatistics(WdStatistic.wdStatisticLines) < 10 Then
                    TempStr = StringWithRegMatchesReturnMatchVal(PRng.Text, FsKey, True, False, True) ''Formal statement 
                    FSIDCnt += 1 : FigFound = False : TabFound = False
                    TempRng = ToSetNodeRangeReturnRng(PRng, sFSTag, 90, True, sTagTypeAttribute, sFSTag, False, "id", sFSTag & FSIDCnt)
                    If TempStr <> "" And Not TempRng Is Nothing Then ''Formal statement 
                        If TempStr.Length + 2 < TempRng.Text.Length Then
                            TempRng.SetRange(TempRng.Start, TempRng.Start + Len(TempStr))
                            Call ToSetNodeRange(TempRng, sLabelTag, 90, True, sTagTypeAttribute, "label_Figlabel")
                            TempRng.SetRange(TempRng.End, PRng.End)
                            Call ToSetNodeRange(TempRng, sTitleTag, 90, True, sTagTypeAttribute, "title_Figtitle")
                        Else
                            Call ToSetNodeRange(TempRng, sTitleTag, 90, True, sTagTypeAttribute, "title_Figtitle", False, True, True)
                        End If
                    End If
                ElseIf RegMatchesAndCustomValidate(PRng.Text, FigKey, True, False, True, True) = True And StringWithRegMatches(PRng.Text, FigKey, True, True, False) > 0 And PRng.ComputeStatistics(WdStatistic.wdStatisticLines) < 10 Then
                    TempStr = StringWithRegMatchesReturnMatchVal(PRng.Text, FigKey, True, False, True)
                    FigIDCnt += 1 : FigFound = True : TabFound = False
                    TempRng = ToSetNodeRangeReturnRng(PRng, sFigTag, 90, True, sTagTypeAttribute, sFigTag, False, "id", sFigTag & FigIDCnt)
                    If TempStr <> "" And Not TempRng Is Nothing Then
                        If TempStr.Length + 2 < TempRng.Text.Length Then
                            TempRng.SetRange(TempRng.Start, TempRng.Start + Len(TempStr))
                            Call ToSetNodeRange(TempRng, sLabelTag, 90, True, sTagTypeAttribute, "label_Figlabel")
                            TempRng.SetRange(TempRng.End, PRng.End)
                            Call ToSetNodeRange(TempRng, sTitleTag, 90, True, sTagTypeAttribute, "title_Figtitle")
                        Else
                            Call ToSetNodeRange(TempRng, sTitleTag, 90, True, sTagTypeAttribute, "title_Figtitle", False, True, True)
                        End If
                    End If

                ElseIf RegMatchesAndCustomValidate(PRng.Text, TabKey, True, False, True, True) = True And StringWithRegMatches(PRng.Text, TabKey, True, True, False) > 0 And PRng.ComputeStatistics(WdStatistic.wdStatisticLines) < 10 Then
                    TempStr = StringWithRegMatchesReturnMatchVal(PRng.Text, TabKey, True, False, True)
                    TabIDCnt += 1 : FigFound = False : TabFound = True
                    TempRng = ToSetNodeRangeReturnRng(PRng, sTabTag, 90, True, sTagTypeAttribute, sTabTag, False, "id", "tab" & TabIDCnt)
                    If TempStr <> "" And Not TempRng Is Nothing Then
                        If TempStr.Length + 2 < TempRng.Text.Length Then
                            TempRng.SetRange(TempRng.Start, TempRng.Start + Len(TempStr))
                            Call ToSetNodeRange(TempRng, sLabelTag, 90, True, sTagTypeAttribute, "title_Tablelabel")
                            TempRng.SetRange(TempRng.End, PRng.End)
                            Call ToSetNodeRange(TempRng, sTitleTag, 90, True, sTagTypeAttribute, "title_Tabletitle")
                        Else
                            Call ToSetNodeRange(TempRng, sTitleTag, 90, True, sTagTypeAttribute, "title_Tabletitle", False, True, True)
                        End If
                    End If


                ElseIf StringWithRegMatches(TempStr, sExactDeleteKey, True, True, True) > 0 And PRng.ComputeStatistics(WdStatistic.wdStatisticLines) < 4 Then
                    Call ToSetNodeRange(PRng, sXTag, 40, True, sTagTypeAttribute, "x_Del", False, False)

                ElseIf StringWithRegMatches(TempStr, sOptionalDeleteKey, True, True, False) > 0 And PRng.ComputeStatistics(WdStatistic.wdStatisticLines) < 10 Then
                    Call ToSetNodeRange(PRng, sXTag, 40, True, sTagTypeAttribute, "x_Optional_Del", False, False)


                ElseIf ((TabFound = True Or FigFound = True) AndAlso (bBoxStartFound = False) AndAlso (PRng.Characters.First.Font.Superscript = True Or IsNumeric(PRng.Characters.First.Text) = True Or PRng.Characters.First.Text = ChrW(&H2A) Or
                       PRng.Characters.First.Text = ChrW(&H2020) Or PRng.Characters.First.Text = ChrW(&H2021) Or
                       (PRng.ComputeStatistics(WdStatistic.wdStatisticLines) < 6 AndAlso
                       (StringWithRegMatches(TempStr, FloatsSourceKey, True, False, False) > 0 OrElse
                        StringWithRegMatches(TempStr, "(\=|[A-Z]+)", False, False, False) > 5)))) Then

                    '######### Validate the footnote mark as in superscript #######
                    TempRng = Nothing
                    If PRng.Characters.First.Font.Superscript = True Then
                        TempRng = PRng.Duplicate : TempRng.SetRange(PRng.Start, PRng.Start + 1)
                        Do While TempRng.Characters.Last.Font.Superscript = True
                            TempRng.SetRange(TempRng.Start, TempRng.End + 1)
                        Loop
                        TempRng.SetRange(TempRng.Start, TempRng.End - 1)
                        TempStr = TempRng.Text
                    Else
                        TempStr = StringWithRegMatchesReturnMatchVal(TempStr, "(\d|\u002A|\u2020|\u2021)+", True, False, True)
                    End If
                    Select Case True
                        Case TabFound
                            If String.IsNullOrEmpty(TempStr) = False Then
                                TabFNCnt += 1
                                TempRng = ToSetNodeRangeReturnRng(PRng, "tab-note", 80, True, sTagTypeAttribute, "tab-note_Tabfn", False, "id", "tabfn" & TabFNCnt)
                                TempRng.SetRange(TempRng.Start, TempRng.Start + TempStr.Length)
                                Call ToSetNodeRange(TempRng, sLabelTag, 70, True, sTagTypeAttribute, "label_Tabfnlabel")
                                TempRng.SetRange(TempRng.End, PRng.End)
                                Call ToSetNodeRange(TempRng, sPTag, 70, True, sTagTypeAttribute, "p_Tabfnpara")
                            Else
                                Call ToSetNodeRange(PRng, sFloatsSourceTag, 70, True, sTagTypeAttribute, "tab-source_TabSource")
                            End If

                        Case FigFound
                            If String.IsNullOrEmpty(TempStr) = False Then
                                FigFNCnt += 1
                                TempRng = ToSetNodeRangeReturnRng(PRng, "fig-note", 80, True, sTagTypeAttribute, "fig-note_Figfn", False, "id", "figfn" & FigFNCnt)
                                TempRng.SetRange(TempRng.Start, TempRng.Start + TempStr.Length)
                                Call ToSetNodeRange(TempRng, sLabelTag, 70, True, sTagTypeAttribute, "label_Figfnlabel")
                                TempRng.SetRange(TempRng.End, PRng.End)
                                Call ToSetNodeRange(TempRng, sPTag, 70, True, sTagTypeAttribute, "p_Figfnpara")
                            Else
                                Call ToSetNodeRange(PRng, sFloatsSourceTag, 70, True, sTagTypeAttribute, "fig-source_FigSource")
                            End If
                    End Select
                    '########## Floats validation in the body matter - End #############

                ElseIf StringWithRegMatches(TempStr, "(([xvi0-9\.\t ]+)?" & Ackkey & ")", True, True) > 0 Then
                    TempRng = ToSetNodeRangeReturnRng(PRng, "ack", 90, True)
                    AckFound = True : Miscellaneous = False
                    TempStr = StringWithRegMatchesReturnMatchVal(TempRng.Text, "([xvi0-9\.\t ]+[\.\:\t ]+)", True, False, True)
                    If TempStr <> "" And Not TempRng Is Nothing Then
                        TempRng.SetRange(TempRng.Start, TempRng.Start + Len(TempStr))
                        Call ToSetNodeRange(TempRng, sLabelTag, 90, True, sTagTypeAttribute, "label_Acklabel")
                        TempRng.SetRange(TempRng.Start + Len(TempStr), PRng.End)
                        Call ToSetNodeRange(TempRng, sTitleTag, 90, True, sTagTypeAttribute, "title_Acktitle")
                    Else
                        Call ToSetNodeRange(TempRng, sTitleTag, 90, True, sTagTypeAttribute, "title_Acktitle")
                    End If

                ElseIf StringWithRegMatches(TempStr, "(([xvi0-9\.\t ]+)?" & Appkey & ")", True, True) > 0 Then
                    TempRng = ToSetNodeRangeReturnRng(PRng, "app", 90, True)
                    AppFound = True
                    TempStr = StringWithRegMatchesReturnMatchVal(TempRng.Text, "(appendix([\s\.\:]+)((\d+[A-Z]|[A-Z]\d+|\d+|[A-Z]?)[\s\.\:]+)+|[xvi0-9\.\t ]+[\.\:\t ]+)", True, False, True)
                    If TempStr <> "" And Not TempRng Is Nothing Then
                        If TempStr.Length + 5 > TempRng.Text.Length Then
                            TempRng.SetRange(TempRng.Start, TempRng.Start + Len(TempStr))
                            Call ToSetNodeRange(TempRng, sLabelTag, 90, True, sTagTypeAttribute, "label_Applabel")
                            TempRng.SetRange(TempRng.Start + Len(TempStr), PRng.End)
                            Call ToSetNodeRange(TempRng, sTitleTag, 90, True, sTagTypeAttribute, "title_Apptitle")
                        Else
                            Call ToSetNodeRange(TempRng, sTitleTag, 90, True, sTagTypeAttribute, "title_Apptitle")
                        End If
                    End If

                ElseIf StringWithRegMatches(TempStr, sPrefixNoKey & MiscellaneousKey, True, True) > 0 Then
                    '########### It will miss the miscellaneous text paragraph tag ###############
                    'If StringWithRegMatchesReturnMatchValLen(TempStr, sPrefixNoKey & MiscellaneousKey, True, False, True) + 7 >= TempStr.Length Then
                    '    ConfidenceVal += 60
                    '    bAddNextTag = True
                    'Else
                    '    ConfidenceVal += 90
                    'End If
                    'Call ToSetNodeRange(PRng, sXTag, ConfidenceVal, True, sTagTypeAttribute, "x_Misc", bAddParaInfo, bAddLastTag, bAddNextTag)
                    GoTo UserInput4Body


                ElseIf Regex.IsMatch(sLastTagInfo, "(sec1)", RegexOptions.IgnoreCase) = False AndAlso StringWithRegMatches(TempStr, "(([xvi0-9\.\t ]+)?" & Sec1Key & ")", True, True) > 0 And PRng.ComputeStatistics(WdStatistic.wdStatisticLines) < 3 Then
                    TempRng = ToSetNodeRangeReturnRng(PRng, "sec", 90, True, sTagTypeAttribute, "sec_Sec1", True, "", "", True)
                    Sec1Found = True : TempStr = StringWithRegMatchesReturnMatchVal(TempRng.Text, "([xvi0-9\.\t\s]+[\.\:\t\s]+)", True, False)
                    If TempStr <> "" And Not TempRng Is Nothing Then
                        If TempStr.Length + 3 < TempRng.Text.Length Then
                            TempRng.SetRange(TempRng.Start, TempRng.Start + Len(TempStr))
                            Call ToSetNodeRange(TempRng, sLabelTag, 90, True, sTagTypeAttribute, "label_Sec1label", False, False, False)
                            TempRng.SetRange(TempRng.Start + Len(TempStr), PRng.End)
                            Call ToSetNodeRange(TempRng, sTitleTag, 90, True, sTagTypeAttribute, "title_Sec1title", False, bAddLastTag, False)
                        Else
                            Call ToSetNodeRange(TempRng, sTitleTag, 90, True, sTagTypeAttribute, "title_Sec1title", False, bAddLastTag, False)
                        End If
                    Else
                        Call ToSetNodeRange(TempRng, sTitleTag, 90, True, sTagTypeAttribute, "title_Sec1title", False, bAddLastTag, False)
                    End If

                ElseIf Regex.IsMatch(sLastTagInfo, "(sec2)", RegexOptions.IgnoreCase) = False AndAlso StringWithRegMatches(TempStr, "(([xvi0-9\.\t ]+)?" & Sec2Key & ")", True, True) > 0 And PRng.ComputeStatistics(WdStatistic.wdStatisticLines) < 3 Then
                    TempRng = ToSetNodeRangeReturnRng(PRng, "sec", 90, True, sTagTypeAttribute, "sec_Sec2", True, "", "", True)
                    Sec2Found = True : TempStr = StringWithRegMatchesReturnMatchVal(TempRng.Text, "([xvi0-9\.\t\s]+[\.\:\t\s]+)", True, False)
                    If TempStr <> "" And Not TempRng Is Nothing Then
                        If TempStr.Length + 3 < TempRng.Text.Length Then
                            TempRng.SetRange(TempRng.Start, TempRng.Start + Len(TempStr))
                            Call ToSetNodeRange(TempRng, sLabelTag, 90, True, sTagTypeAttribute, "label_Sec2label", False, False, False)
                            TempRng.SetRange(TempRng.Start + Len(TempStr), PRng.End)
                            Call ToSetNodeRange(TempRng, sTitleTag, 90, True, sTagTypeAttribute, "title_Sec2title", False, False, False)
                        Else
                            Call ToSetNodeRange(TempRng, sTitleTag, 90, True, sTagTypeAttribute, "title_Sec2title", False, False, False)
                        End If
                    Else
                        Call ToSetNodeRange(TempRng, sTitleTag, 90, True, sTagTypeAttribute, "title_Sec2title", False, False, False)
                    End If

                ElseIf Regex.IsMatch(sLastTagInfo, "(sec3)", RegexOptions.IgnoreCase) = False AndAlso StringWithRegMatches(TempStr, "(([xvi0-9\.\t ]+)?" & Sec3Key & ")", True, True) > 0 And PRng.ComputeStatistics(WdStatistic.wdStatisticLines) < 3 Then
                    TempRng = ToSetNodeRangeReturnRng(PRng, "sec", 90, True, sTagTypeAttribute, "sec_Sec3", True, "", "", True)
                    Sec2Found = True : TempStr = StringWithRegMatchesReturnMatchVal(TempRng.Text, "([xvi0-9\.\t\s]+[\.\:\t\s]+)", True, False)
                    If TempStr <> "" And Not TempRng Is Nothing Then
                        If TempStr.Length + 3 < TempRng.Text.Length Then
                            TempRng.SetRange(TempRng.Start, TempRng.Start + Len(TempStr))
                            Call ToSetNodeRange(TempRng, sLabelTag, 90, True, sTagTypeAttribute, "label_Sec3label", False, False, False)
                            TempRng.SetRange(TempRng.Start + Len(TempStr), PRng.End)
                            Call ToSetNodeRange(TempRng, sTitleTag, 90, True, sTagTypeAttribute, "title_Sec3title", False, False, False)
                        Else
                            Call ToSetNodeRange(TempRng, sTitleTag, 90, True, sTagTypeAttribute, "tiotle_Sec3title", False, False, False)
                        End If
                    Else
                        Call ToSetNodeRange(TempRng, sTitleTag, 90, True, sTagTypeAttribute, "title_Sec3title", False, False, False)
                    End If

                ElseIf StringWithRegMatches(TempStr, sPrefixNoKey & BoxMiscKey, True, True) > 0 Or (bBoxStartFound = True AndAlso (PRng.Text.Contains(vbTab) = True Or PRng.ComputeStatistics(WdStatistic.wdStatisticLines) <= 5)) Then
                    If StringWithRegMatches(TempStr, sPrefixNoKey & BoxMiscKey, True, True) > 0 Then
                        bAddNextTag = True
                        Call ToSetNodeRange(PRng, sXTag, 70, True, sTagTypeAttribute, "x_BoxStart", bAddParaInfo, bAddLastTag, bAddNextTag)
                    Else
                        Call ToSetNodeRange(PRng, sXTag, 40, True, sTagTypeAttribute, "x_BoxStart", bAddParaInfo, bAddLastTag, bAddNextTag)
                    End If
                    bBoxStartFound = True

                ElseIf (PRng.Font.Bold = True Or PRng.Font.Italic = True Or PRng.Font.Underline <> WdUnderline.wdUnderlineNone Or IsNumeric(Left(TempStr, 1)) = True) And Right(TempStr, 1) <> "." Then
                    If PRng.ComputeStatistics(WdStatistic.wdStatisticLines) <= 2 And Right(TempStr, 1) <> "." And (PRng.Font.Bold = True Or PRng.Font.Italic = True Or PRng.Font.Underline <> WdUnderline.wdUnderlineNone) Then
                        TempStr = StringWithRegMatchesReturnMatchVal(PRng.Text, "[xvi0-9\.\t\s]+[\.\:\t\s]+", True, False, True)
                        If TempStr = "" Then GoTo BdyCheck
                        TempRng = PRng.Duplicate : TempRng.SetRange(TempRng.Start, TempRng.Start + Len(TempStr))
                        TempVar = Split(TempStr, ".") : SecLevel = 0
                        If IsNumeric(Left(Trim(TempVar(UBound(TempVar))), 1)) = True Then SecLevel = UBound(TempVar) + 1 Else SecLevel = UBound(TempVar)
                        Select Case SecLevel
                            Case 0, 1
                                TempRng = ToSetNodeRangeReturnRng(PRng, "sec", 70, True, sTagTypeAttribute, "sec_Sec1", True, "", "", True)
                                Sec1Found = True : TempStr = StringWithRegMatchesReturnMatchVal(TempRng.Text, "([xvi0-9\.\t\s]+[\.\:\t\s]+)", True, False)
                                If TempStr <> "" And Not TempRng Is Nothing Then
                                    If TempStr.Length + 3 < TempRng.Text.Length Then
                                        TempRng.SetRange(TempRng.Start, TempRng.Start + Len(TempStr))
                                        Call ToSetNodeRange(TempRng, sLabelTag, 70, True, sTagTypeAttribute, "label_Sec1label", False, False, False)
                                        TempRng.SetRange(TempRng.Start + Len(TempStr), PRng.End)
                                        Call ToSetNodeRange(TempRng, sTitleTag, 70, True, sTagTypeAttribute, "title_Sec1title", False, True, False)
                                    Else
                                        Call ToSetNodeRange(TempRng, sTitleTag, 70, True, sTagTypeAttribute, "title_Sec1title", False, True, False)
                                    End If
                                Else
                                    Call ToSetNodeRange(TempRng, sTitleTag, 70, True, sTagTypeAttribute, "title_Sec1title", False, True, False)
                                End If

                            Case 2
                                TempRng = ToSetNodeRangeReturnRng(PRng, "sec", 70, True, sTagTypeAttribute, "sec_Sec2", True, "", "", True)
                                Sec2Found = True : TempStr = StringWithRegMatchesReturnMatchVal(TempRng.Text, "([xvi0-9\.\t\s]+[\.\:\t\s]+)", True, False)
                                If TempStr <> "" And Not TempRng Is Nothing Then
                                    If TempStr.Length + 3 < TempRng.Text.Length Then
                                        TempRng.SetRange(TempRng.Start, TempRng.Start + Len(TempStr))
                                        Call ToSetNodeRange(TempRng, sLabelTag, 70, True, sTagTypeAttribute, "label_Sec2label", False, False, False)
                                        TempRng.SetRange(TempRng.Start + Len(TempStr), PRng.End)
                                        Call ToSetNodeRange(TempRng, sTitleTag, 70, True, sTagTypeAttribute, "title_Sec2title", False, True, False)
                                    Else
                                        Call ToSetNodeRange(TempRng, sTitleTag, 70, True, sTagTypeAttribute, "title_Sec2title", False, True, False)
                                    End If
                                Else
                                    Call ToSetNodeRange(TempRng, sTitleTag, 70, True, sTagTypeAttribute, "title_Sec2title", False, True, False)
                                End If

                            Case 3
                                TempRng = ToSetNodeRangeReturnRng(PRng, "sec", 70, True, sTagTypeAttribute, "sec_Sec3", True, "", "", True)
                                Sec3Found = True : TempStr = StringWithRegMatchesReturnMatchVal(TempRng.Text, "([xvi0-9\.\t\s]+[\.\:\t\s]+)", True, False)
                                If TempStr <> "" And Not TempRng Is Nothing Then
                                    If TempStr.Length + 3 < TempRng.Text.Length Then
                                        TempRng.SetRange(TempRng.Start, TempRng.Start + Len(TempStr))
                                        Call ToSetNodeRange(TempRng, sLabelTag, 70, True, sTagTypeAttribute, "label_Sec3label", False, False, False)
                                        TempRng.SetRange(TempRng.Start + Len(TempStr), PRng.End)
                                        Call ToSetNodeRange(TempRng, sTitleTag, 70, True, sTagTypeAttribute, "title_Sec3title", False, True, False)
                                    Else
                                        Call ToSetNodeRange(TempRng, sTitleTag, 70, True, sTagTypeAttribute, "title_Sec3title", False, True, False)
                                    End If
                                Else
                                    Call ToSetNodeRange(TempRng, sTitleTag, 70, True, sTagTypeAttribute, "title_Sec3title", False, True, False)
                                End If

                            Case 4
                                TempRng = ToSetNodeRangeReturnRng(PRng, "sec", 70, True, sTagTypeAttribute, "sec_Sec4", True, "", "", True)
                                SecFound = True : TempStr = StringWithRegMatchesReturnMatchVal(TempRng.Text, "([xvi0-9\.\t\s]+[\.\:\t\s]+)", True, False)
                                If TempStr <> "" And Not TempRng Is Nothing Then
                                    If TempStr.Length + 3 < TempRng.Text.Length Then
                                        TempRng.SetRange(TempRng.Start, TempRng.Start + Len(TempStr))
                                        Call ToSetNodeRange(TempRng, sLabelTag, 70, True, sTagTypeAttribute, "label_Sec4label", False, False, False)
                                        TempRng.SetRange(TempRng.Start + Len(TempStr), PRng.End)
                                        Call ToSetNodeRange(TempRng, sTitleTag, 70, True, sTagTypeAttribute, "title_Sec4title", False, True, False)
                                    Else
                                        Call ToSetNodeRange(TempRng, sTitleTag, 70, True, sTagTypeAttribute, "title_Sec4title", False, True, False)
                                    End If
                                Else
                                    Call ToSetNodeRange(TempRng, sTitleTag, 70, True, sTagTypeAttribute, "title_Sec4title", False, True, False)
                                End If

                            Case 5
                                TempRng = ToSetNodeRangeReturnRng(PRng, "sec", 70, True, sTagTypeAttribute, "sec_Sec5", True, "", "", True)
                                SecFound = True : TempStr = StringWithRegMatchesReturnMatchVal(TempRng.Text, "([xvi0-9\.\t\s]+[\.\:\t\s]+)", True, False)
                                If TempStr <> "" And Not TempRng Is Nothing Then
                                    If TempStr.Length + 3 < TempRng.Text.Length Then
                                        TempRng.SetRange(TempRng.Start, TempRng.Start + Len(TempStr))
                                        Call ToSetNodeRange(TempRng, sLabelTag, 70, True, sTagTypeAttribute, "label_Sec5label", False, False, False)
                                        TempRng.SetRange(TempRng.Start + Len(TempStr), PRng.End)
                                        Call ToSetNodeRange(TempRng, sTitleTag, 70, True, sTagTypeAttribute, "title_Sec5title", False, True, False)
                                    Else
                                        Call ToSetNodeRange(TempRng, sTitleTag, 70, True, sTagTypeAttribute, "title_Sec5title", False, True, False)
                                    End If
                                Else
                                    Call ToSetNodeRange(TempRng, sTitleTag, 70, True, sTagTypeAttribute, "title_Sec5title", False, True, False)
                                End If

                            Case Else
                                TempRng = ToSetNodeRangeReturnRng(PRng, "sec", 70, True, sTagTypeAttribute, "sec_Sec6", True, "", "", True)
                                SecFound = True : TempStr = StringWithRegMatchesReturnMatchVal(TempRng.Text, "([xvi0-9\.\t\s]+[\.\:\t\s]+)", True, False)
                                If TempStr <> "" And Not TempRng Is Nothing Then
                                    If TempStr.Length + 3 < TempRng.Text.Length Then
                                        TempRng.SetRange(TempRng.Start, TempRng.Start + Len(TempStr))
                                        Call ToSetNodeRange(TempRng, sLabelTag, 70, True, sTagTypeAttribute, "label_Sec6label", False, False, False)
                                        TempRng.SetRange(TempRng.Start + Len(TempStr), PRng.End)
                                        Call ToSetNodeRange(TempRng, sTitleTag, 70, True, sTagTypeAttribute, "title_Sec6title", False, True, False)
                                    Else
                                        Call ToSetNodeRange(TempRng, sTitleTag, 70, True, sTagTypeAttribute, "title_Sec6title", False, True, False)
                                    End If
                                Else
                                    Call ToSetNodeRange(TempRng, sTitleTag, 70, True, sTagTypeAttribute, "title_Sec6title", False, True, False)
                                End If
                        End Select
                    ElseIf IsNumeric(Left(TempStr, 1)) = True And InStr(1, TempStr, vbTab, vbTextCompare) > 0 Then
                        GoTo ListCheck
                    Else
                        GoTo BdyCheck
                    End If

                ElseIf InStr(1, Left(TempStr, 6), vbTab, vbTextCompare) > 0 Then 'And PRng.ComputeStatistics(WdStatistic.wdStatisticLines) < 4 
ListCheck:
                    '####### For Different type of list checking ##################
                    TempStr = Regex.Replace(TempStr, "(\(|\)|\{|\}|\[|\]|\s+)", "") : TempStr = Left(TempStr, 1)

                    If Regex.IsMatch(TempStr, "(\d)") = True Then
                        Call ToSetNodeRange(PRng, sListItemTag, 70, True, sTagTypeAttribute, "list-item_ArabicNumList")

                    ElseIf Regex.IsMatch(TempStr, "(i|v|x)", RegexOptions.IgnoreCase) = True Then
                        Call ToSetNodeRange(PRng, sListItemTag, 70, True, sTagTypeAttribute, "list-item_RomanNumList")

                    ElseIf Regex.IsMatch(TempStr, "([a-z])", RegexOptions.IgnoreCase) = True Then
                        Call ToSetNodeRange(PRng, sListItemTag, 70, True, sTagTypeAttribute, "list-item_AlphaNumList")

                    ElseIf ChrW(&H2022) = TempStr Or ChrW(&HF0B7) = TempStr Then
                        Call ToSetNodeRange(PRng, sListItemTag, 70, True, sTagTypeAttribute, "list-item_BullUnNumList")

                    ElseIf ChrW(&H2013) = TempStr Or ChrW(&H2014) = TempStr Or ChrW(&H28) = TempStr Or "-" = TempStr Then
                        Call ToSetNodeRange(PRng, sListItemTag, 70, True, sTagTypeAttribute, "list-item_NdashUnNumList")
                    Else
                        GoTo BdyCheck
                    End If

                Else
BdyCheck:

                    Dim TagName As String, TagAttribute As String
                    TempStr = ToSetAndGetParaInfo(PRng, True, "", "")
                    Select Case True
                        Case PRng.ComputeStatistics(WdStatistic.wdStatisticLines) > 3
                            GoTo TagAsPara

                        Case TempStr <> ""
                            If TempStr.Contains("|") = True Then
                                TempVar = TempStr.Split(SplitSinglePipe)
                                TagName = TempVar(0) : TagAttribute = TempVar(1)
                                If TagName <> "" Then
                                    Select Case True
                                        Case TagName.Contains("sec")
                                            If PRng.ComputeStatistics(WdStatistic.wdStatisticLines) > 1 OrElse Regex.IsMatch(sLastTagInfo, TagAttribute, RegexOptions.IgnoreCase) = True Then
                                                '###### It validate the same level of section heading present with immediate occurence #########
                                                '#TempRng = ToSetNodeRangeReturnRng(PRng, TagName, 40, True, sTagTypeAttribute, TagAttribute, False, "", "", True)
                                                '#Call ToSetNodeRange(TempRng, sTitleTag, 80, True, sTagTypeAttribute, TagAttribute & sTitleTag)
                                                bAddParaInfo = True : bAddLastTag = True
                                                GoTo UserInput4Body
                                            Else
                                                TempRng = ToSetNodeRangeReturnRng(PRng, TagName, 80, True, sTagTypeAttribute, TagAttribute, False, "", "", True)
                                                Call ToSetNodeRange(TempRng, sTitleTag, 80, True, sTagTypeAttribute, TagAttribute & sTitleTag)
                                            End If
                                        Case Else
                                            Call ToSetNodeRange(PRng, TagName, 60, True, sTagTypeAttribute, TagAttribute, False, True)
                                    End Select
                                End If
                            Else
                                'Call ToSetNodeRange(PRng, sXTag, 40, True, sTagTypeAttribute, "unknown")
                                GoTo UserInput4Body
                            End If

                        Case PRng.Words.Count < 11 And (PRng.Font.Bold = True Or PRng.Font.Italic = True Or PRng.Font.Underline = WdUnderline.wdUnderlineSingle Or PRng.Font.Underline = WdUnderline.wdUnderlineDouble)
                            Select Case True
                                Case Regex.IsMatch(sLastTagInfo, "(Sec(\d+))", RegexOptions.IgnoreCase) = False AndAlso String.IsNullOrEmpty(LastSectionInfo)
                                    TagName = "sec" : TagAttribute = "sec_Sec1"
                                    TempRng = ToSetNodeRangeReturnRng(PRng, TagName, 60, True, sTagTypeAttribute, TagAttribute, True, "", "", True)
                                    Call ToSetNodeRange(TempRng, sTitleTag, 60, True, sTagTypeAttribute, TagAttribute & sTitleTag)

                                Case Regex.IsMatch(LastSectionInfo, "Sec1", RegexOptions.IgnoreCase) = True AndAlso Regex.IsMatch(sLastTagInfo, "(Sec(2|3|4|5|6))", RegexOptions.IgnoreCase) = False
                                    TagName = "sec" : TagAttribute = "sec_Sec2"
                                    TempRng = ToSetNodeRangeReturnRng(PRng, TagName, 60, True, sTagTypeAttribute, TagAttribute, True, "", "", True)
                                    Call ToSetNodeRange(TempRng, sTitleTag, 60, True, sTagTypeAttribute, TagAttribute & sTitleTag)

                                Case Regex.IsMatch(LastSectionInfo, "Sec2", RegexOptions.IgnoreCase) = True AndAlso Regex.IsMatch(sLastTagInfo, "(Sec(1|3|4|5|6))", RegexOptions.IgnoreCase) = False
                                    TagName = "sec" : TagAttribute = "sec_Sec3"
                                    TempRng = ToSetNodeRangeReturnRng(PRng, TagName, 60, True, sTagTypeAttribute, TagAttribute, True, "", "", True)
                                    Call ToSetNodeRange(TempRng, sTitleTag, 60, True, sTagTypeAttribute, TagAttribute & sTitleTag)

                                Case Regex.IsMatch(LastSectionInfo, "Sec3", RegexOptions.IgnoreCase) AndAlso Regex.IsMatch(sLastTagInfo, "(Sec(1|2|4|5|6))", RegexOptions.IgnoreCase) = False
                                    TagName = "sec" : TagAttribute = "sec_Sec4"
                                    TempRng = ToSetNodeRangeReturnRng(PRng, TagName, 60, True, sTagTypeAttribute, TagAttribute, True, "", "", True)
                                    Call ToSetNodeRange(TempRng, sTitleTag, 60, True, sTagTypeAttribute, TagAttribute & sTitleTag)

                                Case Regex.IsMatch(LastSectionInfo, "Sec4", RegexOptions.IgnoreCase) AndAlso Regex.IsMatch(sLastTagInfo, "(Sec(1|2|3|5|6))", RegexOptions.IgnoreCase) = False
                                    TagName = "sec" : TagAttribute = "sec_Sec5"
                                    TempRng = ToSetNodeRangeReturnRng(PRng, TagName, 60, True, sTagTypeAttribute, TagAttribute, True, "", "", True)
                                    Call ToSetNodeRange(TempRng, sTitleTag, 60, True, sTagTypeAttribute, TagAttribute & sTitleTag)

                                Case Regex.IsMatch(LastSectionInfo, "Sec5", RegexOptions.IgnoreCase) AndAlso Regex.IsMatch(sLastTagInfo, "(Sec(1|2|3|4|6))", RegexOptions.IgnoreCase) = False
                                    TagName = "sec" : TagAttribute = "sec_Sec6"
                                    TempRng = ToSetNodeRangeReturnRng(PRng, TagName, 60, True, sTagTypeAttribute, TagAttribute, True, "", "", True)
                                    Call ToSetNodeRange(TempRng, sTitleTag, 60, True, sTagTypeAttribute, TagAttribute & sTitleTag)

                                Case Else
                                    GoTo TagAsPara
                            End Select



                        Case Else
TagAsPara:
                            Select Case True
                                Case Regex.IsMatch(sLastTagInfo, "(Sec|disp-formula|_Fig|_tab)", RegexOptions.IgnoreCase) Or String.IsNullOrEmpty(sLastTagInfo)
                                    Call ToSetNodeRange(PRng, sPTag, 60, True, sTagTypeAttribute, "p_IndTxtPara")

                                Case Regex.IsMatch(sLastTagInfo, "(Ack)", RegexOptions.IgnoreCase)
                                    Call ToSetNodeRange(PRng, sPTag, 70, True, sTagTypeAttribute, "p_AckIndTxtPara")

                                Case Regex.IsMatch(sLastTagInfo, "(App)", RegexOptions.IgnoreCase)
                                    Call ToSetNodeRange(PRng, sPTag, 70, True, sTagTypeAttribute, "p_AppIndTxtPara")

                                Case Regex.IsMatch(sLastTagInfo, "(List)", RegexOptions.IgnoreCase)
                                    Call ToSetNodeRange(PRng, sPTag, 70, True, sTagTypeAttribute, "p_FlushLeftTxtPara")

                                Case Regex.IsMatch(sLastTagInfo, "(IndTxtPara|FlushLeftTxtPara|AppIndTxtPara)", RegexOptions.IgnoreCase)
                                    Call ToSetNodeRange(PRng, sPTag, 70, True, sTagTypeAttribute, "p_FlushLeftTxtPara")
                                    'Case Regex.IsMatch(sLastTagInfo, "Misc", RegexOptions.IgnoreCase)
                                    'Call ToSetNodeRange(PRng, sXTag, 70, True, sTagTypeAttribute, "x_Misc")

                                Case Else
UserInput4Body:
                                    P.Range.Select() : IdentifierValStr = String.Empty ': TempIdentifierRng = P.Range.Duplicate
                                    TempCaptionRng = P.Range.Duplicate
                                    P.Range.HighlightColorIndex = WdColorIndex.wdBrightGreen
                                    WordApp.ActiveWindow.ScrollIntoView(P.Range, True)
                                    frmAuto.TopMost = True : frmAuto.ShowDialog()
                                    P.Range.HighlightColorIndex = WdColorIndex.wdNoHighlight
                                    Call ToAddUserSpecifiedTag(P.Range, IdentifierValStr, False)
                                    'Call ToSetNodeRange(PRng, sXTag, 40, True, sTagTypeAttribute, "unknown", False, False)
                            End Select
                    End Select
                End If
NxtPara:
                oWordDoc.UndoClear()
            Next P
            ToTagBody = True
        Catch ex As Exception
            'sAutoProcessErrorInfo = ex.Message
            Throw ex
        End Try
    End Function

    Private Function ToTagTail(ByVal oWordDoc As Document) As Boolean
        BackRng = ToGetNodeRange(oWordDoc, oWordDoc.Range, "back")
        Try
            '########## Reset module variables ###########
            If BackRng Is Nothing Then ToTagTail = True : Exit Function
            shtList1LeftInfo = 0 : shtList2LeftInfo = 0 : shtList3LeftInfo = 0
            sLastTagInfo = "" : MiscellaneousKey = ""
            PRng = Nothing : P = Nothing : TempRng = Nothing : TempStr = ""
            FigKey = "" : TabKey = "" : FloatsSourceKey = ""
            Ackkey = "" : Appkey = "" : sNextTagInfo = String.Empty
            FigFound = False : TabFound = False : AckFound = False : AppFound = False : bBoxStartFound = False
            TabFNCnt = 0 : FigFNCnt = 0
            TabIDCnt = 0 : FigIDCnt = 0

            'Const sHarvardAuthorPattern As String = "(\w+[\.\,]+)([\s]+)([A-Z][\,\.\s])+"
            Const sHarvardYearPattern As String = "((1[7-9]|20)\d\d[a-z]*[\u2013\u2012\-]+(1[7-9]|20)\d\d[a-z]*|(1[7-9]|20)\d\d[a-z]*|n\.d\.)"
            Const sPageNoPattern As String = "([\d\(\)]+[\:\;]+|[a-z]?[\d]+[\-\u2013\u2012\u2014]+)[a-z]?[\d]+[\.\:]*($)"
            Const sAuthorNamePattern As String = "^(([A-Z][\w\-]+\s[A-Z]{1,3}[\.\,])\s)+"
            Const sPrefixNamePattern As String = "\b([\)\(]+|\-|\u2012|\u2013|Le|La|L\'|Van Der|Van De|Von De|vanden|Vander|Von Der|L\. de|de la|de l\'|d\'|dela|de|Du|Van|Von|di St|di|Jr|Sr|III|VIII|VII|XIII|XIV|XV|XII|XI|IX|IV|VI|II|I|V|X)\b"

            Dim NumberSepCntInt As Integer = StringWithRegMatches(BackRng.Text, "((\[\s*\d\d?\d?\s*\]|\(\s*\d\d?\d?\s*\)|\d\d?\d?))", True, True, False)
            Dim NumberSepBln As Boolean = (NumberSepCntInt) > (BackRng.Paragraphs.Count / 2)
            If BackRng Is Nothing Then ToTagTail = True : Exit Function
            Ackkey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "AckPattern", "", True)
            Appkey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "AppPattern", "", True)
            sExactDeleteKey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "ColorTextExactPattern", "", True)
            sOptionalDeleteKey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "ColorTextInRngPattern", "", True)
            BoxMiscKey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "BoxPattern", "", True, False)
            FigKey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "FigPattern", "", True)
            TabKey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "TabPattern", "", True)
            FloatsSourceKey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "TabAndFigSourcePattern", "", True)


            For Each P In BackRng.Paragraphs
                If P.Range.Information(WdInformation.wdWithInTable) = True Then GoTo Nxt
                TempStr = Trim(P.Range.Text)
                ConfidenceVal = 0 : bAddNextTag = False : bAddLastTag = True : bAddParaInfo = False
                If TempStr = Chr(13) Or TempStr = Chr(11) Or TempStr = Chr(11) & Chr(13) Then GoTo Nxt
                PRng = P.Range : PRng.SetRange(PRng.Start, PRng.End - 1)
                Call ToTrimParagraphSpace(PRng)
                oWordDoc.ActiveWindow.ScrollIntoView(PRng, True)
                Do While Left(TempStr, 1) Like "[.,;:"" ]" : TempStr = Mid(TempStr, 2, Len(TempStr)) : Loop
                If StringWithRegMatches(TempStr, "([0-9]+|[ivx]+)?(\.)?\s*(references?|bibliography|references?\s+and\s+notes?|references?\s+cited|literature?\s+cited?)(\.)?\s*(\.|\:)?", True, True) > 0 Then
                    TempRng = ToSetNodeRangeReturnRng(PRng, "ref-list", 95, True, sTagTypeAttribute, "ref-list")
                    Call ToSetNodeRange(PRng, sTitleTag, 95, True, sTagTypeAttribute, "title_ref-title")
                    RefTitle = True

                ElseIf String.IsNullOrEmpty(sNextTagInfo) = False Then
                    TempVar = sNextTagInfo.Split(SplitSinglePipe, StringSplitOptions.RemoveEmptyEntries)
                    If TempVar.GetUpperBound(0) > 0 Then
                        Call ToSetNodeRange(PRng, TempVar(0), 40, True, sTagTypeAttribute, TempVar(1))
                    Else
                        Call ToSetNodeRange(PRng, TempVar(0), 40, True, sTagTypeAttribute, sNextTagInfo & "_unknown")
                    End If
                    sNextTagInfo = String.Empty

                ElseIf StringWithRegMatches(TempStr, "(([xvi0-9\.\t ]+)?" & Ackkey & ")", True, True) > 0 Then
                    TempRng = ToSetNodeRangeReturnRng(PRng, "ack", 90, True)
                    AckFound = True
                    TempStr = StringWithRegMatchesReturnMatchVal(TempRng.Text, "([xvi0-9\.\t ]+[\.\:\t ]+)", True, False, True)
                    If TempStr <> "" And Not TempRng Is Nothing Then
                        TempRng.SetRange(TempRng.Start, TempRng.Start + Len(TempStr))
                        Call ToSetNodeRange(TempRng, sLabelTag, 90, True, sTagTypeAttribute, "label_Acklabel")
                        TempRng.SetRange(TempRng.Start + Len(TempStr), TempRng.End)
                        Call ToSetNodeRange(TempRng, sTitleTag, 90, True, sTagTypeAttribute, "title_Acktitle")
                    Else
                        Call ToSetNodeRange(TempRng, sTitleTag, 90, True, sTagTypeAttribute, "title_Acktitle")
                    End If

                ElseIf StringWithRegMatches(TempStr, "(([xvi0-9\.\t ]+)?" & Appkey & ")", True, True) > 0 Then
                    TempRng = ToSetNodeRangeReturnRng(PRng, "app", 90, True)
                    AppFound = True
                    TempStr = StringWithRegMatchesReturnMatchVal(TempRng.Text, "(appendix([\s\.\:]+)((\d+[A-Z]|[A-Z]\d+|\d+|[A-Z]?)[\s\.\:]+)+|[xvi0-9\.\t ]+[\.\:\t ]+)", True, False, True)
                    If TempStr <> "" And Not TempRng Is Nothing Then
                        If TempStr.Length + 5 > TempRng.Text.Length Then
                            TempRng.SetRange(TempRng.Start, TempRng.Start + Len(TempStr))
                            Call ToSetNodeRange(TempRng, sLabelTag, 90, True, sTagTypeAttribute, "label_Applabel")
                            TempRng.SetRange(TempRng.Start + Len(TempStr), TempRng.End)
                            Call ToSetNodeRange(TempRng, sTitleTag, 90, True, sTagTypeAttribute, "title_Apptitle")
                        Else
                            Call ToSetNodeRange(TempRng, sTitleTag, 90, True, sTagTypeAttribute, "title_Apptitle")
                        End If
                    End If

                ElseIf StringWithRegMatches(TempStr, sExactDeleteKey, True, True, True) > 0 And PRng.ComputeStatistics(WdStatistic.wdStatisticLines) < 2 Then
                    Call ToSetNodeRange(PRng, sXTag, 40, True, sTagTypeAttribute, "x_Del", False, False)

                ElseIf StringWithRegMatches(TempStr, sOptionalDeleteKey, True, True, False) > 0 And PRng.ComputeStatistics(WdStatistic.wdStatisticLines) < 2 Then
                    Call ToSetNodeRange(PRng, sXTag, 40, True, sTagTypeAttribute, "x_Optional_Del", False, False)

                    '########## Floats validation in the tail matter - Start #############
                ElseIf RegMatchesAndCustomValidate(PRng.Text, FigKey, True, False, True, True) = True And StringWithRegMatches(PRng.Text, FigKey, True, True, False) > 0 And PRng.ComputeStatistics(WdStatistic.wdStatisticLines) < 7 Then
                    TempStr = StringWithRegMatchesReturnMatchVal(PRng.Text, FigKey, True, False, True)
                    FigIDCnt += 1 : FigFound = True : TabFound = False
                    TempRng = ToSetNodeRangeReturnRng(PRng, sFigTag, 90, True, sTagTypeAttribute, sFigTag, False, "id", sFigTag & FigIDCnt)
                    If TempStr <> "" And Not TempRng Is Nothing Then
                        If TempStr.Length + 2 < TempRng.Text.Length Then
                            TempRng.SetRange(TempRng.Start, TempRng.Start + Len(TempStr))
                            Call ToSetNodeRange(TempRng, sLabelTag, 90, True, sTagTypeAttribute, "label_Figlabel")
                            TempRng.SetRange(TempRng.End, PRng.End)
                            Call ToSetNodeRange(TempRng, sTitleTag, 90, True, sTagTypeAttribute, "title_Figtitle")
                        Else
                            Call ToSetNodeRange(TempRng, sTitleTag, 90, True, sTagTypeAttribute, "title_Figtitle", False, True, True)
                        End If
                    End If

                ElseIf RegMatchesAndCustomValidate(PRng.Text, TabKey, True, False, True, True) = True And StringWithRegMatches(PRng.Text, TabKey, True, True, False) > 0 And PRng.ComputeStatistics(WdStatistic.wdStatisticLines) < 7 Then
                    TempStr = StringWithRegMatchesReturnMatchVal(PRng.Text, TabKey, True, False, True)
                    TabIDCnt += 1 : FigFound = False : TabFound = True
                    TempRng = ToSetNodeRangeReturnRng(PRng, sTabTag, 90, True, sTagTypeAttribute, sTabTag, False, "id", "tab" & TabIDCnt)
                    If TempStr <> "" And Not TempRng Is Nothing Then
                        If TempStr.Length + 2 < TempRng.Text.Length Then
                            TempRng.SetRange(TempRng.Start, TempRng.Start + Len(TempStr))
                            Call ToSetNodeRange(TempRng, sLabelTag, 90, True, sTagTypeAttribute, "title_Tablelabel")
                            TempRng.SetRange(TempRng.End, PRng.End)
                            Call ToSetNodeRange(TempRng, sTitleTag, 90, True, sTagTypeAttribute, "title_Tabletitle")
                        Else
                            Call ToSetNodeRange(TempRng, sTitleTag, 90, True, sTagTypeAttribute, "title_Tabletitle", False, True, True)
                        End If
                    End If

                ElseIf StringWithRegMatches(TempStr, sPrefixNoKey & BoxMiscKey, True, True) > 0 Then
                    Call ToSetNodeRange(PRng, sXTag, 40, True, sTagTypeAttribute, "x_BoxStart")
                    bBoxStartFound = True : FigFound = False : TabFound = False : AckFound = False : AppFound = False

                ElseIf ((TabFound = True Or FigFound = True) AndAlso (bBoxStartFound = False) AndAlso (PRng.Characters.First.Font.Superscript = True Or IsNumeric(PRng.Characters.First.Text) = True Or PRng.Characters.First.Text = ChrW(&H2A) Or _
                       PRng.Characters.First.Text = ChrW(&H2020) Or PRng.Characters.First.Text = ChrW(&H2021) Or _
                       StringWithRegMatches(TempStr, FloatsSourceKey, True, False, False) > 0 Or StringWithRegMatches(TempStr, "(\=|[A-Z]+)", False, False, False) > 5)) Then

                    '######### Validate the footnote mark as in superscript #######
                    TempRng = Nothing
                    If PRng.Characters.First.Font.Superscript = True Then
                        TempRng = PRng.Duplicate : TempRng.SetRange(PRng.Start, PRng.Start + 1)
                        Do While TempRng.Characters.Last.Font.Superscript = True
                            TempRng.SetRange(TempRng.Start, TempRng.End + 1)
                        Loop
                        TempRng.SetRange(TempRng.Start, TempRng.End - 1)
                        TempStr = TempRng.Text
                    Else
                        TempStr = StringWithRegMatchesReturnMatchVal(TempStr, "(\d|\u002A|\u2020|\u2021)+", True, False, True)
                    End If
                    Select Case True
                        Case TabFound
                            If String.IsNullOrEmpty(TempStr) = False Then
                                TabFNCnt += 1
                                TempRng = ToSetNodeRangeReturnRng(PRng, "tab-note", 80, True, sTagTypeAttribute, "tab-note_Tabfn", False, "id", "tabfn" & TabFNCnt)
                                TempRng.SetRange(TempRng.Start, TempRng.Start + TempStr.Length)
                                Call ToSetNodeRange(TempRng, sLabelTag, 70, True, sTagTypeAttribute, "label_Tabfnlabel")
                                TempRng.SetRange(TempRng.End, PRng.End)
                                Call ToSetNodeRange(TempRng, sPTag, 70, True, sTagTypeAttribute, "p_Tabfnpara")
                            Else
                                Call ToSetNodeRange(PRng, sFloatsSourceTag, 70, True, sTagTypeAttribute, "tab-source_TabSource")
                            End If

                        Case FigFound
                            If String.IsNullOrEmpty(TempStr) = False Then
                                FigFNCnt += 1
                                TempRng = ToSetNodeRangeReturnRng(PRng, "fig-note", 80, True, sTagTypeAttribute, "fig-note_Figfn", False, "id", "figfn" & FigFNCnt)
                                TempRng.SetRange(TempRng.Start, TempRng.Start + TempStr.Length)
                                Call ToSetNodeRange(TempRng, sLabelTag, 70, True, sTagTypeAttribute, "label_Figfnlabel")
                                TempRng.SetRange(TempRng.End, PRng.End)
                                Call ToSetNodeRange(TempRng, sPTag, 70, True, sTagTypeAttribute, "p_Figfnpara")
                            Else
                                Call ToSetNodeRange(PRng, sFloatsSourceTag, 70, True, sTagTypeAttribute, "fig-source_FigSource")
                            End If
                    End Select
                    '########## Floats validation in the Tail matter - End #############
                ElseIf AckFound = True OrElse AppFound = True Then
                    Select Case True
                        Case Regex.IsMatch(sLastTagInfo, "(Sec|disp-formula|Ack)", RegexOptions.IgnoreCase)
                            Call ToSetNodeRange(PRng, sPTag, 70, True, sTagTypeAttribute, "p_IndTxtPara")

                        Case Regex.IsMatch(sLastTagInfo, "(App)", RegexOptions.IgnoreCase)
                            Call ToSetNodeRange(PRng, sPTag, 70, True, sTagTypeAttribute, "p_AppIndTxtPara")

                        Case Regex.IsMatch(sLastTagInfo, "(List)", RegexOptions.IgnoreCase)
                            Call ToSetNodeRange(PRng, sPTag, 70, True, sTagTypeAttribute, "p_FlushLeftTxtPara")

                        Case Regex.IsMatch(sLastTagInfo, "(IndTxtPara|FlushLeftTxtPara|AppIndTxtPara)", RegexOptions.IgnoreCase)
                            Call ToSetNodeRange(PRng, sPTag, 70, True, sTagTypeAttribute, "p_FlushLeftTxtPara")

                        Case PRng.ComputeStatistics(WdStatistic.wdStatisticLines) < 5
                            GoTo TagRef
                        Case Else
                            GoTo UserInput4Tail
                    End Select

                ElseIf bBoxStartFound = True Then
                    Select Case True
                        Case PRng.Bold = True
                            Call ToSetNodeRange(PRng, sPTag, 70, True, sTagTypeAttribute, "sec_BoxHeadA")
                        Case PRng.Italic = True
                            Call ToSetNodeRange(PRng, sPTag, 70, True, sTagTypeAttribute, "sec_BoxHeadB")

                        Case Regex.IsMatch(sLastTagInfo, "(Sec|disp-formula|Ack)", RegexOptions.IgnoreCase)
                            Call ToSetNodeRange(PRng, sPTag, 70, True, sTagTypeAttribute, "p_BoxParaInd")

                        Case Regex.IsMatch(sLastTagInfo, "(IndTxtPara|FlushLeftTxtPara|AppIndTxtPara)", RegexOptions.IgnoreCase)
                            Call ToSetNodeRange(PRng, sPTag, 70, True, sTagTypeAttribute, "p_BoxParaFlushLeft")
                        Case Else
                            GoTo UserInput4Tail
                    End Select

                ElseIf PRng.ComputeStatistics(WdStatistic.wdStatisticLines) <= 7 Then
TagRef:
                    If StringWithRegMatches(TempStr, "((^|\n|\r)(\[\s*\d+\s*\]|\(\s*\d+\s*\)|\d+\s*\)|\d+)\s*)", True, True, False) > 0 Then
                        TempRng = ToSetNodeRangeReturnRng(PRng, sRefTag, 90, True, sTagTypeAttribute, "Reference")
                        TempStr = StringWithRegMatchesReturnMatchVal(TempRng.Text, "((^|\n|\r)(\[\s*\d+\s*\]|\(\s*\d+\s*\)|\d+\s*\)|\d+)[\.\:\s\t\-]+\s*)", True, False, True)
                        If (NumberSepBln = True And String.IsNullOrEmpty(TempStr) = True) Then
                            TempStr = StringWithRegMatchesReturnMatchVal(TempRng.Text, "((^|\n|\r)(\[\s*\d+\s*\]|\(\s*\d+\s*\)|\d+\s*\)|\d+)\s*)", True, False, True)
                        End If
                        If TempStr <> "" And Not TempRng Is Nothing And TempRng.Text.Length > 20 Then
                            TempRng.SetRange(TempRng.Start, TempRng.Start + Len(TempStr))
                            Call ToSetNodeRange(TempRng, sLabelTag, 90, True, sTagTypeAttribute, "label_Reflabel")
                            TempRng.SetRange(TempRng.End, PRng.End)
                            Call ToSetNodeRange(TempRng, sCitationTag, 90, True, sTagTypeAttribute, "citation_Refcitaion", bAddParaInfo, True, bAddNextTag)
                        Else
                            Call ToSetNodeRange(TempRng, sCitationTag, 40, True, sTagTypeAttribute, "citation_Refcitaion", bAddParaInfo, True, bAddNextTag)
                        End If

                    ElseIf Regex.IsMatch(TempStr, sHarvardYearPattern, RegexOptions.IgnoreCase) = True Then
                        Dim sAuthorNameText As String = Regex.Match(TempStr, "(.*)((1[7-9]|20)\d\d[a-z]*|n\.d\.|(1[7-9]|20)\d\d[a-z]*[\u2013\u2012\-]+(1[7-9]|20)\d\d[a-z]*)(...*)", RegexOptions.IgnoreCase).Groups(1).Value
                        If String.IsNullOrEmpty(sAuthorNameText) = False Then
                            sAuthorNameText = Regex.Replace(sAuthorNameText, sPrefixNamePattern, String.Empty, RegexOptions.IgnoreCase)
                            Dim sNameText As String = Regex.Replace(TempStr, sPrefixNamePattern, String.Empty, RegexOptions.IgnoreCase)
                            Dim iWordCnt As Integer = Regex.Matches(sAuthorNameText, "(\w+)", RegexOptions.IgnoreCase).Count
                            Dim iPunctuationCnt As Integer = Regex.Matches(sAuthorNameText, "([\.\,]+)", RegexOptions.IgnoreCase).Count
                            If iPunctuationCnt >= iWordCnt OrElse Regex.IsMatch(TempStr, sPageNoPattern, RegexOptions.IgnoreCase) = True OrElse Regex.IsMatch(sNameText, sAuthorNamePattern, RegexOptions.None) = True Then
                                Call ToSetNodeRangeReturnRng(PRng, sRefTag, 90, True, sTagTypeAttribute, "Reference")
                            Else
                                GoTo UserInput4Tail
                            End If
                        Else
                            GoTo UserInput4Tail
                        End If
                        'ElseIf Regex.IsMatch(sLastTagInfo, "(citation)", RegexOptions.IgnoreCase) = True AndAlso ToCheckEndLinePunctuations(PRng.Previous.Paragraphs(1).Range.Text, 3, "(\.)") = False Then
                        'Call ToSetNodeRange(PRng, sCitationTag, 40, True, sTagTypeAttribute, "citation_Refcitaion", bAddParaInfo, True, bAddNextTag)
                    Else
                        GoTo UserInput4Tail
                    End If
                Else
UserInput4Tail:
                    P.Range.Select() : IdentifierValStr = String.Empty ': TempIdentifierRng = P.Range.Duplicate
                    TempCaptionRng = P.Range.Duplicate
                    P.Range.HighlightColorIndex = WdColorIndex.wdBrightGreen
                    WordApp.ActiveWindow.ScrollIntoView(P.Range, True)
                    frmAuto.TopMost = True : frmAuto.ShowDialog()
                    P.Range.HighlightColorIndex = WdColorIndex.wdNoHighlight
                    Call ToAddUserSpecifiedTag(P.Range, IdentifierValStr, False)
                    'Call ToSetNodeRange(PRng, sXTag, 40, True, sTagTypeAttribute, "unknown", bAddParaInfo, True, bAddNextTag)
                End If
Nxt:
                oWordDoc.UndoClear()
            Next P
            ToTagTail = True
        Catch ex As Exception
            Throw ex
        End Try
    End Function

    Private Function ToTagFloats(ByVal oWordDoc As Document) As Boolean
        FloatRng = ToGetNodeRange(oWordDoc, oWordDoc.Range, "floats-wrap")
        Try
            If FloatRng Is Nothing Then ToTagFloats = True : Exit Function
            '########## Reset module variables ###########
            AckFound = False : AppFound = False : sLastTagInfo = "" : sNextTagInfo = String.Empty
            FigKey = "" : TabKey = "" : FloatsSourceKey = ""
            TabFNCnt = 0 : FigFNCnt = 0
            TabIDCnt = 0 : FigIDCnt = 0
            PRng = Nothing : P = Nothing : TempRng = Nothing : TempStr = ""

            FigKey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "FigPattern", "", True)
            TabKey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "TabPattern", "", True)
            FloatsSourceKey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "TabAndFigSourcePattern", "", True)

            sExactDeleteKey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "ColorTextExactPattern", "", True)
            sOptionalDeleteKey = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "ColorTextInRngPattern", "", True)

            For Each P In FloatRng.Paragraphs
                If P.Range.Information(WdInformation.wdWithInTable) = True Then GoTo Nxt
                TempStr = Trim(P.Range.Text) : ConfidenceVal = 0
                If TempStr = Chr(13) Or TempStr = Chr(11) Or TempStr = Chr(11) & Chr(13) Then GoTo Nxt
                PRng = P.Range : PRng.SetRange(PRng.Start, PRng.End - 1)
                Call ToTrimParagraphSpace(PRng)
                oWordDoc.ActiveWindow.ScrollIntoView(PRng, True)
                Do While Left(TempStr, 1) Like "[.,;:"" ]" : TempStr = Mid(TempStr, 2, Len(TempStr)) : Loop

                If String.IsNullOrEmpty(sNextTagInfo) = False Then
                    TempVar = sNextTagInfo.Split(SplitSinglePipe, StringSplitOptions.RemoveEmptyEntries)
                    If TempVar.GetUpperBound(0) > 0 Then
                        Call ToSetNodeRange(PRng, TempVar(0), 40, True, sTagTypeAttribute, TempVar(1))
                    Else
                        Call ToSetNodeRange(PRng, TempVar(0), 40, True, sTagTypeAttribute, sNextTagInfo & "_unknown")
                    End If
                    sNextTagInfo = String.Empty

                ElseIf StringWithRegMatches(PRng.Text, FigKey, True, True, False) > 0 Then
                    TempStr = StringWithRegMatchesReturnMatchVal(PRng.Text, FigKey, True, False, True)
                    FigIDCnt += 1 : FigFound = True : TabFound = False
                    TempRng = ToSetNodeRangeReturnRng(PRng, sFigTag, 90, True, sTagTypeAttribute, sFigTag, False, "id", sFigTag & FigIDCnt)
                    If TempStr <> "" And Not TempRng Is Nothing Then
                        If TempStr.Length + 2 < TempRng.Text.Length Then
                            TempRng.SetRange(TempRng.Start, TempRng.Start + Len(TempStr))
                            Call ToSetNodeRange(TempRng, sLabelTag, 90, True, sTagTypeAttribute, "label_Figlabel")
                            TempRng.SetRange(TempRng.End, PRng.End)
                            Call ToSetNodeRange(TempRng, sTitleTag, 90, True, sTagTypeAttribute, "title_Figtitle")
                        Else
                            Call ToSetNodeRange(TempRng, sTitleTag, 90, True, sTagTypeAttribute, "title_Figtitle", False, True, True)
                        End If
                    End If

                ElseIf StringWithRegMatches(PRng.Text, TabKey, True, True, False) > 0 Then
                    TempStr = StringWithRegMatchesReturnMatchVal(PRng.Text, TabKey, True, False, True)
                    TabIDCnt += 1 : FigFound = False : TabFound = True
                    TempRng = ToSetNodeRangeReturnRng(PRng, sTabTag, 90, True, sTagTypeAttribute, sTabTag, False, "id", "tab" & TabIDCnt)
                    If TempStr <> "" And Not TempRng Is Nothing Then
                        If TempStr.Length + 2 < TempRng.Text.Length Then
                            TempRng.SetRange(TempRng.Start, TempRng.Start + Len(TempStr))
                            Call ToSetNodeRange(TempRng, sLabelTag, 90, True, sTagTypeAttribute, "label_Tablelabel")
                            TempRng.SetRange(TempRng.End, PRng.End)
                            Call ToSetNodeRange(TempRng, sTitleTag, 90, True, sTagTypeAttribute, "title_Tabletitle")
                        Else
                            Call ToSetNodeRange(TempRng, sTitleTag, 90, True, sTagTypeAttribute, "title_Tabletitle", False, True, True)
                        End If
                    End If

                ElseIf StringWithRegMatches(TempStr, sExactDeleteKey, True, True, True) > 0 And PRng.ComputeStatistics(WdStatistic.wdStatisticLines) < 2 Then
                    Call ToSetNodeRange(PRng, sXTag, 40, True, sTagTypeAttribute, "x_Del", False, False)

                ElseIf StringWithRegMatches(TempStr, sOptionalDeleteKey, True, True, False) > 0 And PRng.ComputeStatistics(WdStatistic.wdStatisticLines) < 2 Then
                    Call ToSetNodeRange(PRng, sXTag, 40, True, sTagTypeAttribute, "x_Optional_Del", False, False)

                ElseIf ((TabFound = True Or FigFound = True) AndAlso (bBoxStartFound = False) AndAlso (PRng.Characters.First.Font.Superscript = True Or IsNumeric(PRng.Characters.First.Text) = True Or PRng.Characters.First.Text = ChrW(&H2A) Or _
                        PRng.Characters.First.Text = ChrW(&H2020) Or PRng.Characters.First.Text = ChrW(&H2021) Or _
                        StringWithRegMatches(TempStr, FloatsSourceKey, True, False, False) > 0 Or StringWithRegMatches(TempStr, "(\=|[A-Z]+)", False, False, False) > 5)) Then

                    '######### Validate the footnote mark as in superscript #######
                    TempRng = Nothing
                    If PRng.Characters.First.Font.Superscript = True Then
                        TempRng = PRng.Duplicate : TempRng.SetRange(PRng.Start, PRng.Start + 1)
                        Do While TempRng.Characters.Last.Font.Superscript = True
                            TempRng.SetRange(TempRng.Start, TempRng.End + 1)
                        Loop
                        TempRng.SetRange(TempRng.Start, TempRng.End - 1)
                        TempStr = TempRng.Text
                    Else
                        TempStr = StringWithRegMatchesReturnMatchVal(TempStr, "(\d|\u002A|\u2020|\u2021)+", True, False, True)
                    End If
                    Select Case True
                        Case TabFound
                            If String.IsNullOrEmpty(TempStr) = False Then
                                TabFNCnt += 1
                                TempRng = ToSetNodeRangeReturnRng(PRng, "tab-note", 80, True, sTagTypeAttribute, "tab-note_Tabfn", False, "id", "tabfn" & TabFNCnt)
                                TempRng.SetRange(TempRng.Start, TempRng.Start + TempStr.Length)
                                Call ToSetNodeRange(TempRng, sLabelTag, 70, True, sTagTypeAttribute, "label_Tabfnlabel")
                                TempRng.SetRange(TempRng.End, PRng.End)
                                Call ToSetNodeRange(TempRng, sPTag, 70, True, sTagTypeAttribute, "p_Tabfnpara")
                            Else
                                Call ToSetNodeRange(PRng, sFloatsSourceTag, 70, True, sTagTypeAttribute, "tab-source_TabSource")
                            End If

                        Case FigFound
                            If String.IsNullOrEmpty(TempStr) = False Then
                                FigFNCnt += 1
                                TempRng = ToSetNodeRangeReturnRng(PRng, "fig-note", 80, True, sTagTypeAttribute, "fig-note_Figfn", False, "id", "figfn" & FigFNCnt)
                                TempRng.SetRange(TempRng.Start, TempRng.Start + TempStr.Length)
                                Call ToSetNodeRange(TempRng, sLabelTag, 70, True, sTagTypeAttribute, "label_Figfnlabel")
                                TempRng.SetRange(TempRng.End, PRng.End)
                                Call ToSetNodeRange(TempRng, sPTag, 70, True, sTagTypeAttribute, "p_Figfnpara")
                            Else
                                Call ToSetNodeRange(PRng, sFloatsSourceTag, 70, True, sTagTypeAttribute, "fig-source_FigSource")
                            End If
                    End Select
                Else
                    Select Case True
                        Case TabFound : TempRng = ToSetNodeRangeReturnRng(PRng, sFloatsSourceTag, 70, True, sTagTypeAttribute, "tab-source_TabSource", False, "id", "Tab" & TabIDCnt & "source")
                        Case FigFound : TempRng = ToSetNodeRangeReturnRng(PRng, sFloatsSourceTag, 70, True, sTagTypeAttribute, "fig-source_FigSource", False, "id", sFigTag & FigIDCnt & "source")
                        Case Else
                            P.Range.Select() : IdentifierValStr = String.Empty ': TempIdentifierRng = P.Range.Duplicate
                            TempCaptionRng = P.Range.Duplicate
                            P.Range.HighlightColorIndex = WdColorIndex.wdBrightGreen
                            WordApp.ActiveWindow.ScrollIntoView(P.Range, True)
                            frmAuto.TopMost = True : frmAuto.ShowDialog()
                            P.Range.HighlightColorIndex = WdColorIndex.wdNoHighlight
                            Call ToAddUserSpecifiedTag(P.Range, IdentifierValStr, False)
                    End Select
                End If
Nxt:
                oWordDoc.UndoClear()
            Next P
            ToTagFloats = True
        Catch ex As Exception
            'sAutoProcessErrorInfo = ex.Message
            Throw ex
        End Try
    End Function


    Private Function ToCollectParaInfo(ByVal PRng As Range, Optional ByVal AddToCollection As Boolean = False)
        Dim TempInfoStr As String
        If PRng Is Nothing Then Exit Function
        If PRng.Characters.Last.Text = Chr(13) Then PRng.SetRange(PRng.Start, PRng.End - 1)
        If PRng.InlineShapes.Count > 0 Or IdentifierValStr.Contains("del") = True Or IdentifierValStr.Contains("runon") = True Then Exit Function
        Dim StyObj As Style

        StyObj = PRng.Style
        TempInfoStr = "Style=" & StyObj.NameLocal
        TempInfoStr = TempInfoStr & "|" & "FS=" & PRng.Font.Size

        Select Case PRng.Font.AllCaps
            Case True : TempInfoStr = TempInfoStr & "|FAC=True"
            Case False : TempInfoStr = TempInfoStr & "|FAC=False"
        End Select

        Select Case PRng.Font.SmallCaps
            Case True : TempInfoStr = TempInfoStr & "|FSC=True"
            Case False : TempInfoStr = TempInfoStr & "|FSC=False"
        End Select

        Select Case PRng.Font.Bold
            Case True : TempInfoStr = TempInfoStr & "|FB=True"
            Case False : TempInfoStr = TempInfoStr & "|FB=False"
        End Select

        Select Case PRng.Font.Italic
            Case True : TempInfoStr = TempInfoStr & "|FI=True"
            Case False : TempInfoStr = TempInfoStr & "|FI=False"
        End Select

        Select Case PRng.Font.Underline
            Case True : TempInfoStr = TempInfoStr & "|FU=True"
            Case False : TempInfoStr = TempInfoStr & "|FU=False"
        End Select

        If AddToCollection = True And IdentifierValStr <> String.Empty Then
            If ParaInfoCollection.ContainsKey(TempInfoStr) = False Then
                ParaInfoCollection.Add(TempInfoStr, IdentifierValStr)
            Else
                ParaInfoCollection.Remove(TempInfoStr)
                ParaInfoCollection.Add(TempInfoStr, IdentifierValStr)
            End If
        End If

        If ParaInfoCollection.Count > 0 Then
            Dim Ikey As DictionaryEntry
            For Each Ikey In ParaInfoCollection
                Select Case True
                    Case Ikey.Key.ToString.Contains(TempInfoStr)
                        IdentifierValStr = Ikey.Value : Exit For
                    Case Else ' Do Nothing
                End Select
            Next
        End If
    End Function


    Private Function ToSetNodeRange(ByRef NodeRng As Range, ByVal NodeName As String, Optional ByVal ConfidenceValue As Integer = 0, Optional ByVal TrimNodeRng As Boolean = True, Optional ByVal AttributeName As String = "", Optional ByVal AttributeValue As String = "", Optional ByVal bAddToParaInfo As Boolean = False, Optional ByVal bAddsLastTagInfo As Boolean = True, Optional ByVal bAddsNextTagInfo As Boolean = False) As Boolean
        Dim SetNode As XMLNode
        If NodeRng Is Nothing Then Exit Function
        Try
            Do While NodeRng.Characters.First.Text = Chr(13) OrElse NodeRng.Characters.First.Text = " "
                NodeRng.SetRange(NodeRng.Start + 1, NodeRng.End)
            Loop
            Do While NodeRng.Characters.Last.Text = Chr(13) OrElse NodeRng.Characters.Last.Text = " "
                NodeRng.SetRange(NodeRng.Start, NodeRng.End - 1)
            Loop
            Do While NodeRng.Characters.First.XMLNodes.Count > 0 AndAlso NodeRng.Characters.First Is Nothing
                NodeRng.SetRange(NodeRng.Start + 1, NodeRng.End)
            Loop
            Do While NodeRng.Characters.Last.XMLNodes.Count > 0 AndAlso NodeRng.Characters.First Is Nothing
                NodeRng.SetRange(NodeRng.Start, NodeRng.End - 1)
            Loop


            If Regex.IsMatch(AttributeValue, "((fig(ure)?|tab(le)?|box)(label)|(label_)(sec|ack|app|reflabel))", RegexOptions.IgnoreCase) = False Then
                Do While NodeRng.Characters.Last.Text = " "
                    NodeRng.Characters.Last.Text = String.Empty
                Loop
                Do While NodeRng.Characters.Last.Text = vbTab
                    NodeRng.Characters.Last.Text = String.Empty
                Loop
            End If
            '####### To Reset the table and figure found var. ###########
            If Regex.IsMatch(AttributeValue, "(Tabfn|figfn|TabSource|FigSource|fig|tab)", RegexOptions.IgnoreCase) = False Then TabFound = False : FigFound = False
            If Regex.IsMatch(AttributeValue, "(boxstart)", RegexOptions.IgnoreCase) = False Then bBoxStartFound = False
            '########### #############################################

            If Regex.IsMatch(NodeName, "(list-item)", RegexOptions.IgnoreCase) = True Then
                Dim intLeftIndent As Integer = NodeRng.Paragraphs.Item(1).LeftIndent
                Select Case True
                    Case shtList1LeftInfo = 0
                        AttributeValue = AttributeValue & "1"
                        shtList1LeftInfo = intLeftIndent + 3

                    Case shtList1LeftInfo >= intLeftIndent
                        AttributeValue = AttributeValue & "1"

                    Case shtList2LeftInfo = 0
                        AttributeValue = AttributeValue & "2"
                        shtList2LeftInfo = intLeftIndent + 3

                    Case shtList2LeftInfo >= intLeftIndent
                        AttributeValue = AttributeValue & "2"

                    Case shtList3LeftInfo = 0
                        AttributeValue = AttributeValue & "3"
                        shtList3LeftInfo = intLeftIndent + 3

                    Case shtList3LeftInfo >= intLeftIndent
                        AttributeValue = AttributeValue & "3"

                    Case Else
                        AttributeValue = AttributeValue & "4"
                End Select
            End If
            If Regex.IsMatch(NodeName, "(sec)", RegexOptions.IgnoreCase) = True Then LastSectionInfo = AttributeValue
            If bAddToParaInfo = True Then Call ToSetAndGetParaInfo(NodeRng, False, NodeName, AttributeValue)

            SetNode = NodeRng.XMLNodes.Add(NodeName, URI, NodeRng)
            NodeRng = SetNode.Range : NodeRng.SetRange(NodeRng.Start - 1, NodeRng.End + 1)
            Select Case ConfidenceValue
                Case Is > 100 : ConfidenceValue = 100
                Case Is = 0 : ConfidenceValue = 10
            End Select
            SetNode.Attributes.Add("confidence", "").NodeValue = ConfidenceValue


            '######## To set Last tag info for the reason of avoiding mistagged #####
            If AttributeName <> "" And AttributeValue <> "" Then
                SetNode.Attributes.Add(AttributeName, "").NodeValue = AttributeValue
                If bAddsLastTagInfo = True Then sLastTagInfo = " " & NodeName & " | " & AttributeValue & " "
            Else
                If bAddsLastTagInfo = True Then sLastTagInfo = NodeName
            End If

            '######## To set Next tag info for the reason of spliting information (i.e. Title : vbcr <title>Text</title>) #####
            If bAddsNextTagInfo = True Then
                sNextTagInfo = NodeName & "|" & AttributeValue
            Else
                sNextTagInfo = String.Empty
            End If

            If Not (NodeRng Is Nothing) Then
                If NodeRng.Bookmarks.Count > 0 Then
                    Dim bkQuery As Bookmark : Dim strBKName As String = "" : Dim cmtQuery As Comment = Nothing
                    For Each bkQuery In NodeRng.Bookmarks
                        strBKName = bkQuery.Name
                        Select Case True
                            Case Regex.IsMatch(strBKName, "SecQuery", RegexOptions.IgnoreCase)
                                cmtQuery = NodeRng.Comments.Add(NodeRng, "Please verify the coding of this line as a heading.")
                                cmtQuery.Author = "AutoStyle"
                            Case Else
                        End Select
                        bkQuery.Delete()
                    Next
                End If
            End If
            ToSetNodeRange = True
        Catch ex As Exception
            Throw ex
            'sAutoProcessErrorInfo = ex.Message
        End Try
    End Function

    Private Function ToSetNodeRangeReturnRng(ByRef NodeRng As Range, ByVal NodeName As String, Optional ByVal ConfidenceValue As Integer = 0, Optional ByVal TrimNodeRng As Boolean = True, Optional ByVal AttributeName1 As String = "", Optional ByVal AttributeValue1 As String = "", Optional ByVal bAddToParaInfo As Boolean = False, Optional ByVal AttributeName2 As String = "", Optional ByVal AttributeValue2 As String = "", Optional ByVal bAddsLastTagInfo As Boolean = True) As Range
        Dim SetNode As XMLNode
        Try
            Do While NodeRng.Characters.First.Text = Chr(13) OrElse NodeRng.Characters.First.Text = " "
                NodeRng.SetRange(NodeRng.Start + 1, NodeRng.End)
            Loop
            Do While NodeRng.Characters.Last.Text = Chr(13) OrElse NodeRng.Characters.Last.Text = " "
                NodeRng.SetRange(NodeRng.Start, NodeRng.End - 1)
            Loop
            Do While NodeRng.Characters.First.XMLNodes.Count > 0 AndAlso NodeRng.Characters.First Is Nothing
                NodeRng.SetRange(NodeRng.Start + 1, NodeRng.End)
            Loop
            Do While NodeRng.Characters.Last.XMLNodes.Count > 0 AndAlso NodeRng.Characters.First Is Nothing
                NodeRng.SetRange(NodeRng.Start, NodeRng.End - 1)
            Loop
            'Do While NodeRng.Characters.First.Text = Chr(13)
            '    NodeRng.SetRange(NodeRng.Start + 1, NodeRng.End)
            'Loop
            'Do While NodeRng.Characters.Last.Text = Chr(13)
            '    NodeRng.SetRange(NodeRng.Start, NodeRng.End - 1)
            'Loop

            'If WordDoc.ActiveWindow.View.ShowXMLMarkup = True Then
            '    Do While NodeRng.Characters.First.XMLNodes.Count > 0
            '        NodeRng.SetRange(NodeRng.Start + 1, NodeRng.End)
            '    Loop
            '    Do While NodeRng.Characters.Last.XMLNodes.Count > 0
            '        NodeRng.SetRange(NodeRng.Start, NodeRng.End - 1)
            '    Loop
            'End If


            If Regex.IsMatch(AttributeValue1, "((fig(ure)?|tab(le)?|box)(label)|(label_)(sec|ack|app))", RegexOptions.IgnoreCase) = False Then
                Do While NodeRng.Characters.Last.Text = " "
                    NodeRng.Characters.Last.Delete()
                Loop
                Do While NodeRng.Characters.Last.Text = vbTab
                    NodeRng.Characters.Last.Delete()
                Loop
            End If
            If Regex.IsMatch(NodeName, "(sec)", RegexOptions.IgnoreCase) = True Then LastSectionInfo = AttributeValue1
            If bAddToParaInfo = True Then Call ToSetAndGetParaInfo(NodeRng, False, NodeName, AttributeValue1)

            SetNode = NodeRng.XMLNodes.Add(NodeName, URI, NodeRng)
            Select Case ConfidenceValue
                Case Is > 100 : ConfidenceValue = 100
                Case Is = 0 : ConfidenceValue = 10
                Case Else : ToSetNodeRangeReturnRng = Nothing
            End Select
            SetNode.Attributes.Add("confidence", "").NodeValue = ConfidenceValue
            If AttributeName1 <> "" And AttributeValue1 <> "" Then
                SetNode.Attributes.Add(AttributeName1, "").NodeValue = AttributeValue1
                If AttributeName2 <> "" And AttributeValue2 <> "" Then SetNode.Attributes.Add(AttributeName2, "").NodeValue = AttributeValue2
                If bAddsLastTagInfo = True Then sLastTagInfo = sLastTagInfo & "|" & NodeName
            Else
                If bAddsLastTagInfo = True Then sLastTagInfo = NodeName
            End If
            ToSetNodeRangeReturnRng = SetNode.Range
        Catch ex As Exception
            Throw ex
            'sAutoProcessErrorInfo = ex.Message
            ToSetNodeRangeReturnRng = Nothing
        End Try
    End Function


    Private Function ToGetNodeRange(ByVal oWordDoc As Document, ByVal NodeRng As Range, ByVal NodeName As String, Optional ByVal TrimNodeRng As Boolean = True) As Range
        Dim Xnode As XMLNode
        ToGetNodeRange = Nothing
        Dim strElement As String = "//x:" & NodeName
        Dim strPrefix As String = "xmlns:x=""AS"""

        Xnode = oWordDoc.SelectSingleNode(strElement, strPrefix)
        If Not (Xnode Is Nothing) Then ToGetNodeRange = Xnode.Range
        If ToGetNodeRange Is Nothing Then
            For Each Xnode In NodeRng.XMLNodes
                If Xnode.BaseName.ToLower() = NodeName.ToLower() Then
                    ToGetNodeRange = Xnode.Range
                    Exit For
                End If
            Next
        End If
        If TrimNodeRng = True Then
            If Not ToGetNodeRange Is Nothing Then
                Do While ToGetNodeRange.Characters.First.Text = Chr(13) Or ToGetNodeRange.Characters.First.XMLNodes.Count > 0
                    ToGetNodeRange.SetRange(ToGetNodeRange.Start + 1, ToGetNodeRange.End)
                Loop
                Do While ToGetNodeRange.Characters.Last.Text = Chr(13) Or ToGetNodeRange.Characters.Last.XMLNodes.Count > 0
                    ToGetNodeRange.SetRange(ToGetNodeRange.Start, ToGetNodeRange.End - 1)
                Loop
            End If
        End If
    End Function

    ''' <summary>This is help to identify the documents main parts (i.e. head, body, tail, floats) </summary>
    ''' <param name="oWordDoc">which document we need to process</param>
    ''' <remarks>Last updated : #7/14/2011 2:46:04 PM# </remarks>

    Private Function ToIdentifyDocumentPart(ByVal oWordDoc As Document) As Boolean
        Dim HeadPattern As String, BodyPattern As String, TailPattern As String, MoveFloatsPattern As String, FPattern As String = ""
        Dim SplitSecPattern As String
        Dim I As Integer, Cnt As Integer
        Dim TotalRng As Range = oWordDoc.Range : Dim FRng As Range
        Dim WordApp As Application = oWordDoc.Application
        Dim rMatches As MatchCollection

        SplitSecPattern = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "SplitSectionPattern", "", True)
        SplitSecPattern = "(\n|\r|^)([0-9ivx\.\:\s]*)" & SplitSecPattern & "([\.\:]+\s*)" '"((\n|\r|^)([0-9ivx\.\:\s]*)(acknowledge?ments?)([\.\:\s]*))"
        HeadPattern = "((\n|\r|^)([0-9ivx\.\:\s]*)(introduction|background|main text)([\.\:\s]*)(\n|\r|^))"
        BodyPattern = "((\n|\r|^)([0-9ivx\.\:\s]*)(bibliographic references?|references?|bibliography|references?\s+and\s+notes?|references?\s+cited|literature?\s+cited?)([\.\:\s]*))"
        TailPattern = "(\n|\r|^)(((Figure|Fig|Table|Tab|Scheme|Chart|Plate|Map|Diagram)[s]?(\.)?\s*((([0-9ivx](\s*([A-z](\s*(-|\.|\,|and|\&)\s*[A-z])+|\([A-z]\)(\s*(-|\.|\,|and|\&)\s*\([A-z]\))+|\([A-z]\)))*)(\s*(-|\.|\,|and|\&)\s*[0-9ivx])*)+(\.|\:|\-|\u2013|\u2014)))|(([0-9ivx\.\:\s]*)(table(s)?\s*list|figure\s*list|table(s)?\s*legend|figure\s*legend|figure\s*caption|legend\s*to\s*figure|list\s*of\s*figure\s*caption|list\s*of\s*figure|Table\s*(and|\&)\s*Figure\s*Caption(s)?|(legend|caption|list)(s)?(\s+\w+){1,3}|(figure|tab(le))(s)? title(s)? (and|\&) legend(s)?|(Tables|Figures)[\.|\:])[s]?\s*[\:\.]?))"
        MoveFloatsPattern = "((\n|\r|^)(Figure|Fig|Table|Tab|Scheme|Chart|Plate|Map|Diagram)[s]?(\.)?\s*(([0-9ivx](\s*(-|\.|\,|and|\&)\s*[0-9ivx])*)+(\.|\:)))"

        '######## For Sri Validation #########
        'Dim LCnt As Integer = TotalRng.ComputeStatistics(WdStatistic.wdStatisticLines)
        'Dim J As Integer = CInt(LCnt * 0.1)
        'WordApp.Selection.GoTo(What:=WdGoToItem.wdGoToLine, Which:=WdGoToDirection.wdGoToFirst, Count:=J)
        'If WordApp.Selection.Find.Execute = True Then
        '    WordApp.Selection.Range.Select()
        '    oWordDoc.Bookmarks.Add("BodyStart", WordApp.Selection.Range)
        '    WordApp.Selection.Collapse(WdCollapseDirection.wdCollapseStart)
        'End If
        '######### Split Main headings ###########
        TotalRng = oWordDoc.Range : FRng = TotalRng.Duplicate
        FRng.Find.ClearFormatting() : FRng.Find.Replacement.ClearFormatting()
        Dim RegOptions As RegexOptions = RegexOptions.IgnoreCase
        rMatches = Regex.Matches(TotalRng.Text, SplitSecPattern, RegexOptions.IgnoreCase)
        For Each rMatch As Match In rMatches
            If String.IsNullOrEmpty(rMatch.Value) = False Then
                FRng.Find.Text = rMatch.Value
                Do While FRng.Find.Execute = True
                    If FRng.Characters.Last.Text <> Chr(13) Then
                        TempStr = StringWithRegMatchesReturnMatchVal(FRng.Text, SplitSecPattern)
                        If TempStr.Length + 2 > FRng.Text.Length Then
                            TempRng = FRng.Duplicate
                            TempRng.SetRange(FRng.Start, FRng.Start + TempStr.Length)
                            TempRng.InsertAfter(Chr(13))
                        End If
                    End If
                    FRng.Collapse(WdCollapseDirection.wdCollapseEnd)
                Loop
            End If
        Next

        '######### Split Main headings ###########
        For I = 1 To 4
            Select Case I
                Case 1 : FPattern = HeadPattern
                Case 2 : FPattern = BodyPattern
                Case 3 : FPattern = TailPattern
                Case 4 : FPattern = MoveFloatsPattern
            End Select
            rMatches = Regex.Matches(TotalRng.Text, FPattern, RegexOptions.IgnoreCase)
            Cnt = 0 : FRng = TotalRng.Duplicate : FRng.Find.ClearFormatting() : FRng.Find.Replacement.ClearFormatting()
            For Each rMatch As Match In rMatches
                Select Case I
                    Case 1 : FRng.Find.Text = CStr(rMatch.Value)
                    Case 2 : FRng.Find.Text = CStr(rMatch.Value)
                    Case 3 : FRng.Find.Text = CStr(rMatch.Value)
                    Case 4 : FRng.Find.Text = CStr(rMatch.Value)
                End Select
                If FRng.Find.Execute = True And (FloatRng Is Nothing Or I = 4) Then
                    Cnt = Cnt + 1 : FRng.SetRange(FRng.Start + 1, FRng.End)
                    'FRng.Select()
                    If I = 2 And (Cnt <> 1 And Not BackRng Is Nothing) Then GoTo NxtMatch '########## Avoid the repeated pattern match for e.g REFERENCE term found more than one
                    If (I = 1 Or I = 2) And (Cnt <> rMatches.Count) Then GoTo NxtMatch '########## Catch the last occurences of pattern i.e some times abstract section head as introduction, head matter also contain REFERENCE count = 20  
                    '######## To skip if the head part contain table/figure count - Start ########### 
                    If I = 3 And Not HeadRng Is Nothing Then
                        If FRng.InRange(HeadRng) = True Then GoTo NxtMatch
                    End If
                    '######## To skip if the head part contain table/figure count - End ########### 
                    Select Case I
                        Case 1
                            HeadRng = oWordDoc.Range(TotalRng.Start, FRng.Start - 1)
                            BodyRng = oWordDoc.Range(FRng.Start, oWordDoc.Range.End)

                        Case 2
                            If Not (BodyRng Is Nothing) Then
                                BodyRng = oWordDoc.Range(BodyRng.Start, FRng.Start - 1)
                                BackRng = oWordDoc.Range(FRng.Start, oWordDoc.Range.End)
                            ElseIf HeadRng Is Nothing Then
                                TempRng = Nothing
                                TempRng = ToGetBodyStartRng(oWordDoc)
                                If Not TempRng Is Nothing Then
                                    HeadRng = oWordDoc.Range(TotalRng.Start, TempRng.Start - 1)
                                    BodyRng = oWordDoc.Range(TempRng.Start, FRng.Start - 1)
                                    BackRng = oWordDoc.Range(FRng.Start, oWordDoc.Range.End)
                                End If
                            End If

                        Case 3
                            If Not (BackRng Is Nothing) Then
                                If FRng.Start < BackRng.Start Then GoTo NxtMatch
                                BackRng = oWordDoc.Range(BackRng.Start, FRng.Start - 1)
                                FloatRng = oWordDoc.Range(FRng.Start, oWordDoc.Range.End)
                                GoTo NxtI

                            ElseIf Not (BodyRng Is Nothing) Then
                                BackRng = Nothing
                                BodyRng.SetRange(BodyRng.Start, FRng.Start - 1)
                                FloatRng = oWordDoc.Range(FRng.Start, oWordDoc.Range.End)
                                GoTo NxtI


                            ElseIf Not (HeadRng Is Nothing) Then
                                TempRng = Nothing
                                TempRng = ToGetBodyStartRng(oWordDoc)
                                If Not TempRng Is Nothing Then
                                    HeadRng = oWordDoc.Range(TotalRng.Start, TempRng.Start - 1)
                                    BodyRng = oWordDoc.Range(TempRng.Start, FRng.Start - 1)
                                    FloatRng = oWordDoc.Range(FRng.Start, oWordDoc.Range.End)
                                    BackRng = Nothing
                                    GoTo NxtI
                                End If
                            End If

                        Case 4
                            Dim TempStr As String = ""
                            Select Case True
                                Case Regex.IsMatch(rMatch.Value, "(fig)", RegexOptions.IgnoreCase) : TempStr = "Fig_AS" & Cnt
                                Case Regex.IsMatch(rMatch.Value, "(tab)", RegexOptions.IgnoreCase) : TempStr = "Tab_AS" & Cnt
                                Case True : TempStr = "Float_AS" & Cnt
                            End Select
                            oWordDoc.Bookmarks.Add(TempStr, FRng.Paragraphs.Item(1).Range)
                    End Select
NxtMatch:
                    FRng.Collapse(WdCollapseDirection.wdCollapseEnd)
                End If
NxtI:
            Next
        Next
        oWordDoc.Application.Selection.HomeKey(Unit:=WdUnits.wdStory)
        Call ToLoadSchema(oWordDoc, False)
        If HeadRng Is Nothing Then
            TempRng = Nothing : TempRng = ToGetBodyStartRng(oWordDoc)
            If Not TempRng Is Nothing Then
                HeadRng = oWordDoc.Range(TotalRng.Start, TempRng.Start - 1)
                BodyRng = oWordDoc.Range(TempRng.Start, oWordDoc.Range.End)
            End If
        End If
        Dim PCnt As Integer

        '########### To Set All Range start and end ###########
        If Not (HeadRng Is Nothing) Then
            PCnt = HeadRng.Paragraphs.Count
            HeadRng.SetRange(HeadRng.Paragraphs.Item(1).Range.Start, HeadRng.Paragraphs.Item(PCnt).Range.End)

            ''Dim oWordDocXMLNodes As Microsoft.Office.Interop.Word.XMLNodes = oWordDoc.SelectNodes("//")

            '' Dim xmlData As String = GetXmlFromResource(oWordDoc)
            ''oWordDoc.CustomXMLParts.Add("front", URI)
            Dim obj1 As New AddCustomXMLPartandBindControls()
            obj1.BindControlsToCustomXmlPart(oWordDoc)

            ''  oWordDoc.XMLNodes.Add("front", URI, HeadRng)
            '' oWordDoc.XMLNodes.Add("j:front", URI, HeadRng)
            '' oWordDoc.XMLNodes.Add("front", URI, HeadRng)
        End If

        If Not (BodyRng Is Nothing) Then
            PCnt = BodyRng.Paragraphs.Count
            BodyRng.SetRange(BodyRng.Paragraphs.Item(1).Range.Start, BodyRng.Paragraphs.Item(PCnt).Range.End)
            '######## Validate Para caps info to add/not #######
            If StringWithRegMatches(BodyRng.Text, "[A-Z][A-Z0-9\W]+", False, True) > 2 Then bAddCapsInfo = True Else bAddCapsInfo = False
            oWordDoc.XMLNodes.Add("body", URI, BodyRng)
        End If

        If Not (BackRng Is Nothing) Then
            PCnt = BackRng.Paragraphs.Count
            BackRng.SetRange(BackRng.Paragraphs.Item(1).Range.Start, BackRng.Paragraphs.Item(PCnt).Range.End)
            oWordDoc.XMLNodes.Add("back", URI, BackRng)
        End If

        If Not (FloatRng Is Nothing) Then
            PCnt = FloatRng.Paragraphs.Count
            FloatRng.SetRange(FloatRng.Paragraphs.Item(1).Range.Start, FloatRng.Paragraphs.Item(PCnt).Range.End)
            oWordDoc.XMLNodes.Add("floats-wrap", URI, FloatRng)
        End If
        oWordDoc.XMLNodes.Add("article", URI, oWordDoc.Range)

        Dim Xnode As XMLNode
        TempRng = Nothing
        For Each Xnode In oWordDoc.XMLNodes
            If Xnode.BaseName <> "article" Then
                If Xnode.Range.Characters.First.Text <> Chr(13) Then Xnode.Range.InsertBefore(Chr(13))
                TempRng = Xnode.Range.Duplicate : TempRng.Move(WdUnits.wdCharacter, 1)
                If TempRng.Paragraphs.First.Range.XMLNodes.Count > 0 OrElse TempRng.Paragraphs.First.Range.Text <> Chr(13) Then TempRng.InsertBefore(Chr(13))
                'If Xnode.Range.Characters.Last.Text <> Chr(13) Then Xnode.Range.XMLParentNode.Range.Next(WdUnits.wdParagraph).InsertBefore(ChrW(13))
                'If Xnode.BaseName = "front" Then oWordDoc.XMLNodes.Add("article-meta", URI, Xnode.Range)
                Xnode.Attributes.Add("confidence", "").NodeValue = "90"
            End If
        Next
        ToIdentifyDocumentPart = True
    End Function
    Private Function GetXmlFromResource(ByVal oWordDoc As Document) As String
        oWordDoc.XMLSchemaReferences.AllowSaveAsXMLWithoutValidation = True
        Dim asm As System.Reflection.Assembly = System.Reflection.Assembly.GetExecutingAssembly
        Dim stream1 As System.IO.Stream = asm.GetManifestResourceStream("EmployeeControls.employees.xml")
        Dim resourceReader As System.IO.StreamReader = New System.IO.StreamReader(stream1)
        If (Not (resourceReader) Is Nothing) Then
            Return resourceReader.ReadToEnd
        End If

        Return Nothing
    End Function

    Private Function ToGetBodyStartRng(ByVal oWordDoc As Document) As Range
        Dim TtlRng As Range = oWordDoc.Range
        Dim FRng As Range
        Dim AbsSecStr As String = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "AbstractSecPattern", "", True)
        Dim HeadInfoStartLineStr As String = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "HeadInfoStartLinePattern", "", True, True)
        Dim HeadInfoContainsStr As String = AuoStructureReadINI(sJournalConfigPath, sSecAutoStyleKeys, "HeadInfoContainsPattern", "", True, True)
        Dim AbstractStr As String = "(abstract|graphical(\s*)abstract|summary)"
        Dim KeywordStr As String = "(key[\- ]*word(s)?|pacs[\- ]*(number(s)?)?|nomenclature(s)?|list\s*of\s*main\s*abbreviations|abbreviation(s)?)"


        Dim HeadEnd As Integer = 0
        Dim rMatches As MatchCollection = Nothing
        Dim rMatch As Match
        ToGetBodyStartRng = TtlRng.Paragraphs.Item(1).Range
        Dim I As Integer, PCnt As Integer
        TtlRng = oWordDoc.Range
        TempRng = TtlRng.Duplicate
        Try
            FRng = TtlRng.Duplicate
            FRng.Find.ClearFormatting() : FRng.Find.Replacement.ClearFormatting()
            Dim RegOptions As RegexOptions = RegexOptions.IgnoreCase
            For I = 1 To 2
                Select Case I
                    Case 1 : rMatches = Regex.Matches(TtlRng.Text, "((\n|\r|^)([0-9ivx\.\:\s]*)" & KeywordStr & "([\.\:\s]*))", RegexOptions.IgnoreCase)
                    Case 2 : rMatches = Regex.Matches(TtlRng.Text, "((\n|\r|^)([0-9ivx\.\:\s]*)" & AbstractStr & "([\.\:\s]*))", RegexOptions.IgnoreCase)
                End Select
                For Each rMatch In rMatches
                    If String.IsNullOrEmpty(rMatch.Value) = False Then
                        FRng.Find.Text = rMatch.Value
                        Do While FRng.Find.Execute = True
                            TempRng.SetRange(TempRng.Start, FRng.End) '########## To Validate the maximum para count in the head matter #######
                            If TempRng.Paragraphs.Count < 30 Then
                                Select Case True
                                    Case HeadEnd = 0 : ToGetBodyStartRng = FRng.Duplicate : HeadEnd = ToGetBodyStartRng.Start
                                    Case ToGetBodyStartRng.Start <= FRng.Start : ToGetBodyStartRng = FRng.Duplicate
                                End Select
                            End If
                            FRng.Collapse(WdCollapseDirection.wdCollapseEnd)
                        Loop
                    End If
                Next rMatch
            Next


            If StringWithRegMatches(ToGetBodyStartRng.Text, AbsSecStr, True, True, False) > 0 Then
                ToGetBodyStartRng.SetRange(ToGetBodyStartRng.End + 1, ToGetBodyStartRng.End + 1)
                ToGetBodyStartRng.SetRange(ToGetBodyStartRng.Start, TtlRng.End)
                TtlRng.SetRange(ToGetBodyStartRng.Start, TtlRng.End)    ' ### To Confirm that abstract present here 
                I = 0 : PCnt = ToGetBodyStartRng.Paragraphs.Count
                For I = 1 To PCnt
                    If I > 10 Then GoTo NxtP3
                    PRng = ToGetBodyStartRng.Paragraphs.Item(I).Range.Duplicate
                    PRng.SetRange(PRng.Start, PRng.End - 1) : TempStr = PRng.Text
                    If StringWithRegMatches(TempStr, AbsSecStr, True, True, False) > 0 Then
                        'If ToRemoveAllSpecialChar(TempStr) = "" Or I < 2 Then GoTo NxtP1
                        PRng = ToGetBodyStartRng.Paragraphs.Item(I + 1).Range.Duplicate
                        ToGetBodyStartRng.SetRange(PRng.End, TtlRng.End)
                        If StringWithRegMatches(ToGetBodyStartRng.Text, AbsSecStr, True, True, False) > 0 Then GoTo NxtP3
                        Exit Function
                    End If
NxtP1:
                Next

            ElseIf StringWithRegMatches(ToGetBodyStartRng.Text, KeywordStr, True, True, False) > 0 Then
                ToGetBodyStartRng.SetRange(ToGetBodyStartRng.End + 1, ToGetBodyStartRng.End + 1)
                ToGetBodyStartRng.SetRange(ToGetBodyStartRng.Start, TtlRng.End)
                TtlRng.SetRange(ToGetBodyStartRng.Start, TtlRng.End)    ' ### To Confirm that keywords present here 
                I = 0 : PCnt = ToGetBodyStartRng.Paragraphs.Count
                For I = 1 To PCnt
                    If I > 10 Then GoTo NxtP3
                    PRng = ToGetBodyStartRng.Paragraphs.Item(I).Range.Duplicate
                    PRng.SetRange(PRng.Start, PRng.End - 1) : TempStr = PRng.Text
                    If ToRemoveAllSpecialChar(TempStr) = "" Or I < 2 Then GoTo NxtP2
                    If (PRng.Bold <> 0 Or PRng.ComputeStatistics(WdStatistic.wdStatisticLines) > 2) Then
                        ToGetBodyStartRng.SetRange(PRng.Start, TtlRng.End)
                        Exit Function
                    End If
NxtP2:
                Next
            Else
NxtP3:
                I = 0 : PCnt = TtlRng.Paragraphs.Count
                If PCnt > 25 Or _
                    StringWithRegMatches(TtlRng.Text, AbstractStr, True, True, False) > 0 Or _
                    StringWithRegMatches(ToGetBodyStartRng.Text, KeywordStr, True, True, False) > 0 Then
                    For I = 1 To PCnt
                        PRng = TtlRng.Paragraphs.Item(I).Range.Duplicate
                        PRng.SetRange(PRng.Start, PRng.End - 1)
                        If PRng Is Nothing Then GoTo NxtP4
                        TempStr = PRng.Text
                        If I < 3 Or ToRemoveAllSpecialChar(TempStr) = "" Then GoTo NxtP4
                        If StringWithRegMatches(TempStr, HeadInfoStartLineStr, True, True, False) > 0 Then GoTo NxtP4
                        If StringWithRegMatches(TempStr, HeadInfoContainsStr, True, False, False) > 0 Then GoTo NxtP4
                        If (PRng.ComputeStatistics(WdStatistic.wdStatisticLines) > 5 Or PRng.Font.Bold = True) Then
                            '####### If two seq. paragraph as bold it will collect previous para also #####
                            TempRng = TtlRng.Paragraphs.Item(I - 1).Range.Duplicate
                            TempRng.SetRange(TempRng.Start, TempRng.End - 1)
                            If StringWithRegMatches(TempRng.Text, AbstractStr, True, True, False) > 0 Then GoTo NxtP4
                            If TempRng.Bold = True Then PRng = TempRng
                            '####### If two seq. paragraph as bold it will collect previous para also #####
                            ToGetBodyStartRng = PRng
                            ToGetBodyStartRng.SetRange(ToGetBodyStartRng.Start, TtlRng.End)
                            Exit Function
                        End If
NxtP4:
                    Next
                Else
                    For I = 1 To PCnt
                        PRng = TtlRng.Paragraphs.Item(I).Range.Duplicate
                        If PRng.ComputeStatistics(WdStatistic.wdStatisticLines) > 3 Then
                            ToGetBodyStartRng = PRng
                            ToGetBodyStartRng.SetRange(ToGetBodyStartRng.Start, TtlRng.End)
                            Exit Function
                        End If
                    Next
                End If
            End If
        Catch ex As Exception
            Throw ex
            'sAutoProcessErrorInfo = ex.Message
        End Try
    End Function

    Private Function ToApplyPubStyle(ByVal PubName As String, ByVal ConfigPath As String, ByVal oWordDoc As Document, Optional ByVal bWebInputNeed As Boolean = False) As Boolean
        Dim I As Integer
        Dim RNode As XMLNode = Nothing, CNode As XMLNode = Nothing, NCNode As XMLNode
        WordApp = oWordDoc.Application
        Dim StyleName As String = String.Empty : Dim TagName As String = String.Empty
        Dim INISectionInfo As String = sSecStylesInfo
        Dim QueryID As Integer = 0
        Dim iConfidenceVal As Integer = 0
        Dim sBKName As String = ""
        If WordApp.ActiveWindow.View.SplitSpecial = WdSpecialPane.wdPaneNone Then
            WordApp.ActiveWindow.ActivePane.View.Type = WdViewType.wdNormalView
        Else
            WordApp.ActiveWindow.View.Type = WdViewType.wdNormalView
        End If
        WordApp.ActiveWindow.ActivePane.View.Zoom.Percentage = 100
        If WordApp.ActiveWindow.StyleAreaWidth = 0 Then WordApp.ActiveWindow.StyleAreaWidth = WordApp.InchesToPoints(1)
        '########### Tag Name Strings #############
        Dim Abbrev_name As String = "abbrev" : Dim Abbrev_journal_title_name As String = "abbrev-journal-title" : Dim Abstract_name As String = "abstract" : Dim Access_date_name As String = "access-date" : Dim Ack_name As String = "ack" : Dim Address_name As String = "address" : Dim Addr_line_name As String = "addr-line" : Dim Aff_name As String = "aff" : Dim Alt_text_name As String = "alt-text" : Dim Alt_title_name As String = "alt-title" : Dim Annotation_name As String = "annotation" : Dim Anonymous_name As String = "anonymous" : Dim App_name As String = "app" : Dim App_group_name As String = "app-group" : Dim Array_name As String = "array" : Dim Article_name As String = "article" : Dim Article_categories_name As String = "article-categories" : Dim Article_id_name As String = "article-id" : Dim Article_meta_name As String = "article-meta" : Dim Article_title_name As String = "article-title" : Dim Article_type_name As String = "article-type" : Dim Attrib_name As String = "attrib" : Dim Author_comment_name As String = "author-comment" : Dim Author_info_name As String = "author-info" : Dim Author_notes_name As String = "author-notes" : Dim Back_name As String = "back" : Dim Bio_name As String = "bio" : Dim Body_name As String = "body" : Dim Bold_name As String = "bold" : Dim Boxed_text_name As String = "boxed-text" : Dim Break_name As String = "break" : Dim Caption_name As String = "caption" : Dim Chem_struct_name As String = "chem-struct" : Dim Chem_struct_wrapper_name As String = "chem-struct-wrapper" : Dim Citation_name As String = "citation" : Dim Col_name As String = "col" : Dim Colgroup_name As String = "colgroup" : Dim Collab_name As String = "collab" : Dim Comment_name As String = "comment" : Dim Conf_acronym_name As String = "conf-acronym" : Dim Conf_date_name As String = "conf-date" : Dim Conference_name As String = "conference" : Dim Conf_loc_name As String = "conf-loc" : Dim Conf_name_name As String = "conf-name" : Dim Conf_num_name As String = "conf-num" : Dim Conf_sponsor_name As String = "conf-sponsor" : Dim Conf_theme_name As String = "conf-theme" : Dim Contract_num_name As String = "contract-num" : Dim Contract_sponsor_name As String = "contract-sponsor" : Dim Contrib_name As String = "contrib"
        Dim Contrib_group_name As String = "contrib-group" : Dim Copyright_holder_name As String = "copyright-holder" : Dim Copyright_statement_name As String = "copyright-statement" : Dim Copyright_year_name As String = "copyright-year" : Dim Corresp_name As String = "corresp" : Dim Country_name As String = "country" : Dim Counts_name As String = "counts" : Dim Custom_meta_name As String = "custom-meta" : Dim Custom_meta_wrap_name As String = "custom-meta-wrap" : Dim Date_name As String = "date" : Dim Day_name As String = "day" : Dim Dedicate_name As String = "dedicate" : Dim Def_name As String = "def" : Dim Def_head_name As String = "def-head" : Dim Def_item_name As String = "def-item" : Dim Def_list_name As String = "def-list" : Dim Degrees_name As String = "degrees" : Dim Disp_formula_name As String = "disp-formula" : Dim Disp_quote_name As String = "disp-quote" : Dim Edition_name As String = "edition" : Dim Elocation_id_name As String = "elocation-id" : Dim Email_name As String = "email" : Dim Equation_count_name As String = "equation-count" : Dim Etal_name As String = "etal" : Dim Ext_link_name As String = "ext-link" : Dim Fax_name As String = "fax" : Dim Fig_name As String = "fig" : Dim Fig_count_name As String = "fig-count" : Dim Fig_group_name As String = "fig-group" : Dim Fig_note_name As String = "fig-note" : Dim Floats_wrap_name As String = "floats-wrap" : Dim Fn_name As String = "fn" : Dim Fn_group_name As String = "fn-group" : Dim Font_name As String = "font" : Dim Fpage_name As String = "fpage" : Dim Front_name As String = "front" : Dim Front_stub_name As String = "front-stub" : Dim Given_names_name As String = "given-names" : Dim Glossary_name As String = "glossary" : Dim Gloss_group_name As String = "gloss-group" : Dim Glyph_data_name As String = "glyph-data" : Dim Glyph_ref_name As String = "glyph-ref" : Dim Gov_name As String = "gov" : Dim Grant_num_name As String = "grant-num" : Dim Grant_sponsor_name As String = "grant-sponsor" : Dim Graphic_name As String = "graphic" : Dim History_name As String = "history" : Dim Hr_name As String = "hr" : Dim Inline_formula_name As String = "inline-formula" : Dim Inline_graphic_name As String = "inline-graphic"
        Dim Inline_supplementary_material_name As String = "inline-supplementary-material" : Dim Institution_name As String = "institution" : Dim Isbn_name As String = "isbn" : Dim Issn_name As String = "issn" : Dim Issue_name As String = "issue" : Dim Issue_id_name As String = "issue-id" : Dim Issue_title_name As String = "issue-title" : Dim Italic_name As String = "italic" : Dim Journal_id_name As String = "journal-id" : Dim Journal_meta_name As String = "journal-meta" : Dim Journal_subtitle_name As String = "journal-subtitle" : Dim Journal_title_name As String = "journal-title" : Dim Kwd_name As String = "kwd" : Dim Kwd_group_name As String = "kwd-group" : Dim Label_name As String = "label" : Dim License_name As String = "license" : Dim List_name As String = "list" : Dim List_item_name As String = "list-item" : Dim Long_desc_name As String = "long-desc" : Dim Lpage_name As String = "lpage" : Dim Media_name As String = "media" : Dim Meta_name_name As String = "meta-name" : Dim Meta_value_name As String = "meta-value" : Dim Milestone_end_name As String = "milestone-end" : Dim Milestone_start_name As String = "milestone-start" : Dim Monospace_name As String = "monospace" : Dim Month_name As String = "month" : Dim Name_name As String = "name" : Dim Named_content_name As String = "named-content" : Dim Nlm_citation_name As String = "nlm-citation" : Dim Note_name As String = "note" : Dim Notes_name As String = "notes" : Dim Object_id_name As String = "object-id" : Dim On_behalf_of_name As String = "on-behalf-of" : Dim Overline_name As String = "overline" : Dim Overline_end_name As String = "overline-end" : Dim Overline_start_name As String = "overline-start" : Dim P_name As String = "p" : Dim Page_count_name As String = "page-count" : Dim Page_range_name As String = "page-range" : Dim Patent_name As String = "patent" : Dim Permissions_name As String = "permissions" : Dim Person_group_name As String = "person-group" : Dim Phone_name As String = "phone" : Dim Prefix_name As String = "prefix" : Dim Preformat_name As String = "preformat" : Dim Price_name As String = "price" : Dim Private_char_name As String = "private-char" : Dim Product_name As String = "product" : Dim Pub_date_name As String = "pub-date"
        Dim Pub_id_name As String = "pub-id" : Dim Publisher_name As String = "publisher" : Dim Publisher_loc_name As String = "publisher-loc" : Dim Publisher_name_name As String = "publisher-name" : Dim Ref_name As String = "ref" : Dim Ref_count_name As String = "ref-count" : Dim Ref_list_name As String = "ref-list" : Dim Related_article_name As String = "related-article" : Dim Response_name As String = "response" : Dim Role_name As String = "role" : Dim Run_head_name As String = "run-head" : Dim Sans_serif_name As String = "sans-serif" : Dim Sc_name As String = "sc" : Dim Season_name As String = "season" : Dim Sec_name As String = "sec" : Dim Sec_meta_name As String = "sec-meta" : Dim Self_uri_name As String = "self-uri" : Dim Series_name As String = "series" : Dim Series_text_name As String = "series-text" : Dim Series_title_name As String = "series-title" : Dim Sig_name As String = "sig" : Dim Sig_block_name As String = "sig-block" : Dim Size_name As String = "size" : Dim Source_name As String = "source" : Dim Speaker_name As String = "speaker" : Dim Speech_name As String = "speech" : Dim Statement_name As String = "statement" : Dim Std_name As String = "std" : Dim Strike_name As String = "strike" : Dim String_date_name As String = "string-date" : Dim String_name_name As String = "string-name" : Dim Sub_name As String = "sub" : Dim Sub_article_name As String = "sub-article" : Dim Subject_name As String = "subject" : Dim Subj_group_name As String = "subj-group" : Dim Subtitle_name As String = "subtitle" : Dim Suffix_name As String = "suffix" : Dim Sup_name As String = "sup" : Dim Supplement_name As String = "supplement" : Dim Supplementary_material_name As String = "supplementary-material" : Dim Surname_name As String = "surname" : Dim Table_name As String = "table" : Dim Table_count_name As String = "table-count" : Dim Table_wrap_name As String = "table-wrap" : Dim Table_wrap_foot_name As String = "table-wrap-foot" : Dim Table_wrap_group_name As String = "table-wrap-group" : Dim Tab_note_name As String = "tab-note" : Dim Target_name As String = "target" : Dim Tbody_name As String = "tbody" : Dim Td_name As String = "td"
        Dim Term_name As String = "term" : Dim Term_head_name As String = "term-head" : Dim Tex_math_name As String = "tex-math" : Dim Tfoot_name As String = "tfoot" : Dim Th_name As String = "th" : Dim Thead_name As String = "thead" : Dim Time_stamp_name As String = "time-stamp" : Dim Title_name As String = "title" : Dim Title_group_name As String = "title-group" : Dim Tr_name As String = "tr" : Dim Trans_abstract_name As String = "trans-abstract" : Dim Trans_source_name As String = "trans-source" : Dim Trans_subtitle_name As String = "trans-subtitle" : Dim Trans_title_name As String = "trans-title" : Dim Underline_name As String = "underline" : Dim Underline_end_name As String = "underline-end" : Dim Underline_start_name As String = "underline-start" : Dim Uri_name As String = "uri" : Dim Verse_group_name As String = "verse-group" : Dim Verse_line_name As String = "verse-line" : Dim Volume_name As String = "volume" : Dim Volume_id_name As String = "volume-id" : Dim Word_count_name As String = "word-count" : Dim X_name As String = "x" : Dim Xlink_name As String = "xlink" : Dim Xref_name As String = "xref" : Dim Year_name As String = "year"
        '########### Tag Name Strings #############

        Dim sFundingPattern As String = AuoStructureReadINI(ConfigPath, sSecAutoStyleKeys, "FundingPattern", "", True, False, False)
        Dim sCompetInterestsPattern As String = AuoStructureReadINI(ConfigPath, sSecAutoStyleKeys, "CompetInterestsPattern", "", True, False, False)
        Dim sEthicsApprovalPattern As String = AuoStructureReadINI(ConfigPath, sSecAutoStyleKeys, "EthicsApprovalPattern", "", True, False, False)
        Dim sProvAndPeerPattern As String = AuoStructureReadINI(ConfigPath, sSecAutoStyleKeys, "ProvAndPeerPattern", "", True, False, False)
        Dim sFNMoreInfoPattern As String = AuoStructureReadINI(ConfigPath, sSecAutoStyleKeys, "FNMoreInfoPattern", "", True, False, False)
        Dim sContributorsPattern As String = AuoStructureReadINI(ConfigPath, sSecAutoStyleKeys, "ContributorsPattern", "", True, False, False)

        Try
            Dim RunonWithCommaIndex As Integer
            Dim DelIndex As Integer
            Dim RunonWithSpaceIndex As Integer
            Dim strPrefix As String = "xmlns:x=""AS"""
            For I = 1 To 4
                Select Case I
                    Case 1 : RNode = oWordDoc.SelectSingleNode("//x:front", strPrefix)
                    Case 2 : RNode = oWordDoc.SelectSingleNode("//x:body", strPrefix)
                    Case 3 : RNode = oWordDoc.SelectSingleNode("//x:back", strPrefix)
                    Case 4 : RNode = oWordDoc.SelectSingleNode("//x:floats-wrap", strPrefix)
                End Select
                If RNode Is Nothing Then GoTo NxtRTNode
                For Each CNode In RNode.ChildNodes
                    TagName = ToGetAttributeVal(CNode, "tagtype")
                    Select Case True
                        Case Regex.IsMatch(TagName, "userinput", RegexOptions.IgnoreCase)
                            '###Dim rMatch As Match = Regex.Match(TagName, "(.*)(_)(.*)", RegexOptions.IgnoreCase)
                            Dim rMatch As Match = Regex.Match(TagName, "(userinput)(_)(.*)", RegexOptions.IgnoreCase)
                            StyleName = rMatch.Groups(3).Value
                            Select Case True
                                Case StyleName.Contains("del")
                                    DelIndex += 1 : CNode.Range.Bookmarks.Add("CEGAS_del_" & DelIndex, CNode.Range)
                                    GoTo NxtNode
                                Case StyleName.Contains("runonwithcomma")
                                    RunonWithCommaIndex += 1 : CNode.Range.Bookmarks.Add("CEGAS_runonwithcomma_" & RunonWithCommaIndex, CNode.Range)
                                    GoTo NxtNode
                                Case StyleName.Contains("runonwith")
                                    RunonWithSpaceIndex += 1 : CNode.Range.Bookmarks.Add("CEGAS_runonwithspace_" & RunonWithSpaceIndex, CNode.Range)
                                    GoTo NxtNode
                                Case StyleName.Contains("skip")
                                    CNode.Range.HighlightColorIndex = WdColorIndex.wdYellow
                                    GoTo NxtNode
                                Case String.IsNullOrWhiteSpace(StyleName) = False
                                    GoTo StyleNode
                            End Select

                        Case Regex.IsMatch(TagName, "(_)")
                            Dim rMatch As Match = Regex.Match(TagName, "(.*)(_)(.*)", RegexOptions.IgnoreCase)
                            TagName = rMatch.Groups(3).Value
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, TagName, "", False, False, False)
                            If StyleName <> "" Then GoTo StyleNode
                        Case Else
                            TagName = CNode.BaseName
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, TagName, "", False, False, False)
                            If StyleName <> "" Then GoTo StyleNode
                    End Select

                    Select Case True
                        Case Regex.IsMatch(TagName, Abbrev_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Abbrev_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Abbrev_journal_title_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Abbrev_journal_title_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Abstract_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Abstract_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Access_date_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Access_date_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Ack_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Ack_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Address_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Address_name, "", False, False, False)


                        Case Regex.IsMatch(TagName, Addr_line_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Addr_line_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Aff_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Aff_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Alt_text_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Alt_text_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Alt_title_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Alt_title_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Annotation_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Annotation_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Anonymous_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Anonymous_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, App_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, App_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, App_group_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, App_group_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Array_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Array_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Article_categories_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Article_categories_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Article_id_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Article_id_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Article_meta_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Article_meta_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Article_title_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Article_title_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Article_type_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Article_type_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Attrib_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Attrib_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Author_comment_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Author_comment_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Author_info_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Author_info_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Author_notes_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Author_notes_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Back_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Back_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Bio_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Bio_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Body_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Body_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Bold_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Bold_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Boxed_text_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Boxed_text_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Break_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Break_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Caption_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Caption_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Chem_struct_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Chem_struct_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Chem_struct_wrapper_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Chem_struct_wrapper_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Citation_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Citation_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Colgroup_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Colgroup_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Collab_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Collab_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Comment_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Comment_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Conf_acronym_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Conf_acronym_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Conf_date_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Conf_date_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Conference_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Conference_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Conf_loc_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Conf_loc_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Conf_name_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Conf_name_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Conf_num_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Conf_num_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Conf_sponsor_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Conf_sponsor_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Conf_theme_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Conf_theme_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Contract_num_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Contract_num_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Contract_sponsor_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Contract_sponsor_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Contrib_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Contrib_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Contrib_group_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Contrib_group_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Copyright_holder_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Copyright_holder_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Copyright_statement_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Copyright_statement_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Copyright_year_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Copyright_year_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Corresp_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Corresp_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Country_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Country_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Counts_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Counts_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Custom_meta_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Custom_meta_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Custom_meta_wrap_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Custom_meta_wrap_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Date_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Date_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Day_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Day_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Dedicate_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Dedicate_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Def_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Def_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Def_head_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Def_head_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Def_item_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Def_item_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Def_list_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Def_list_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Degrees_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Degrees_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Disp_formula_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Disp_formula_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Disp_quote_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Disp_quote_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Edition_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Edition_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Elocation_id_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Elocation_id_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Email_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Email_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Equation_count_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Equation_count_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Etal_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Etal_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Ext_link_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Ext_link_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Fax_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Fax_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Fig_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Fig_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Fig_count_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Fig_count_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Fig_group_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Fig_group_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Fig_note_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Fig_note_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Floats_wrap_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Floats_wrap_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Fn_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Fn_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Fn_group_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Fn_group_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Font_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Font_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Fpage_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Fpage_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Front_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Front_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Front_stub_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Front_stub_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Given_names_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Given_names_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Glossary_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Glossary_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Gloss_group_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Gloss_group_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Glyph_data_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Glyph_data_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Glyph_ref_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Glyph_ref_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Gov_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Gov_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Grant_num_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Grant_num_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Grant_sponsor_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Grant_sponsor_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Graphic_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Graphic_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, History_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, History_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Inline_formula_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Inline_formula_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Inline_graphic_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Inline_graphic_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Inline_supplementary_material_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Inline_supplementary_material_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Institution_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Institution_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Isbn_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Isbn_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Issn_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Issn_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Issue_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Issue_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Issue_id_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Issue_id_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Issue_title_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Issue_title_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Italic_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Italic_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Journal_id_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Journal_id_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Journal_meta_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Journal_meta_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Journal_subtitle_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Journal_subtitle_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Journal_title_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Journal_title_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Kwd_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Kwd_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Kwd_group_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Kwd_group_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Label_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Label_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, License_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, License_name, "", False, False, False)


                        Case Regex.IsMatch(TagName, List_item_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, List_item_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Long_desc_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Long_desc_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Lpage_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Lpage_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Media_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Media_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Meta_name_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Meta_name_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Meta_value_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Meta_value_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Milestone_end_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Milestone_end_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Milestone_start_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Milestone_start_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Monospace_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Monospace_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Month_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Month_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Name_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Name_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Named_content_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Named_content_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Nlm_citation_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Nlm_citation_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Note_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Note_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Notes_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Notes_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Object_id_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Object_id_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, On_behalf_of_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, On_behalf_of_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Overline_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Overline_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Overline_end_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Overline_end_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Overline_start_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Overline_start_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Page_count_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Page_count_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Page_range_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Page_range_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Patent_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Patent_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Permissions_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Permissions_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Person_group_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Person_group_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Phone_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Phone_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Prefix_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Prefix_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Preformat_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Preformat_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Price_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Price_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Private_char_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Private_char_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Product_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Product_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Pub_date_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Pub_date_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Pub_id_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Pub_id_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Publisher_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Publisher_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Publisher_loc_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Publisher_loc_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Publisher_name_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Publisher_name_name, "", False, False, False)


                        Case Regex.IsMatch(TagName, Ref_count_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Ref_count_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Ref_list_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Ref_list_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Ref_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Ref_name, "", False, False, False)


                        Case Regex.IsMatch(TagName, Related_article_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Related_article_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Response_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Response_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Role_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Role_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Run_head_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Run_head_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Sans_serif_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Sans_serif_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Season_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Season_name, "", False, False, False)


                        Case Regex.IsMatch(TagName, Sec_meta_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Sec_meta_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Self_uri_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Self_uri_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Series_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Series_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Series_text_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Series_text_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Series_title_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Series_title_name, "", False, False, False)


                        Case Regex.IsMatch(TagName, Sig_block_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Sig_block_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Size_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Size_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Source_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Source_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Speaker_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Speaker_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Speech_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Speech_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Statement_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Statement_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Std_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Std_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Strike_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Strike_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, String_date_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, String_date_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, String_name_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, String_name_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Sub_article_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Sub_article_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Subject_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Subject_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Subj_group_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Subj_group_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Subtitle_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Subtitle_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Suffix_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Suffix_name, "", False, False, False)


                        Case Regex.IsMatch(TagName, Supplement_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Supplement_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Supplementary_material_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Supplementary_material_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Surname_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Surname_name, "", False, False, False)


                        Case Regex.IsMatch(TagName, Table_count_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Table_count_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Table_wrap_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Table_wrap_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Table_wrap_foot_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Table_wrap_foot_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Table_wrap_group_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Table_wrap_group_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Tab_note_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Tab_note_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Target_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Target_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Tbody_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Tbody_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Table_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Table_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Term_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Term_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Term_head_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Term_head_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Tex_math_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Tex_math_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Tfoot_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Tfoot_name, "", False, False, False)


                        Case Regex.IsMatch(TagName, Thead_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Thead_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Time_stamp_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Time_stamp_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Title_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Title_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Title_group_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Title_group_name, "", False, False, False)


                        Case Regex.IsMatch(TagName, Trans_abstract_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Trans_abstract_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Trans_source_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Trans_source_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Trans_subtitle_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Trans_subtitle_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Trans_title_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Trans_title_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Underline_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Underline_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Underline_end_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Underline_end_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Underline_start_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Underline_start_name, "", False, False, False)


                        Case Regex.IsMatch(TagName, Verse_group_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Verse_group_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Verse_line_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Verse_line_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Volume_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Volume_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Volume_id_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Volume_id_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Word_count_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Word_count_name, "", False, False, False)


                        Case Regex.IsMatch(TagName, Xlink_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Xlink_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Xref_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Xref_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, X_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, X_name, "", False, False, False)

                        Case Regex.IsMatch(TagName, Year_name, RegexOptions.IgnoreCase)
                            StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, Year_name, "", False, False, False)
                        Case Else

                    End Select
StyleNode:
                    If String.IsNullOrEmpty(StyleName) = False Then
                        oWordDoc.ActiveWindow.ScrollIntoView(CNode.Range, True)
                        Call modApplyStyles.ToApplyStyle(WordApp, oWordDoc, CNode.Range, StyleName)
                    ElseIf CNode.BaseName = "x" Then
                        Dim TagText As String
                        TagName = ToGetAttributeVal(CNode, "tagtype")
                        TagText = CNode.Range.Text
                        'StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, "BoxStart1", "", False, False, False)

                        Select Case True
                            Case Regex.IsMatch(TagName, "boxstart", RegexOptions.IgnoreCase)
                                StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, "BoxStart1", "", False, False, False)
                                Call modApplyStyles.ToApplyStyle(WordApp, oWordDoc, CNode.Range, StyleName)

                            Case Regex.IsMatch(TagName, "(_del)", RegexOptions.IgnoreCase)
                                CNode.Range.HighlightColorIndex = WdColorIndex.wdRed

                            Case Regex.IsMatch(TagText, "\b" & sCompetInterestsPattern, RegexOptions.IgnoreCase)
                                StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, "CompetInterestsMeta", String.Empty, False, False, False)

                            Case Regex.IsMatch(TagText, "\b" & sEthicsApprovalPattern, RegexOptions.IgnoreCase)
                                StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, "EthicsApprovalMeta", String.Empty, False, False, False)

                            Case Regex.IsMatch(TagText, "\b" & sProvAndPeerPattern, RegexOptions.IgnoreCase)
                                StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, "ProvAndPeerMeta", String.Empty, False, False, False)

                            Case Regex.IsMatch(TagText, "\b" & sContributorsPattern, RegexOptions.IgnoreCase)
                                StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, "ContributorsMeta", String.Empty, False, False, False)

                            Case Regex.IsMatch(TagText, "\b" & sFundingPattern, RegexOptions.IgnoreCase)
                                StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, "FundingMeta", String.Empty, False, False, False)

                            Case Regex.IsMatch(TagText, "\b" & sFNMoreInfoPattern, RegexOptions.IgnoreCase)
                                StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, "FNMoreInfoMeta", String.Empty, False, False, False)

                            Case Else
                                GoTo Raise2Query
                        End Select
                        If String.IsNullOrEmpty(StyleName) = False Then Call modApplyStyles.ToApplyStyle(WordApp, oWordDoc, CNode.Range, StyleName) Else GoTo Raise2Query
                    Else
                        GoTo Raise2Query
                    End If
                    '############# Generate XML for Web input #############
                    If bWebInputNeed = True Then
                        iConfidenceVal = CInt(ToGetAttributeVal(CNode, "confidence"))
                        If iConfidenceVal < 51 Then
Raise2Query:
                            Dim sXML As String = String.Empty : Dim sStylename As String = String.Empty
                            Dim sElements As String = String.Empty : Dim sExpandGroup As String = String.Empty
                            QueryID += 1
                            Select Case True
                                Case String.IsNullOrEmpty(StyleName) : sStylename = "x"
                                Case Else : sStylename = StyleName
                            End Select
                            Select Case True
                                Case Regex.IsMatch(CNode.BaseName, "(fn_|misc|x)", RegexOptions.IgnoreCase) : sElements = sFNElements : sExpandGroup = "Frontmatter notes"
                                Case I = 1 : sElements = sHeadElements : sExpandGroup = "Frontmatter"
                                Case I = 2 : sElements = sBodyElements : sExpandGroup = "Body"
                                Case I = 3 : sElements = sBackElements : sExpandGroup = "Floats"
                                Case I = 4 : sElements = sFloatsElements : sExpandGroup = "Endmatter"
                            End Select
                            sBKName = "Query" & QueryID
                            sXML = "<query id=""" & QueryID & """><bookmark-name>" & sBKName & "</bookmark-name>" _
                                    & "<style>" & sStylename & "</style>" _
                                    & "<elements>" & sElements & "</elements>" _
                                    & "<expand-group>" & sExpandGroup & "</expand-group></query>"
                            sWebInputXMLInfo = sWebInputXMLInfo & sXML
                            Call oWordDoc.Bookmarks.Add(sBKName, CNode.Range)
                        End If
                    End If
                    '######################################################
                    '############ Apply Styles for nested level of tags ##############
                    If CNode.ChildNodes.Count > 0 Then
                        For Each NCNode In CNode.ChildNodes
                            If Regex.IsMatch(CNode.BaseName, "(title|label|citation)", RegexOptions.IgnoreCase) = False Then
                                TagName = ToGetAttributeVal(NCNode, "tagtype")
                                Select Case True
                                    Case Regex.IsMatch(TagName, "(_)")
                                        Dim rMatch As Match = Regex.Match(TagName, "(.*)(_)(.*)", RegexOptions.IgnoreCase)
                                        TagName = rMatch.Groups(3).Value
                                        StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, TagName, "", False, False, False)
                                        Select Case True
                                            Case Regex.IsMatch(StyleName, "(refnum)", RegexOptions.IgnoreCase)
                                                NCNode.Range.InsertAfter(vbTab)
                                            Case Else ' Do Nothing
                                        End Select
                                    Case Else
                                        TagName = NCNode.BaseName
                                        StyleName = AuoStructureReadINI(ConfigPath, INISectionInfo, TagName, "", False, False, False)
                                End Select
                                If String.IsNullOrEmpty(StyleName) = False Then
                                    Call modApplyStyles.ToApplyStyle(WordApp, oWordDoc, NCNode.Range, StyleName)
                                End If
                            End If
                        Next
                    End If
NxtNode:
                    ' CNode.Delete()
                Next
NxtRTNode:
            Next
            Call TableStyling(WordApp, oWordDoc, ConfigPath, PubName)
            Call ToRemoveAllNodes(oWordDoc)
            Call ToProcessBookMark(oWordDoc)
            ToApplyPubStyle = True
        Catch ex As Exception
            ApplyPunStyleErrorInfo = ex.Message
        End Try
    End Function

    Private Function ToProcessBookMark(ByVal BKDoc As Document) As Boolean
        On Error Resume Next
        Dim I As Integer
        For I = BKDoc.Bookmarks.Count To 1 Step -1
            Dim sBKName As String = BKDoc.Bookmarks(I).Name
            Dim sMatch As Match = Regex.Match(sBKName, "(CEGAS)(_)(.*?)(_)", RegexOptions.IgnoreCase)
            Dim sProcessName As String = sMatch.Groups(3).Value
            If String.IsNullOrWhiteSpace(sProcessName) = False Then
                Select Case sProcessName.ToLower
                    Case "runonwithcomma"
                        If Not BKDoc.Bookmarks(I).Range.Previous.Paragraphs(1).Range Is Nothing Then
                            Dim oPreviousParaRng As Range = BKDoc.Bookmarks(I).Range.Previous.Paragraphs(1).Range
                            oPreviousParaRng.Select()
                            If oPreviousParaRng.Characters.Last.Text = vbCr Then
                                oPreviousParaRng.Characters.Last.Text = ", "
                            End If
                        End If
                    Case "runonwithspace"
                        If Not BKDoc.Bookmarks(I).Range.Previous.Paragraphs(1).Range Is Nothing Then
                            Dim oPreviousParaRng As Range = BKDoc.Bookmarks(I).Range.Previous.Paragraphs(1).Range
                            oPreviousParaRng.Select()
                            If oPreviousParaRng.Characters.Last.Text = vbCr Then
                                oPreviousParaRng.Characters.Last.Text = " "
                            End If
                        End If
                    Case "del"
                        BKDoc.Bookmarks(I).Range.Paragraphs(1).Range.Text = String.Empty
                End Select
            End If
        Next
    End Function

    Private Function ToTrimParagraphSpace(ByRef PRng As Range) As Boolean
        On Error Resume Next
        Do While PRng.Characters.First.Text = " " Or (PRng.Characters.First.XMLNodes.Count > 0 And Trim(PRng.Characters.First.Text) = String.Empty)

            PRng.Characters.First.Text = String.Empty
        Loop
        Do While PRng.Characters.Last.Text = " " Or (PRng.Characters.Last.XMLNodes.Count > 0 And Trim(PRng.Characters.Last.Text) = String.Empty)
            PRng.Characters.Last.Text = String.Empty
        Loop
    End Function

    Private Function ToRemoveAllSpecialChar(ByVal InputStr As String) As String
        If String.IsNullOrEmpty(InputStr) = False Then
            ToRemoveAllSpecialChar = Regex.Replace(InputStr, "(\n|\r|\t|\s+|\.|\;|\:|\?|\!|\(|\)|\-)", "")
        Else
            ToRemoveAllSpecialChar = ""
        End If
    End Function

    Private Function ToSetConfidenceVal(ByRef Xnode As XMLNode, Optional ByVal AttributeValue As String = "0", Optional ByVal AttributeName As String = "confidence") As Boolean
        Dim I As Integer
        For I = 1 To Xnode.Attributes.Count
            If LCase(Xnode.Attributes(I).BaseName) = LCase(AttributeName) Then
                Xnode.Attributes(I).NodeValue = AttributeValue
                ToSetConfidenceVal = True
                Exit Function
            End If
        Next
        'If AttributeName = "confidence" Then
        '    Call Xnode.Attributes.Add("confidence", URI, Xnode.Range)
        '    For I = 1 To Xnode.Attributes.Count
        '        If LCase(Xnode.Attributes(I).BaseName) = LCase(AttributeName) Then
        '            Xnode.Attributes(I).NodeValue = AttributeValue
        '            ToSetConfidenceVal = True
        '            Exit Function
        '        End If
        '    Next
        'End If
    End Function

    Private Function ToLoadSchema(ByVal AutoWordDoc As Document, Optional ByVal UnLoad As Boolean = False) As Boolean
        If AutoWordDoc Is Nothing Then Exit Function
        Dim AutWordApp As Application = AutoWordDoc.Application
        Try
            If UnLoad = False Then
                Dim NS As XMLNamespace
                If (AutWordApp.Documents.Count = 0) Then AutWordApp.Documents.Add()
                NS = AutWordApp.XMLNamespaces.Add(sAutoStructuresXSDPath, "http://www.w3.org/2013/XSL/json", "Newgen Autostructuring 2013 XSD", False)
                With AutoWordDoc
                    .UpdateStylesOnOpen = False
                    ''   .XMLSchemaReferences.AutomaticValidation = False
                    '' .XMLSchemaReferences.AllowSaveAsXMLWithoutValidation = True
                    'For 2013 Word
                    '  .AttachedTemplate = AutoWordDoc
                    ''.XMLSchemaReferences.AutomaticValidation = False
                    ''     .XMLSchemaReferences.AllowSaveAsXMLWithoutValidation = True
                End With
                ''  AutWordApp.XMLNamespaces.Item("AS").AttachToDocument(AutoWordDoc)
                AutWordApp.XMLNamespaces.Item("http://www.w3.org/2013/XSL/json").AttachToDocument(AutoWordDoc)
                AutWordApp.TaskPanes(WdTaskPanes.wdTaskPaneXMLStructure).Visible = False
                AutWordApp.ActiveWindow.View.ShowXMLMarkup = False
                'If AutWordApp.ActiveWindow.View.ShowXMLMarkup = False Then AutWordApp.ActiveWindow.View.ShowXMLMarkup = True
            Else
                Dim I As Integer
                For I = 1 To AutoWordDoc.XMLSchemaReferences.Count
                    If AutoWordDoc.XMLSchemaReferences(I).NamespaceURI = "AS" Then
                        AutoWordDoc.XMLSchemaReferences("AS").Delete()
                        Exit For
                    End If
                Next
            End If
            ToLoadSchema = True
        Catch ex As Exception
            Throw ex
            'sAutoProcessErrorInfo = ex.Message
        End Try
    End Function

    Private Function ToLoadSchema_Thiyagu(ByVal AutoWordDoc As Document, Optional ByVal UnLoad As Boolean = False) As Boolean
        If AutoWordDoc Is Nothing Then Exit Function
        Dim AutWordApp As Application = AutoWordDoc.Application
        Try
            If UnLoad = False Then
                Dim NS As XMLNamespace
                If (AutWordApp.Documents.Count = 0) Then AutWordApp.Documents.Add()
                NS = AutWordApp.XMLNamespaces.Add(sAutoStructuresXSDPath, "AS", "Newgen Autostructuring XSD", False)
                With AutoWordDoc
                    .UpdateStylesOnOpen = False

                    ''  .XMLSchemaReferences.AutomaticValidation = False
                    '' .XMLSchemaReferences.AllowSaveAsXMLWithoutValidation = True
                End With
                AutWordApp.XMLNamespaces.Item("AS").AttachToDocument(AutoWordDoc)
                AutWordApp.TaskPanes(WdTaskPanes.wdTaskPaneXMLStructure).Visible = False
                AutWordApp.ActiveWindow.View.ShowXMLMarkup = False
                'If AutWordApp.ActiveWindow.View.ShowXMLMarkup = False Then AutWordApp.ActiveWindow.View.ShowXMLMarkup = True
            Else
                Dim I As Integer
                For I = 1 To AutoWordDoc.XMLSchemaReferences.Count
                    If AutoWordDoc.XMLSchemaReferences(I).NamespaceURI = "AS" Then
                        AutoWordDoc.XMLSchemaReferences("AS").Delete()
                        Exit For
                    End If
                Next
            End If
            ToLoadSchema_Thiyagu = True
        Catch ex As Exception
            Throw ex
            'sAutoProcessErrorInfo = ex.Message
        End Try
    End Function

    Private Function SplitRunOnSections(ByVal oWordDoc As Document, ByVal TRng As Range, Optional ByVal SkipSecHeadPattern As String = "(xxx)") As Boolean
        Dim P As Paragraph
        Dim TempParaRng As Range
        Dim WordApp As Application = oWordDoc.Application
        Dim SplitSecTempStr As String = ""
        Dim IntCnt As Integer = 0

        WordApp.ScreenUpdating = False
        For Each P In TRng.Paragraphs
            TempParaRng = P.Range.Duplicate
            If TempParaRng.Text = Chr(13) Then GoTo SkipLoop
            If TempParaRng.Information(WdInformation.wdWithInTable) = True Or TempParaRng.ComputeStatistics(WdStatistic.wdStatisticLines) <= 2 Then GoTo SkipLoop
            TempParaRng.SetRange(TempParaRng.Start, TempParaRng.End - 1)
            If (InStr(1, TempParaRng.Text, ". ", vbTextCompare) = 0 And InStr(1, TempParaRng.Text, ": ", vbTextCompare) = 0) Then GoTo SkipLoop
            If TempParaRng.Font.Bold = True Or TempParaRng.Font.Italic = True Then GoTo SkipLoop
            Do While TempParaRng.Characters.First.Text = " "
                TempParaRng.Characters.First.Delete()
            Loop
            If ((TempParaRng.Words.Item(1).Font.Italic = True) Or (TempParaRng.Words.Item(1).Font.Bold = True) Or (TempParaRng.Words.Item(1).Font.Underline <> WdUnderline.wdUnderlineNone)) And _
            (TempParaRng.Text.Contains(": ") = True Or TempParaRng.Text.Contains(". ") = True) Then
                TempParaRng.Select()
                WordApp.Selection.Collapse(WdCollapseDirection.wdCollapseStart)
                Do While ((WordApp.Selection.Range.Next.Words.Item(1).Font.Bold = True) Or (WordApp.Selection.Range.Next.Words.Item(1).Font.Underline <> WdUnderline.wdUnderlineNone) Or _
                (WordApp.Selection.Range.Next.Words.Item(1).Font.Italic = True) Or (WordApp.Selection.Range.Next.Text Like "[:.]"))
                    WordApp.Selection.MoveRight(WdUnits.wdCharacter, 1, WdMovementType.wdExtend)
                Loop
                TempParaRng.SetRange(WordApp.Selection.Range.End, P.Range.End)
                If ((Right(WordApp.Selection.Text, 2) = ". " Or Right(WordApp.Selection.Text, 2) = ": ") And (TempParaRng.ComputeStatistics(WdStatistic.wdStatisticLines) > 2 And _
                    StringWithRegMatches(WordApp.Selection.Text, "(|addresses|corres|author|article|short|running|title|figure|fig|scheme|chart|plate|map|diagram|table|tab)", True, True, False) = 0) And _
                    StringWithRegMatches(WordApp.Selection.Text, "(" & SkipSecHeadPattern & ")", True, True, False) = 0) Then
                    'This if validate the selection text have punctuation and the remaining text length greater 12
                    Do While (WordApp.Selection.Range.Characters.Last.Text Like "[:. ]")
                        WordApp.Selection.Range.Characters.Last.Text = String.Empty
                        If WordApp.Selection.Range.Next(WdUnits.wdCharacter, 1).Text = " " Then WordApp.Selection.Range.Next(WdUnits.wdCharacter, 1).Text = String.Empty
                    Loop
                    WordApp.Selection.InsertAfter(Chr(13))
                    TempParaRng.SetRange(WordApp.Selection.Range.Start, WordApp.Selection.Range.Start + 1)
                    IntCnt += 1 : TempParaRng.Bookmarks.Add("SecQuery_" & IntCnt, TempParaRng)
                End If
                WordApp.Selection.EscapeKey() : WordApp.Selection.ExtendMode = False
                WordApp.Selection.Collapse(WdCollapseDirection.wdCollapseStart)
            End If
SkipLoop:
        Next P
        WordApp.ScreenUpdating = True
    End Function

    Private Function ToSetAndGetParaInfo(ByRef PRng As Range, Optional ByVal ReturnNodeName As Boolean = False, Optional ByVal NodeName As String = "", Optional ByVal AttributeName As String = "") As String
        Dim TempInfoStr As String
        ToSetAndGetParaInfo = ""
        If PRng Is Nothing Then Exit Function
        If PRng.ComputeStatistics(WdStatistic.wdStatisticLines) > 2 Then Exit Function
        If PRng.Characters.Last.Text = Chr(13) Then PRng.SetRange(PRng.Start, PRng.End - 1)
        Dim PInfoRng As Range = PRng.Duplicate
        Dim StyObj As Style = PInfoRng.Style


        Do While StringWithRegMatches(PInfoRng.Characters.First.Text, "(\.|\,|\!|\?|\:|\|\s|\t|\r|\n)", True) > 0
            PInfoRng.SetRange(PInfoRng.Start + 1, PInfoRng.End)
        Loop
        Do While StringWithRegMatches(PInfoRng.Characters.Last.Text, "(\.|\,|\!|\?|\:|\|\s|\t|\r|\n)", True) > 0
            PInfoRng.SetRange(PInfoRng.Start, PInfoRng.End - 1)
        Loop


        TempInfoStr = String.Empty
        TempInfoStr = TempInfoStr & "|" & "FS=" & PInfoRng.Font.Size & "|" & "FU=" & PInfoRng.Font.Underline


        '####### This validation should be based on the no. of caps line present in document ########
        If bAddCapsInfo = True Then
            Select Case PInfoRng.Font.AllCaps OrElse UCase(PInfoRng.Text) = PInfoRng.Text
                Case True : TempInfoStr = TempInfoStr & "|FAC=True"
                Case False : TempInfoStr = TempInfoStr & "|FAC=False"
            End Select
        End If

        Select Case PInfoRng.Font.SmallCaps
            Case True : TempInfoStr = TempInfoStr & "|FSC=True"
            Case False : TempInfoStr = TempInfoStr & "|FSC=False"
        End Select

        Select Case PInfoRng.Font.Bold
            Case True : TempInfoStr = TempInfoStr & "|FB=True"
            Case False : TempInfoStr = TempInfoStr & "|FB=False"
        End Select

        Select Case PInfoRng.Font.Italic
            Case True : TempInfoStr = TempInfoStr & "|FI=True"
            Case False : TempInfoStr = TempInfoStr & "|FI=False"
        End Select



        If ReturnNodeName = False Then
            If AttributeName <> "" Then NodeName = NodeName & "|" & AttributeName
            If NodeName <> "" Then
                If ParaInfoCollection Is Nothing Then ParaInfoCollection = New Hashtable
                If ParaInfoCollection.ContainsKey(TempInfoStr) = False Then
                    ParaInfoCollection.Add(TempInfoStr, NodeName)
                Else
                    ParaInfoCollection.Remove(TempInfoStr)
                    ParaInfoCollection.Add(TempInfoStr, NodeName)
                End If
            End If
        Else
            If Not ParaInfoCollection Is Nothing Then
                If ParaInfoCollection.Count > 0 Then
                    Dim Ikey As DictionaryEntry
                    For Each Ikey In ParaInfoCollection
                        Select Case True
                            Case Ikey.Key.ToString.Contains(TempInfoStr)
                                ToSetAndGetParaInfo = Ikey.Value : Exit For
                            Case Else ' Do Nothing
                        End Select
                    Next
                End If
            End If
        End If
    End Function

    Private Function ToRemoveAllNodes(ByVal oWordDoc As Document) As Boolean
        On Error Resume Next
        Dim TagName As String
        Dim I As Integer, J As Integer : Dim XCnt As Integer = oWordDoc.XMLNodes.Count
        ToRemoveAllNodes = True
        If XCnt = 0 Then Exit Function
        Dim iPCnt As Integer
        Dim PRng As Range
        ReferencesRng = Nothing
        Call ToRemoveFullXSD(oWordDoc)
        If oWordDoc.XMLNodes.Count > 0 Then
            iPCnt = oWordDoc.Range.Paragraphs.Count
            For I = iPCnt To 1 Step -1
                PRng = oWordDoc.Range.Paragraphs(I).Range
                If PRng.Information(WdInformation.wdWithInTable) = False Then
                    XCnt = PRng.XMLNodes.Count
                    For J = XCnt To 1 Step -1
                        If ReferencesRng Is Nothing Then
                            Select Case True
                                Case Regex.IsMatch(PRng.XMLNodes(J).BaseName, "(back)", RegexOptions.IgnoreCase)
                                    ReferencesRng = PRng.XMLNodes(J).Range.Duplicate
                                Case Else 'Do Nothing
                            End Select
                        End If
                        PRng.XMLNodes(J).Delete()
                    Next
                    If Trim(PRng.Text) = vbCr AndAlso PRng.XMLNodes.Count = 0 Then PRng.Text = String.Empty
                End If
            Next
            With oWordDoc
                .XMLSchemaReferences("AS").Delete()
                .XMLSchemaReferences.AutomaticValidation = False
                .XMLSchemaReferences.AllowSaveAsXMLWithoutValidation = True
            End With
        End If
        If oWordDoc.Range.Paragraphs.Last.Range.Text = vbCr Then oWordDoc.Range.Paragraphs.Last.Range.Delete()
        If oWordDoc.Range.Paragraphs.First.Range.Text = vbCr Then oWordDoc.Range.Paragraphs.First.Range.Delete()
    End Function

    Private Function ToRemoveFullXSD(ByVal oWordDoc As Document) As Boolean
        On Error Resume Next
        With oWordDoc
            .XMLSchemaReferences("AS").Delete()
            .XMLSchemaReferences.AutomaticValidation = False
            .XMLSchemaReferences.AllowSaveAsXMLWithoutValidation = True
        End With
        oWordDoc.Range.Select()
        oWordDoc.Application.Selection.WholeStory()
        oWordDoc.Application.Selection.XMLParentNode.Delete()
        If oWordDoc.Range.Paragraphs.Last.Range.Text = vbCr Then oWordDoc.Range.Paragraphs.Last.Range.Delete()
        If oWordDoc.Range.Paragraphs.First.Range.Text = vbCr Then oWordDoc.Range.Paragraphs.First.Range.Delete()
    End Function

    Private Function TableStyling(ByVal TabApp As Application, ByVal TabDoc As Document, ByVal ConfigPath As String, Optional ByVal TabPubName As String = "")
        Dim I As Integer
        Dim T As Table
        Dim SpanFound As Boolean
        Dim TabHeadRng As Range, TabBodyRng As Range, CellRng As Range
        Dim TableHeadStyle As String = "" : Dim TableBodyStyle As String = ""
        TableHeadStyle = AuoStructureReadINI(ConfigPath, sSecStylesInfo, "Thead", "TableHeader")
        TableBodyStyle = AuoStructureReadINI(ConfigPath, sSecStylesInfo, "Tbody", "TableBody")
        For Each T In TabDoc.Tables
            TabHeadRng = Nothing : TabBodyRng = Nothing : CellRng = Nothing : SpanFound = False
            For I = 1 To T.Rows.Count
                Try
                    If SpanFound = False Then
                        T.Rows.Item(I).Range.Select()
                    Else
                        If I = 1 Then
                            T.Range.Cells.Item(1).Range.Select()
                            TabApp.Selection.SelectRow()
                        Else
                            If TabApp.Selection.Tables.Count > 0 Then
                                TabApp.Selection.Next(WdUnits.wdRow).Select()
                            Else
                                T.Range.Cells.Item(1).Range.Select()
                                TabApp.Selection.SelectRow()
                            End If
                        End If
                    End If
                    If TabApp.Selection.Range.Font.Bold = True Or I = 1 Then
                        If TabHeadRng Is Nothing Then
                            TabHeadRng = TabApp.Selection.Range.Duplicate
                        Else
                            TabHeadRng.SetRange(TabHeadRng.Start, TabApp.Selection.End)
                        End If
                    Else
                        If TabHeadRng Is Nothing Then
                            TabHeadRng = Nothing
                            TabBodyRng = T.Range.Duplicate
                        Else
                            TabBodyRng = T.Range.Duplicate
                            TabBodyRng.SetRange(TabHeadRng.End, T.Range.End)
                        End If
                        Exit For
                    End If
                Catch ex As Exception
                    ex.Data.Clear() : Err.Clear()
                    SpanFound = True
                    I -= I
                End Try
            Next
            If Not TabHeadRng Is Nothing And Not TabBodyRng Is Nothing Then
                If TabHeadRng.End >= TabBodyRng.End Then
                    If SpanFound = True Then
                        T.Range.Cells.Item(1).Select()
                        TabApp.Selection.SelectRow()
                        TabHeadRng = TabApp.Selection.Range.Duplicate
                        TabBodyRng.SetRange(TabHeadRng.End, TabBodyRng.End)
                    Else
                        TabHeadRng = T.Range.Rows.Item(1).Range.Duplicate
                        TabBodyRng.SetRange(TabHeadRng.End, TabBodyRng.End)
                    End If
                End If
            ElseIf T.Rows.Count = 1 Then
                TabHeadRng = Nothing
                TabBodyRng = T.Range.Duplicate
            End If

            If Not (TabBodyRng Is Nothing) And TableBodyStyle <> "" Then
                Try
                    TabBodyRng.Style = TableBodyStyle
                Catch ex As Exception
                    ex.Data.Clear()
                End Try
            End If

            If Not (TabHeadRng Is Nothing) And TableHeadStyle <> "" Then
                Try
                    TabHeadRng.Style = TableHeadStyle
                Catch ex As Exception
                    ex.Data.Clear()
                End Try
            End If
        Next
    End Function

    Private Function ToGetAttributeVal(ByVal ANode As XMLNode, ByVal AttributeName As String) As String
        Dim ACnt As Integer = ANode.Attributes.Count
        Dim J As Integer
        For J = 1 To ACnt
            If ANode.Attributes(J).BaseName.ToLower = AttributeName.ToLower Then
                ToGetAttributeVal = ANode.Attributes(J).NodeValue
                Exit Function
            End If
        Next
        ToGetAttributeVal = ""
    End Function


    Private Function ToCopyStyle(ByVal StyleTemplatePath As String, ByVal AutoStyleDoc As Document) As Boolean
        On Error Resume Next
        AutoStyleDoc.UpdateStylesOnOpen = True
        Dim ValFalse As Object = False, newTemplate As Object = False, docType As Object = 0
        Dim JournalTemplateDoc As Document
        JournalTemplateDoc = AutoStyleDoc.Application.Documents.Add(StyleTemplatePath, newTemplate, docType, ValFalse)
        JournalTemplateDoc.ActiveWindow.Visible = False
        Dim Sty As Style
        For Each Sty In JournalTemplateDoc.Styles
            If Sty.BuiltIn = False Then
                AutoStyleDoc.Application.OrganizerCopy(JournalTemplateDoc.FullName, AutoStyleDoc.FullName, Sty.NameLocal, WdOrganizerObject.wdOrganizerObjectStyles)
            End If
        Next
        JournalTemplateDoc.Close(WdSaveOptions.wdDoNotSaveChanges)
        ToCopyStyle = True
    End Function

    Private Function StyleOverrides(ByVal whichStylesINI As String, ByVal wDoc As Document) As Boolean
        On Error Resume Next
        Dim oCommandtext As String = String.Empty : Dim oStyletext As String = String.Empty : Dim oFormatoverride As String = String.Empty
        Dim wStylename As String = String.Empty : Dim wFormattype As String = String.Empty : Dim wFormatValue As String = String.Empty
        Dim oVrnt As Object : Dim xVrnt As Object
        oCommandtext = ReadINI(whichStylesINI, "Style_overrides", "ChangeFormat", String.Empty, False)
        For Each oVrnt In Split(oCommandtext, "||")
            If InStr(1, oVrnt, "+") > 0 Then
                xVrnt = Split(oVrnt, "+")
                wStylename = Trim(xVrnt(0))
                If Regex.IsMatch(Trim(xVrnt(1)), "\[.*?\]", RegexOptions.IgnoreCase) = True Then
                    Dim oMats As MatchCollection = Regex.Matches(Trim(xVrnt(1)), "\[.*?\]", RegexOptions.IgnoreCase)
                    wFormatValue = oMats(0).Value
                End If
                wFormattype = Trim(Replace(xVrnt(1), wFormatValue, "", 1, -1, vbTextCompare))
                wFormatValue = Replace(wFormatValue, "[", "")
                wFormatValue = Replace(wFormatValue, "]", "")
                Select Case LCase(wFormattype)
                    Case LCase("Italic")
                        wDoc.Styles(wStylename).Font.Italic = True
                    Case LCase("notitalic")
                        wDoc.Styles(wStylename).Font.Italic = False
                    Case LCase("Bold")
                        wDoc.Styles(wStylename).Font.Bold = True
                    Case LCase("notbold")
                        wDoc.Styles(wStylename).Font.Bold = False
                    Case LCase("Superscript")
                        wDoc.Styles(wStylename).Font.Superscript = True
                    Case LCase("notsuperscript")
                        wDoc.Styles(wStylename).Font.Superscript = False
                    Case LCase("Subscript")
                        wDoc.Styles(wStylename).Font.Subscript = True
                    Case LCase("notsubscript")
                        wDoc.Styles(wStylename).Font.Subscript = False
                    Case LCase("AllCaps")
                        wDoc.Styles(wStylename).Font.AllCaps = True
                    Case LCase("notallcaps")
                        wDoc.Styles(wStylename).Font.AllCaps = False
                    Case LCase("Delete")
                        wDoc.Styles(wStylename).Delete()
                    Case LCase("rename")
                        wDoc.Styles(wStylename).NameLocal = wFormatValue
                    Case LCase("color")
                        wDoc.Styles(wStylename).Font.Color = CLng(wFormatValue)
                End Select
            End If
        Next
    End Function

    Private Function ReplaceSpecialText(ByVal WordDoc As Document, ByVal sSpecialText As String, Optional ByVal sReplaceText As String = "^p")
        On Error Resume Next
        With WordDoc.Content.Find
            .ClearFormatting() : .Text = sSpecialText
            .Replacement.ClearFormatting() : .Replacement.Text = sReplaceText
            .Forward = True : .Wrap = WdFindWrap.wdFindContinue
            .Format = False : .MatchCase = False
            .MatchWholeWord = False : .MatchWildcards = False
            .MatchSoundsLike = False : .MatchAllWordForms = False
            .Execute(Replace:=WdReplace.wdReplaceAll)
        End With
Errorhandler:
        If Err.Number <> 0 Then Err.Clear()
        On Error GoTo 0
    End Function

    Private Function CollapseText(ByVal WordDoc As Document, ByVal sFind As String, ByVal sReplace As String) As Boolean
        On Error Resume Next
        Dim lDocSize As Long
        CollapseText = False
        lDocSize = WordDoc.Content.End
        Call ReplaceSpecialText(WordDoc, sFind, sReplace)
        CollapseText = (lDocSize > WordDoc.Content.End)
    End Function

    Private Function ConvertsList2Text(ByVal WordDoc As Document)
        Dim yRng As Range
        On Error Resume Next
        For Each yRng In WordDoc.StoryRanges
            yRng.ListFormat.ConvertNumbersToText()
        Next
        Err.Clear()
    End Function

    Private Function ToRemoveBookmarks(ByVal WordDoc As Document, Optional ByVal SkipPattern As String = "") As Boolean
        Dim BK As Bookmark
        Try
            If WordDoc.Bookmarks.Count = 0 Then ToRemoveBookmarks = True : Exit Function
            Call ToRemoveEmptyBookmarks(WordDoc)
            WordDoc.Bookmarks.ShowHidden = False : WordDoc.Bookmarks.ShowHidden = True
            If Trim(SkipPattern) <> "" Then
                SkipPattern = "(" & SkipPattern & ")"
                Dim rRegExp As New Regex(SkipPattern, RegexOptions.IgnoreCase)
                For Each BK In WordDoc.Bookmarks
                    If rRegExp.IsMatch(BK.Name) = False Then BK.Delete()
                    WordDoc.UndoClear()
                Next
                rRegExp = Nothing
            Else
                For Each BK In WordDoc.Bookmarks
                    BK.Delete() : WordDoc.UndoClear()
                Next
            End If
            ToRemoveBookmarks = True
        Catch ex As Exception
            ex.Data.Clear()
        Finally
            BK = Nothing
        End Try
    End Function

    '######### To remove empty bookmarks in the document ###########
    Private Function ToRemoveEmptyBookmarks(ByVal WordDoc As Document) As Boolean
        If WordDoc.Bookmarks.Count = 0 Then ToRemoveEmptyBookmarks = True : Exit Function
        WordDoc.Bookmarks.ShowHidden = False : WordDoc.Bookmarks.ShowHidden = True
        Try
            Dim BKName As String = WordDoc.Bookmarks(1).Name
            ToRemoveEmptyBookmarks = True
        Catch ex As Exception
            Dim WrdDlg As Dialog
            WrdDlg = WordDoc.Application.Dialogs(WdWordDialog.wdDialogInsertBookmark)
            WrdDlg.Delete = 1 : WrdDlg.Execute()
            ex = Nothing
        Finally
            ToRemoveEmptyBookmarks = True
        End Try
    End Function

    Private Function RegMatchesAndCustomValidate(ByVal SourceStr As String, ByVal PatternStr As String, Optional ByVal BeginLine As Boolean = False, Optional ByVal EndLine As Boolean = False, Optional ByVal IgnoreCase As Boolean = True, Optional ByVal CheckRegExMatchNextWordAsCaps As Boolean = False) As Boolean
        Try
            PatternStr = Replace(PatternStr, " ", "(\s*)", 1, -1, CompareMethod.Text)
            Dim OpenStr As String, CloseStr As String, RegexPattern As String
            Dim Options As RegexOptions
            If BeginLine = True Then OpenStr = "((\n|\r|^)(\s*)(" Else OpenStr = "((\s*)("
            If EndLine = True Then CloseStr = ")[.:;\t ]*$)" Else CloseStr = ")[.:;\t ]*)"
            RegexPattern = OpenStr & PatternStr & CloseStr
            If IgnoreCase = True Then Options = RegexOptions.IgnoreCase
            If String.IsNullOrEmpty(SourceStr) = False Then
                SourceStr = Trim(SourceStr)
                Dim sNextWord As String
                Dim sMatchVal As String
                Dim rExp As System.Text.RegularExpressions.Regex = New System.Text.RegularExpressions.Regex(RegexPattern, Options)
                Dim rSMatches As System.Text.RegularExpressions.MatchCollection = rExp.Matches(SourceStr)
                If rSMatches.Count > 0 Then
                    sMatchVal = rSMatches(0).Value()
                    If CheckRegExMatchNextWordAsCaps = True Then
                        sNextWord = Trim(Right(SourceStr, Len(SourceStr) - Len(sMatchVal)))
                        If sNextWord.Length > 0 Then
                            If Left(sNextWord, 1) = Left(sNextWord, 1).ToUpper Then RegMatchesAndCustomValidate = True Else RegMatchesAndCustomValidate = False
                        End If
                        Exit Function
                    Else
                        RegMatchesAndCustomValidate = True
                    End If
                End If
            End If
        Catch ex As Exception
            ex.Data.Clear()
        End Try
    End Function

    Private Function AutoStructureStringToRegPattern(ByVal RegString As String) As String
        RegString = Replace(RegString, "||", "|", 1, -1, vbTextCompare)
        RegString = Regex.Replace(RegString, "(\n|^|\r)(\|+)", "$1")
        RegString = Regex.Replace(RegString, "(\|+)($)", "$2")
        RegString = Replace(RegString, "*", "(\*)", 1, -1, vbTextCompare)
        RegString = Replace(RegString, "?", "(\?)", 1, -1, vbTextCompare)
        RegString = Replace(RegString, "+", "(\+)", 1, -1, vbTextCompare)
        RegString = Replace(RegString, "(", "\(", 1, -1, vbTextCompare) : RegString = Replace(RegString, ")", "\)", 1, -1, vbTextCompare)
        RegString = Replace(RegString, "[", "\[", 1, -1, vbTextCompare) : RegString = Replace(RegString, "]", "\]", 1, -1, vbTextCompare)
        RegString = Replace(RegString, "{", "\{", 1, -1, vbTextCompare) : RegString = Replace(RegString, "}", "\}", 1, -1, vbTextCompare)
        RegString = Replace(RegString, " ", "(\s*)", 1, -1, vbTextCompare)
        RegString = Replace(RegString, ",", "\,", 1, -1, vbTextCompare)
        RegString = Replace(RegString, "@", "\@", 1, -1, vbTextCompare)
        RegString = Replace(RegString, ";", "\;", 1, -1, vbTextCompare)
        RegString = Replace(RegString, ".", "\.", 1, -1, vbTextCompare)
        RegString = Replace(RegString, ":", "\:", 1, -1, vbTextCompare)
        RegString = Replace(RegString, "\\", "\", 1, -1, vbTextCompare)
        AutoStructureStringToRegPattern = "(" & RegString & ")"
    End Function

    Private Function StringWithRegMatches(ByVal SourceStr As String, ByVal PatternStr As String, Optional ByVal IgnoreCase As Boolean = True, Optional ByVal BeginLine As Boolean = False, Optional ByVal EndLine As Boolean = False) As Integer
        Try
            PatternStr = Replace(PatternStr, " ", "(\s*)", 1, -1, CompareMethod.Text)
            Dim RegexPattern As String
            Dim OpenStr As String, CloseStr As String
            Dim Options As RegexOptions = RegexOptions.None
            If BeginLine = True Then OpenStr = "((\n|\r|^)(\s*)(" Else OpenStr = "((\s*)("
            If EndLine = True Then CloseStr = ")[.:;\t ]*$)" Else CloseStr = ")[.:;\t ]*)"
            RegexPattern = OpenStr & PatternStr & CloseStr
            If IgnoreCase = True Then Options = RegexOptions.IgnoreCase Else Options = RegexOptions.None
            If String.IsNullOrEmpty(SourceStr) = False Then
                SourceStr = Trim(SourceStr)
                Dim rExp As System.Text.RegularExpressions.Regex = New System.Text.RegularExpressions.Regex(RegexPattern, Options)
                Dim rSMatches As System.Text.RegularExpressions.MatchCollection = rExp.Matches(SourceStr)
                If rSMatches.Count > 0 Then
                    StringWithRegMatches = rSMatches.Count
                    Exit Function
                End If
            End If
        Catch ex As Exception
            StringWithRegMatches = 0
        End Try
    End Function

    Private Function StringWithRegMatchesReturnMatchVal(ByVal SourceStr As String, ByVal PatternStr As String, Optional ByVal BeginLine As Boolean = False, Optional ByVal EndLine As Boolean = False, Optional ByVal IgnoreCase As Boolean = True) As String
        PatternStr = Replace(PatternStr, " ", "(\s*)", 1, -1, CompareMethod.Text)
        Dim OpenStr As String, CloseStr As String, RegexPattern As String
        Dim Options As RegexOptions
        If BeginLine = True Then OpenStr = "((\n|\r|^)(\s*)(" Else OpenStr = "((\s*)("
        If EndLine = True Then CloseStr = ")[.:;\t ]*$)" Else CloseStr = ")[.:;\t ]*)"
        RegexPattern = OpenStr & PatternStr & CloseStr
        If IgnoreCase = True Then Options = RegexOptions.IgnoreCase
        If String.IsNullOrEmpty(SourceStr) = False Then
            SourceStr = Trim(SourceStr)
            Dim rExp As System.Text.RegularExpressions.Regex = New System.Text.RegularExpressions.Regex(RegexPattern, Options)
            Dim rSMatches As System.Text.RegularExpressions.MatchCollection = rExp.Matches(SourceStr)
            If rSMatches.Count > 0 Then
                StringWithRegMatchesReturnMatchVal = rSMatches(0).Value()
                Exit Function
            End If
        End If
        StringWithRegMatchesReturnMatchVal = ""
    End Function

    Private Function StringWithRegMatchesReturnMatchValLen(ByVal SourceStr As String, ByVal PatternStr As String, Optional ByVal BeginLine As Boolean = False, Optional ByVal EndLine As Boolean = False, Optional ByVal IgnoreCase As Boolean = True) As Integer
        PatternStr = Replace(PatternStr, " ", "(\s*)", 1, -1, CompareMethod.Text)
        Dim OpenStr As String, CloseStr As String, RegexPattern As String
        Dim Options As RegexOptions
        If BeginLine = True Then OpenStr = "((\n|\r|^)(\s*)(" Else OpenStr = "((\s*)("
        If EndLine = True Then CloseStr = ")[.:;\t ]*$)" Else CloseStr = ")[.:;\t ]*)"
        RegexPattern = OpenStr & PatternStr & CloseStr
        If IgnoreCase = True Then Options = RegexOptions.IgnoreCase
        If String.IsNullOrEmpty(SourceStr) = False Then
            SourceStr = Trim(SourceStr)
            Dim rExp As System.Text.RegularExpressions.Regex = New System.Text.RegularExpressions.Regex(RegexPattern, Options)
            Dim rSMatches As System.Text.RegularExpressions.MatchCollection = rExp.Matches(SourceStr)
            If rSMatches.Count > 0 Then
                StringWithRegMatchesReturnMatchValLen = rSMatches(0).Value().Length
                Exit Function
            End If
        End If
        StringWithRegMatchesReturnMatchValLen = 0
    End Function

    Private Function ToCheckEndLinePunctuations(ByVal sFindString As String, Optional ByVal iSuffixCharCount As Integer = 0, Optional ByVal sFindPattern As String = "") As Boolean
        Try
            If String.IsNullOrEmpty(sFindPattern) = True Then sFindPattern = "(\:|\;|\,)"
            If iSuffixCharCount > 0 Then
                If iSuffixCharCount <= sFindString.Length Then
                    sFindString = Right(sFindString, iSuffixCharCount)
                    ToCheckEndLinePunctuations = Regex.IsMatch(sFindString, sFindPattern, RegexOptions.IgnoreCase)
                Else
                    ToCheckEndLinePunctuations = False
                End If
            Else
                ToCheckEndLinePunctuations = Regex.IsMatch(sFindString, sFindPattern, RegexOptions.IgnoreCase)
            End If
        Catch ex As Exception
            ex.Data.Clear()
            ToCheckEndLinePunctuations = False
        End Try
    End Function

    Private Function AuoStructureReadINI(ByVal INIPath As String, ByVal SectionName As String, ByVal KeyName As String, ByVal DefaultValue As String, Optional ByVal IsRegPattern As Boolean = False, Optional ByVal NeedBoundary As Boolean = False, Optional ByVal IsXPathInfo As Boolean = False) As String
        Dim n As Integer
        Dim sData As New String(" ", 65536)
        n = GetPrivateProfileString(SectionName, KeyName, DefaultValue, sData, sData.Length, INIPath)
        If n > 0 Then
            AuoStructureReadINI = sData.Substring(0, n)
            If IsRegPattern = True Then
                AuoStructureReadINI = AuoStructureReadINI.Replace(" ", "\s*")
                AuoStructureReadINI = AuoStructureReadINI.Replace("<dot>", "[\.\,\:\;\u002D\u2013\u2014\s]*")
                Select Case NeedBoundary
                    Case True : AuoStructureReadINI = "\b(" & AuoStructureReadINI & ")\b"
                    Case False : AuoStructureReadINI = "(" & AuoStructureReadINI & ")"
                End Select
            End If
        Else
            Select Case True
                Case IsRegPattern : AuoStructureReadINI = "(########)"
                Case IsXPathInfo : AuoStructureReadINI = "//xyz"
                Case Else : AuoStructureReadINI = ""
            End Select
        End If
    End Function

    Private Function ToMoveCaptionsForAutoStructure() As Boolean
        On Error GoTo Errorhandler
        Dim I As Integer
        Dim MoveCaptionAtEnd As Boolean
        Dim FigPatt As String, TabPatt As String, CaptionsPatt As String = ""
        Dim FRng As Range, CapRng As Range, MoveCaption As Boolean
        FigPatt = "(^(Figure|Fig|Scheme|Chart|Plate|Map|Diagram)[s]?(\.)?\s*(([0-9ivx]((-|.)[0-9ivx])?)+(\.|\:)))"
        TabPatt = "(^(Table|Tab)[s]?(\.)?\s*(([0-9ivx]((-|.)[0-9ivx])?)+(\.|\:)))"

        'rReg = New RegExp : rReg.Multiline = True : rReg.Global = True : rReg.IgnoreCase = True

        If Not (FloatRng Is Nothing) Then
            CapRng = FloatRng.Duplicate
        Else
            WordApp.Selection.EndKey(WdUnits.wdStory)
            WordApp.Selection.InsertAfter(Chr(13)) : WordApp.Selection.Style = "Normal"
            FloatRng = WordApp.Selection.Range : WordApp.Selection.Collapse(WdCollapseDirection.wdCollapseEnd)
            CapRng = FloatRng.Duplicate
        End If

        'Select Case PubName_Pre
        '    Case "informa1" : ExpandInfo = "BackMatter||Table"
        '    Case Else : ExpandInfo = "Tables||Figures||Miscellaneous"
        'End Select


        If Not (BodyRng Is Nothing) Then
            For I = 1 To 2
                Select Case I
                    Case 1 : CaptionsPatt = FigPatt
                    Case 2 : CaptionsPatt = TabPatt
                End Select
                FRng = BodyRng.Duplicate : FRng.Find.ClearFormatting() : FRng.Find.Replacement.ClearFormatting()
                Dim rReg As New Regex(CaptionsPatt)
                Dim rMatches As MatchCollection = rReg.Matches(BodyRng.Text) : Dim rMatch As Match
                For Each rMatch In rMatches
                    TempCaptionRng = Nothing : MoveCaption = False
                    FRng.Find.Text = "^p" & rMatch.Value
                    If FRng.Find.Execute = True Then
                        FRng.SetRange(FRng.Start + 1, FRng.End)
                        FRng.SetRange(FRng.Start, FRng.Paragraphs.Item(1).Range.End)
                        If I = 2 Then
                            FRng.SetRange(FRng.Start, FRng.Paragraphs.Item(1).Range.End + 10)
                            If FRng.Next.Paragraphs.Count > 0 Then
                                FRng.SetRange(FRng.Start, FRng.Next.Paragraphs.Item(1).Range.End)
                                If FRng.Tables.Count > 0 Then
                                    FRng.SetRange(FRng.Start, FRng.Tables.Item(1).Range.End)
                                Else
                                    FRng.SetRange(FRng.Start, FRng.Paragraphs.Item(1).Range.End)
                                End If
                            End If
                        End If
                        TempCaptionRng = FRng.Duplicate
                        TempCaptionRng.HighlightColorIndex = WdColorIndex.wdGreen
                        TempCaptionRng.Select() : WordApp.ActiveWindow.ScrollIntoView(WordApp.Selection.Range, True)
                        Select Case I
                            Case 1 : frmAuto.Button4.Focus()
                            Case 2 : frmAuto.Button6.Focus()
                        End Select

                        frmAuto.Button1.Enabled = False
                        frmAuto.GroupBox1.Enabled = False
                        frmAuto.GroupBox2.Enabled = False
                        frmAuto.TreeView1.Enabled = False
                        frmAuto.GroupBox3.Enabled = True
                        frmAuto.TopMost = True
                        frmAuto.ShowDialog()
                        If Not (TempCaptionRng Is Nothing) Then
                            TempCaptionRng.HighlightColorIndex = WdColorIndex.wdNoHighlight
                            '########## New update ###########
                            If CapRng.Text <> String.Empty Then CapRng.SetRange(CapRng.End, CapRng.End)
                            '########## New update ###########
                            CapRng.FormattedText = TempCaptionRng
                            TempCaptionRng.Delete()
                            CapRng.SetRange(CapRng.End, CapRng.End)
                            MoveCaption = True  ' MoveCaption  using to move the caption rng and place near to float rng the document
                            MoveCaptionAtEnd = True
                            FRng.SetRange(FRng.Start - 3, FRng.Start - 3) : FRng.Collapse(WdCollapseDirection.wdCollapseEnd)
                        End If
                    End If
                    If MoveCaption = False Then
                        FRng.SetRange(FRng.Start, FRng.Start + 3)
                        FRng.Collapse(WdCollapseDirection.wdCollapseEnd)
                    End If
                Next rMatch
            Next I
        End If

        If MoveCaptionAtEnd = True Then
            If Not (BackRng Is Nothing) Then
                FloatRng.SetRange(FloatRng.Start, CapRng.End)
                BackRng.SetRange(BackRng.Start, FloatRng.Start - 1)
            ElseIf Not (BodyRng Is Nothing) Then
                FloatRng.SetRange(FloatRng.Start, CapRng.End)
                BodyRng.SetRange(BodyRng.Start, FloatRng.Start - 1)
            ElseIf Not (HeadRng Is Nothing) Then
                FloatRng.SetRange(FloatRng.Start, CapRng.End)
                HeadRng.SetRange(HeadRng.Start, FloatRng.Start - 1)
            End If
        End If

        '######### For Remove Shape range in doucment #######
        Dim Cnt As Integer
        Dim Sh As Shape
        Dim InSh As InlineShape
        For Each Sh In WordDoc.Shapes
            Cnt = Cnt + 1

            If Sh.Type <> Microsoft.Office.Core.MsoShapeType.msoEmbeddedOLEObject And Sh.Type <> Microsoft.Office.Core.MsoShapeType.msoGroup Then
                Sh.Select() : IdentifierValStr = ""
                Sh.Line.Style = Microsoft.Office.Core.MsoLineStyle.msoLineThinThick
                Sh.Line.DashStyle = Microsoft.Office.Core.MsoLineDashStyle.msoLineRoundDot
                Sh.Line.Visible = Microsoft.Office.Core.MsoTriState.msoTrue
                Sh.Line.ForeColor.RGB = RGB(255, 0, 255)
                WordApp.ActiveWindow.ScrollIntoView(WordApp.Selection.Range, True)

                frmAuto.GroupBox1.Enabled = True
                frmAuto.GroupBox2.Enabled = True
                frmAuto.TreeView1.Enabled = False
                frmAuto.GroupBox3.Enabled = False
                frmAuto.Button2.Focus()
                frmAuto.TopMost = True
                frmAuto.ShowDialog()
                Select Case IdentifierValStr.Contains("del")
                    Case True : Sh.Delete()
                    Case False : Sh.Name = IdentifierValStr & "SH_AS" & Cnt
                        Sh.Line.Visible = Microsoft.Office.Core.MsoTriState.msoFalse
                End Select
            End If
        Next

        '######### For Remove Inline Shape range in doucment #######
        For Each InSh In WordDoc.InlineShapes
            Cnt = Cnt + 1
            If InSh.Type <> WdInlineShapeType.wdInlineShapeEmbeddedOLEObject And InSh.Type <> WdInlineShapeType.wdInlineShapeOLEControlObject Then
                InSh.Select()
                InSh.Line.Style = Microsoft.Office.Core.MsoLineStyle.msoLineThinThick
                InSh.Line.DashStyle = Microsoft.Office.Core.MsoLineDashStyle.msoLineRoundDot
                InSh.Line.Visible = Microsoft.Office.Core.MsoTriState.msoTrue
                InSh.Line.ForeColor.RGB = RGB(255, 0, 255)
                WordApp.ActiveWindow.ScrollIntoView(WordApp.Selection.Range, True)

                frmAuto.GroupBox1.Enabled = True : frmAuto.GroupBox2.Enabled = True
                frmAuto.TreeView1.Enabled = False : frmAuto.GroupBox3.Enabled = False
                frmAuto.Button2.Focus()
                frmAuto.TopMost = True : frmAuto.ShowDialog()
                Select Case IdentifierValStr.Contains("del")
                    Case True : InSh.Delete()
                    Case False
                        'ToAddBookmark(InSh.Range, IdentifierValStr & "INSH_AS" & Cnt, False)
                        InSh.Line.Visible = Microsoft.Office.Core.MsoTriState.msoFalse
                End Select
            End If
        Next

        Dim T As Table
        Dim C As Cell

        For Each T In WordDoc.Tables
            CapRng = T.Range.Cells.Item(1).Range
            T.Range.Cells.Item(1).Row.Select()
            If RegExMatch(CapRng.Text, TabPatt, True, True) = True Then
                T.Range.Select()
                WordApp.Selection.Collapse(WdCollapseDirection.wdCollapseStart)
                WordApp.Selection.MoveLeft(WdUnits.wdCharacter, 1)
                WordApp.Selection.TypeParagraph()
                For I = 1 To T.Range.Rows.Item(1).Range.Cells.Count
                    CapRng = Nothing
                    CapRng = T.Range.Rows.Item(1).Cells.Item(I).Range
                    CapRng.SetRange(CapRng.Start, CapRng.End - 1)
                    If Not (CapRng Is Nothing) = True Then
                        If CapRng.Text <> String.Empty Then
                            WordApp.Selection.TypeParagraph()
                            WordApp.Selection.Range.FormattedText = CapRng
                        End If
                    End If
                Next
                On Error Resume Next
                T.Range.Cells.Item(1).Row.Delete()
            End If
        Next T
        WordDoc.UndoClear()
        ToMoveCaptionsForAutoStructure = True
Errorhandler:
        Select Case Err.Number
            Case 0
            Case Else
                Err.Clear()
                Exit Function
        End Select
    End Function

    Public Function zAutoStyleForDemo(wDoc As Document, StyleIniPath As String, tempPath As String)
        Dim sTempFullPath As String = String.Empty : Dim sBackupDocFullPath As String = String.Empty
        Try
            WordApp = Nothing : WordDoc = Nothing
            WordApp = wDoc.Application : WordDoc = wDoc
            sTempFullPath = Path.Combine(Path.GetTempPath(), wDoc.Name)
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            If WordApp.ActiveWindow.View.SplitSpecial = WdSpecialPane.wdPaneNone Then
                WordApp.ActiveWindow.ActivePane.View.Type = WdViewType.wdNormalView
            Else
                WordApp.ActiveWindow.View.Type = WdViewType.wdNormalView
            End If
            WordApp.ActiveWindow.ActivePane.View.Zoom.Percentage = 100
            If WordApp.ActiveWindow.StyleAreaWidth = 0 Then WordApp.ActiveWindow.StyleAreaWidth = 1

            sBackupDocFullPath = Path.Combine(Path.Combine(wDoc.Path, "Backup"), wDoc.Name)
            If File.Exists(sBackupDocFullPath) = False Then
                Dim sBackUpDir As String = Path.Combine(wDoc.Path, "Backup")
                If Directory.Exists(sBackUpDir) = False Then Directory.CreateDirectory(sBackUpDir)
                File.Copy(wDoc.FullName, sBackupDocFullPath)
            End If
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            frmAuto.StylesConfPath = StyleIniPath

            ToApplyStyleForDemo(wDoc, tempPath)


        Catch ex As Exception
            MsgBox("Unable to complete the process ...")
            Call ToRevertDocument(wDoc, sBackupDocFullPath, sTempFullPath)
        End Try
    End Function
    Public Function ToApplyStyleForDemo(wDoc As Document, templatePath As String)
        Dim dictParaInfor As New Dictionary(Of Range, clsParaProperty)
        Dim dPara As Paragraph
        Dim fromAuto As New frmAutoStyles
        Try
            '''''''''''''''777777777777777777777777777,,,,,,,,,,
            Call ToCopyStyle(templatePath, wDoc)
            ''Call StyleOverrides(StylesConfPath, wDoc)
            '''''''''''''''77777777777777777777777777777777

            For Each dPara In wDoc.Paragraphs
                Dim objPara As New clsParaProperty
                Dim dictStyleInfor As New Dictionary(Of String, Integer)
                Dim wStyle As Style
                If dPara.Range.Information(WdInformation.wdWithInTable) = True Then GoTo NxtPara
                PRng = dPara.Range : TempStr = Trim(dPara.Range.Text)

                If TempStr = Chr(13) Or TempStr = Chr(11) Or TempStr = Chr(11) & Chr(13) Then GoTo NxtPara
                If PRng.Characters.Last.Text = Chr(13) Then PRng.SetRange(PRng.Start, PRng.End - 1)
                If PRng.InlineShapes.Count > 0 Or PRng.ShapeRange.Count > 0 Then
                    If Trim(PRng.Text) = "/" Or Trim(PRng.Text) = "" Then GoTo NxtPara
                End If
                ''''''''�ollect Para information''''

                wStyle = dPara.Style
                objPara.orgStyleName = wStyle.NameLocal
                objPara.pFontName = PRng.Font.Name
                objPara.FontSize = PRng.Font.Size
                If PRng.Font.Bold = True Then objPara.IsBold = True
                If PRng.Font.Italic = True Then objPara.IsItalic = True
                If PRng.ParagraphFormat.LeftIndent > 0 Then objPara.IsIndent = True
                dPara.Range.Select() : IdentifierValStr = String.Empty
                TempCaptionRng = dPara.Range.Duplicate
                dPara.Range.HighlightColorIndex = WdColorIndex.wdBrightGreen
                WordApp.ActiveWindow.ScrollIntoView(dPara.Range, True)

                If dictParaInfor.Count <> 0 Then
                    If dictParaInfor.Values.Where(Function(x) x.orgStyleName = objPara.orgStyleName And x.IsBold = objPara.IsBold And x.IsItalic = objPara.IsItalic And x.IsIndent = objPara.IsIndent And x.pFontName = objPara.pFontName And x.FontSize = objPara.FontSize).Select(Function(y) y.newStyledName).Count > 0 Then
                        Dim sStyled As String
                        For Each sStyled In dictParaInfor.Values.Where(Function(x) x.orgStyleName = objPara.orgStyleName And x.IsBold = objPara.IsBold And x.IsItalic = objPara.IsItalic And x.IsIndent = objPara.IsIndent And x.pFontName = objPara.pFontName And x.FontSize = objPara.FontSize).Select(Function(y) y.newStyledName).ToList()
                            Dim cCount As Integer = dictParaInfor.Values.Where(Function(x) x.orgStyleName = objPara.orgStyleName And x.IsBold = objPara.IsBold And x.IsItalic = objPara.IsItalic And x.IsIndent = objPara.IsIndent And x.pFontName = objPara.pFontName And x.FontSize = objPara.FontSize And x.newStyledName = sStyled).Count
                            If Not dictStyleInfor.ContainsKey(sStyled) Then
                                dictStyleInfor.Add(sStyled, cCount)
                            End If
                        Next
                    Else
                        IdentifierValStr = ""
                    End If
                    IdentifierValStr = dictParaInfor.Values.Where(Function(x) x.orgStyleName = objPara.orgStyleName And x.IsBold = objPara.IsBold And x.IsItalic = objPara.IsItalic And x.IsIndent = objPara.IsIndent And x.pFontName = objPara.pFontName And x.FontSize = objPara.FontSize).Select(Function(y) y.newStyledName).LastOrDefault()

                    If IdentifierValStr <> Nothing Then
                        Dim valStr As String
                        valStr = dictParaInfor.Values.Where(Function(x) x.orgStyleName = objPara.orgStyleName And x.IsBold = objPara.IsBold And x.IsItalic = objPara.IsItalic And x.IsIndent = objPara.IsIndent And x.pFontName = objPara.pFontName And x.FontSize = objPara.FontSize And x.ApplyStyleAll = True).Select(Function(y) y.newStyledName).LastOrDefault()
                        If valStr = IdentifierValStr Then UserConfirmStr = "yesall"
                    End If
                End If
shForm:
                If UserConfirmStr = "" Then
                    If IdentifierValStr <> "" Then
                        Dim objUserForm As New frmUserConformation(dictStyleInfor)
                        frmAuto.Top = True : objUserForm.ShowDialog()
                    Else
                        frmAuto.TopMost = True : frmAuto.ShowDialog()
                        UserConfirmStr = "yes"
                    End If
                End If
                dPara.Range.HighlightColorIndex = WdColorIndex.wdNoHighlight
                If UserConfirmStr = "yes" Then
                    If IdentifierValStr.ToUpper() <> "SKIP" And IdentifierValStr <> "" And IdentifierValStr <> "del" And IdentifierValStr <> "runonwithcomma" Then
                        Call modApplyStyles.ToApplyStyle(WordApp, wDoc, dPara.Range, IdentifierValStr)
                        objPara.newStyledName = IdentifierValStr
                    End If
                ElseIf UserConfirmStr = "yesall" Then
                    If IdentifierValStr.ToUpper() <> "SKIP" And IdentifierValStr <> "" And IdentifierValStr <> "del" And IdentifierValStr <> "runonwithcomma" Then
                        Call modApplyStyles.ToApplyStyle(WordApp, wDoc, dPara.Range, IdentifierValStr)
                        objPara.newStyledName = IdentifierValStr
                        objPara.ApplyStyleAll = True
                    End If
                Else
                    IdentifierValStr = ""
                    GoTo shForm
                End If
NxtPara:
                wDoc.UndoClear()
                If objPara.newStyledName <> "" Then
                    If Not dictParaInfor.ContainsKey(PRng) And Not objPara Is Nothing Then
                        dictParaInfor.Add(PRng, objPara)
                    End If
                End If
                IdentifierValStr = "" : UserConfirmStr = ""

            Next
        Catch ex As Exception

        End Try
    End Function
    Function ToApplyUserSelectedStyle(styName As String, ranPara As Range)

    End Function
End Class
Public Class clsParaProperty
    Public Sub New()
        orgStyleName = "" : pFontName = "" : FontSize = ""
        IsBold = False : IsItalic = False
        IsIndent = False : newStyledName = "" : ApplyStyleAll = False
    End Sub
    Friend orgStyleName As String
    Friend newStyledName As String
    Friend pFontName As String
    Friend FontSize As String
    Friend IsBold As Boolean
    Friend IsItalic As Boolean
    Friend IsIndent As Boolean
    Friend ApplyStyleAll As Boolean
End Class


